BEGIN TRANSACTION;
CREATE TABLE Mobile_UserOffline (enduser_id INTEGER PRIMARY KEY AUTOINCREMENT, enduser_username TEXT, enduser_password TEXT);
CREATE TABLE sqlite_sequence(name,seq);
COMMIT;
