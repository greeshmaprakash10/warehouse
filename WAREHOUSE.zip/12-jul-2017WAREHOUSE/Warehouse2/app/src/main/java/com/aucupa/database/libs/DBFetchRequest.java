package com.aucupa.database.libs;

public class DBFetchRequest {

	public static class UserFetchRequest{
		public static String uname=null;
		public static String password=null;
		
		public UserFetchRequest(String uname,String password) {
			this.uname=uname;
			this.password=password;
		}
	}
}
