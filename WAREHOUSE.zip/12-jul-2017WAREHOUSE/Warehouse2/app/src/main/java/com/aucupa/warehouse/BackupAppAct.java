package com.aucupa.warehouse;

import android.content.Context;
import android.os.Environment;
import android.text.format.Time;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.channels.FileChannel;

public class BackupAppAct {
	private String BACKUP_DIR="/Aucupa_DevNeeds";
	
	
	public void backupAppSQLite(Context context,String packagename,String databasename){
		try {
		    File sd = Environment.getExternalStorageDirectory();
		    File data = Environment.getDataDirectory();
		    if (sd.canWrite()) {
		        String currentDBPath = "//data//"+ packagename +"//databases//"+databasename;
		        Time now=new Time();
		        now.setToNow();
		        String backupDBfile = databasename+"_"+now.monthDay+now.MONTH+now.year+"_"+now.hour+now.minute+now.second;
		        File currentDB = new File(data, currentDBPath);
		        File backupDB = new File(sd,BACKUP_DIR);
		        if(!backupDB.exists()){
		        	backupDB.mkdir();
		        }
		        backupDB=new File(backupDB,backupDBfile);
		        FileChannel src = new FileInputStream(currentDB).getChannel();
				long size= (src.size());
				Log.i("size=", String.valueOf(size));
		        FileChannel dst = new FileOutputStream(backupDB).getChannel();
		        dst.transferFrom(src, 0, src.size());
		        src.close();
		        dst.close();
//		        Toast.makeText(context, backupDB.toString(), Toast.LENGTH_LONG).show();
//				 Intent emailIntent = new Intent(Intent.ACTION_SEND);
//				 emailIntent .setType("*/email");
//		        emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[] {"myphone9497@gmail.com"});
//		        emailIntent.putExtra(Intent.EXTRA_SUBJECT,Utilities.EMAIL_SUBJUCT+Utilities.EMAIL_COMPANY_NAME);
//		        emailIntent.putExtra(Intent.EXTRA_TEXT, Utilities.EMAIL_BODY);
//		        if (!backupDB.exists() || !backupDB.canRead()) {
//		        return;
//		        }
//		        Uri uri = Uri.fromFile(backupDB);
//		        emailIntent.putExtra(Intent.EXTRA_STREAM, uri);
//		        context.startActivity(Intent.createChooser(emailIntent, "Pick an Email provider"));
		    }
		} catch (Exception e) {
		    Toast.makeText(context, e.toString(), Toast.LENGTH_LONG).show();
		}	
	}
	public static void BackupLog(Context context){
		try {
		      Process process = Runtime.getRuntime().exec("logcat -d");
		      BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(process.getInputStream()));

		      StringBuilder log=new StringBuilder();
		      String line;
		      while ((line = bufferedReader.readLine()) != null) {
		        log.append(line);
		      }
		      
		      Toast.makeText(context, log, Toast.LENGTH_SHORT).show();
		      
		} catch (IOException e) {
	    }
	}
	
}
