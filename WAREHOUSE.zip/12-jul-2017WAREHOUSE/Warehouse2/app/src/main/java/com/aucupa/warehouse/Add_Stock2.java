package com.aucupa.warehouse;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.format.Time;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;  
import android.widget.RadioGroup; 
import android.widget.Spinner;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;

public class Add_Stock2 extends Activity {
	int currentdatebtnid;
	SimpleDateFormat datef;
	
	Button btnarrival,btnexpdate;
	
	String stocktype_Selected;
	
	Spinner spinstocktype,spinsuppliername;
	
	AutoCompleteTextView etItemcode;
	
	TableRow trOrderIntent,trbatchnumber;
	
	EditText etItemname,etOrdernumber,etitemunit,
	etCategory,etSubCategory,etBatchnumber,etRmarno,etrmspecno,etgirno,etcomgrade,etvariety,
	etestimateyield,etTotalQuantity,etLotnumber,etNoofbags,etunitprice,etarrivalfrom,etRemarks;  
	
	String stsuppliercode,stItemcode,stItemname,stOrdernumber,stCategory,stSubCategory,
	stitemunit,strmspecno,stgirno,stcomgrade,stvariety,stestimateyield,stexpdate,stunitprice,starrivalfrom,
	stBatchnumber,stRmarno,stLotnumber,stNoofbags,stRemarks,stArrivaldate,Today,stTotalquantity,
	stWareHouseNo;
	
	String stStatus = 0+"";
	String stIntentstatus=0+"";
	
	boolean flag_insert=true;
	
	ArrayList< String> itemcodelist;
	
	RadioGroup radiorderintent;
	RadioButton radioorderno,radiointen;
	Sqldatabase db;
	Utils utility;
	Context context;
	
	@Override 
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_add__stock2);
		
		context=this;
		db = new Sqldatabase(this); 
		
		btnarrival=(Button)findViewById(R.id.btnarrivaldate);
		btnexpdate=(Button)findViewById(R.id.btnexpdate);
		
		radiorderintent=(RadioGroup)findViewById(R.id.radiogroupaddstockoi);
		radioorderno=(RadioButton)findViewById(R.id.radiobtnaddstockorderno);
		radiointen=(RadioButton)findViewById(R.id.radiobtnaddstockintent);
		
		trOrderIntent=(TableRow)findViewById(R.id.tr_orderintent);
		trbatchnumber=(TableRow)findViewById(R.id.tr_batchnumber);
		
		
		spinstocktype=(Spinner)findViewById(R.id.spinstocktype);
		spinsuppliername=(Spinner)findViewById(R.id.spinsupplier);
		
		etOrdernumber=(EditText)findViewById(R.id.editordernumber);
		etItemcode=(AutoCompleteTextView)findViewById(R.id.edititemcode);
		etItemname=(EditText)findViewById(R.id.edititemname);
		etCategory=(EditText)findViewById(R.id.editcategory);
		etSubCategory=(EditText)findViewById(R.id.editsubcategory);
		etitemunit=(EditText)findViewById(R.id.edititemunit);
		etRmarno=(EditText)findViewById(R.id.editrmarno);
		etBatchnumber=(EditText)findViewById(R.id.editbatchnumber);
		etrmspecno=(EditText)findViewById(R.id.editrmspecno);
		etgirno=(EditText)findViewById(R.id.editgirno);
		etcomgrade=(EditText)findViewById(R.id.editcommoditygrade);
		etvariety=(EditText)findViewById(R.id.editvariety);
		etestimateyield=(EditText)findViewById(R.id.editestimatedyield);
		etTotalQuantity=(EditText)findViewById(R.id.edittotalqty);
		etNoofbags=(EditText)findViewById(R.id.editnoofbag);
		etunitprice=(EditText)findViewById(R.id.editunitprice);
		etLotnumber=(EditText)findViewById(R.id.editlotno);
		etarrivalfrom=(EditText)findViewById(R.id.editarivalfrom);
		etRemarks=(EditText)findViewById(R.id.editremarks);
		
		/**ware house No**/
		stWareHouseNo=utility.SharedPreferencesContain(Add_Stock2.this,"Warehouse_No");
		
		/***Date ***/
		Date d=new Date(System.currentTimeMillis());
		datef=new SimpleDateFormat("dd/MM/yyyy");
		btnarrival.setText(datef.format(d));
		btnexpdate.setText(datef.format(d));
		//TODO Demo Variables.....
		
		spinstocktype.setSelection(2); 
		
		/**Supplier Spiner**/
		Cursor c=db.getdb().query(db.tbl_suppliers, null, null, null, null, null, null);
		ArrayList<String>supplierslist=new ArrayList<>();
		if(c.getCount()>0){
			
		}else{
			ContentValues cv=new ContentValues();
			for(int i=1;i<6;i++){
			cv.put(db.key_supplier_code, "Sup"+i);
			cv.put(db.key_supplier_name,"Supplier "+i);
			
			db.sqlins(db.tbl_suppliers, cv);
			}
			c=db.getdb().query(db.tbl_suppliers, null, null, null, null, null, null);
		}
		supplierslist.clear();
		while(c.moveToNext()){
			supplierslist.add(c.getString(2)+" ("+c.getString(1)+")");
		}
		ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
				R.layout.spinner_item, supplierslist);
			dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			spinsuppliername.setAdapter(dataAdapter); 
			
			spinsuppliername.setOnItemSelectedListener(new OnItemSelectedListener() {

				@Override
				public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
					// TODO Auto-generated method stub
					String s=((TextView)view).getText().toString();
					stsuppliercode=s.substring(s.indexOf("(")+1,s.indexOf(")"));
				}

				@Override
				public void onNothingSelected(AdapterView<?> parent) {
					// TODO Auto-generated method stub
					spinsuppliername.setSelection(0);
				}
			});

		etItemcode.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				// TODO Auto-generated method stub
				Cursor cr=db.getdb().query(true, db.tbl_Items,null,
					db.key_warehouse_item_itemtype+" = ? AND "+db.key_warehouse_item_itemcode+" = ? ",
			            new String[] {stocktype_Selected.toString(),((TextView)view).getText().toString()}, null, null, null,
			            null);
				if(cr.getCount()>0){
					cr.moveToFirst();
					etItemname.setText(cr.getString(1));
					etCategory.setText(cr.getString(2));
					etSubCategory.setText(cr.getString(3));
					etitemunit.setText(cr.getString(4));
					
				}
			}
		});
		
		btnarrival.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				showArrivalDate(btnarrival.getId());
				
			}
		});	
		
		btnexpdate.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				showArrivalDate(btnexpdate.getId());
			}
		});
		
		/** Initial Clear Values **/
		
		/***Spinner***/
		spinstocktype.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int position, long arg3) {
				// TODO Auto-generated method stub
				
				switch (position) {
				case 2:
					stocktype_Selected="1";
					trOrderIntent.setVisibility(View.VISIBLE);
					radioorderno.setChecked(true);
					etOrdernumber.setHint("Order Number");
					stIntentstatus=0+"";
					trbatchnumber.setVisibility(View.GONE);
					etBatchnumber.setText("");
					stBatchnumber="";
					autoCompletefill();
					etItemcode.setText("");
					etItemname.setText("");
					etCategory.setText("");
					etSubCategory.setText("");
					etitemunit.setText("");
					break;
					
				case 1:
					stocktype_Selected="2";
					trOrderIntent.setVisibility(View.GONE);
					radioorderno.setChecked(true);
					etOrdernumber.setHint("Order Number");
					stIntentstatus=0+"";
					trbatchnumber.setVisibility(View.VISIBLE);
					etBatchnumber.setText("");
					stBatchnumber="";
					autoCompletefill();
					etItemcode.setText("");
					etItemname.setText("");
					etCategory.setText("");
					etSubCategory.setText("");
					etitemunit.setText("");
						break;
				case 0:
					stocktype_Selected="3";
					trOrderIntent.setVisibility(View.GONE);
					radioorderno.setChecked(true);
					etOrdernumber.setHint("Order Number");
					stIntentstatus=0+"";
					trbatchnumber.setVisibility(View.VISIBLE);
					etBatchnumber.setText("");
					stBatchnumber="";
					autoCompletefill();
					etItemcode.setText("");
					etItemname.setText("");
					etCategory.setText("");
					etSubCategory.setText("");
					etitemunit.setText("");
							break;	
				default:
					break;
				}
				
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				spinstocktype.setSelection(2);
			}
		});

	}
	
	public void autoCompletefill() {
		itemcodelist=new ArrayList<>();
		itemcodelist.clear();
				Cursor c=db.getdb().query(db.tbl_Items, null, null, null, null, null, null);
		if(c.getCount()>0){
			c=db.getdb().query(true, db.tbl_Items, new String[] { db.key_warehouse_item_itemcode},
					db.key_warehouse_item_itemtype+" = ? ",
			            new String[] {stocktype_Selected.toString()}, null, null, null,
			            null);
		}else{
			Toast.makeText(Add_Stock2.this, "101010",
					Toast.LENGTH_SHORT).show();
			ContentValues cv=new ContentValues();
			for(int i=1;i<20;i++){
			cv.put(db.key_warehouse_item_itemcode, "i00"+i);
			cv.put(db.key_warehouse_item_itemname,"item"+i);
			cv.put(db.key_warehouse_item_category, "category"+i);
			cv.put(db.key_warehouse_item_subcategory,"SubCAt"+i);
			if(i%4==0){
				cv.put(db.key_warehouse_item_itemtype, ""+1);
			}else{
				cv.put(db.key_warehouse_item_itemtype, ""+i%4);
			}
			cv.put(db.key_warehouse_item_itemUnit,"kg");
			
			db.sqlins(db.tbl_Items, cv);
			}
			c=db.getdb().query(true, db.tbl_Items, new String[] { db.key_warehouse_item_itemcode},
					db.key_warehouse_item_itemtype+" = ? ",
			            new String[] {stocktype_Selected}, null, null, null,
			            null);
		}
		while (c.moveToNext()) {
			itemcodelist.add(c.getString(0));
		}
		ArrayAdapter<String> adapter =new ArrayAdapter<String>(getApplicationContext(),R.layout.autolistview,itemcodelist);
		etItemcode.setAdapter(adapter);
	}
	
	public void  onRadioButtonClicked(View view){
		 // Is the button now checked?
	    boolean checked = ((RadioButton) view).isChecked();
	    
	    // Check which radio button was clicked
	    switch(view.getId()) {
	        case R.id.radiobtnaddstockintent:
	            if (checked)
	            	stIntentstatus=1+"";
				etOrdernumber.setHint("Intent Number");
	            break;
	        case R.id.radiobtnaddstockorderno:
	            if (checked)
	            	stIntentstatus=0+"";
				etOrdernumber.setHint("Order Number");
	            break;
	    }
	}
	
	//click on Save Button
	public void clicktoSave(View v){ 
		
		flag_insert=true;
		if(etestimateyield.getText().toString().equals("")){
			stestimateyield=""+0;
		}else
		{
			stestimateyield=etestimateyield.getText().toString();
		}
		if(etOrdernumber.length()<1)
		{
			String msg="Enter "+etOrdernumber.getHint().toString();
			Toast.makeText(Add_Stock2.this, msg, Toast.LENGTH_SHORT).show();
			flag_insert=false;
		}
		else if(etItemcode.length()<1)
		{
			Toast.makeText(Add_Stock2.this, "Enter Item Code ", Toast.LENGTH_SHORT).show();
			flag_insert=false;
		}
		else if(Double.parseDouble(stestimateyield)<0.0||Double.parseDouble(stestimateyield)>100.0){
			if(!etestimateyield.getText().toString().equals("")){

				Toast.makeText(Add_Stock2.this, "Enter Estimate Yield 0% - 100%", Toast.LENGTH_SHORT).show();
				flag_insert=false;
			}
		}
		else if(!checkdate(btnexpdate.getText().toString(),R.id.btnexpdate)){
			Toast.makeText(Add_Stock2.this, "Expiry Date must Greater than Current date", Toast.LENGTH_SHORT).show();
			flag_insert=false;
		}
		else if(etTotalQuantity.length()<1){
			Toast.makeText(Add_Stock2.this, "Enter Toatal Quantity", Toast.LENGTH_SHORT).show();
			flag_insert=false;
		}
		else if(etNoofbags.length()<1)
		{
			Toast.makeText(Add_Stock2.this, "Enter Number Of Bags ", Toast.LENGTH_SHORT).show();
			flag_insert=false;
		}
		else if(!checkdate(btnarrival.getText().toString(),R.id.btnarrivaldate)){
			Toast.makeText(Add_Stock2.this, "arrival date must less than or equal to Current Date",
					Toast.LENGTH_SHORT).show();
			flag_insert=false;
		}
		else{
			stArrivaldate=btnarrival.getText().toString();
			stOrdernumber=etOrdernumber.getText().toString();
			stItemcode=etItemcode.getText().toString();
			stItemname=etItemname.getText().toString();
			stCategory=etCategory.getText().toString();
			stSubCategory=etSubCategory.getText().toString();
			stitemunit=etitemunit.getText().toString();
			stRmarno=etRmarno.getText().toString();
			stBatchnumber=etBatchnumber.getText().toString();
			strmspecno=etrmspecno.getText().toString();
			stgirno=etgirno.getText().toString();
			stcomgrade=etcomgrade.getText().toString();
			stvariety=etvariety.getText().toString();
			stestimateyield=etestimateyield.getText().toString();
			stexpdate=btnexpdate.getText().toString();
			stTotalquantity=etTotalQuantity.getText().toString();
			stNoofbags=etNoofbags.getText().toString();
			stunitprice=etunitprice.getText().toString();
			stLotnumber=etLotnumber.getText().toString();
			starrivalfrom=etarrivalfrom.getText().toString();
			stArrivaldate=btnarrival.getText().toString();
			stRemarks=etRemarks.getText().toString();
			flag_insert=true;
		}
		
		
		try {
			Cursor curs=db.sqlQuery("Select * from "+db.tbl_warehouse_addsock+
					" where "+db.key_warehouse_addstock_ordernumber+" = '"+stOrdernumber+"'");
			if(curs.getCount()>0){
				Toast.makeText(Add_Stock2.this, "Same Order Number Already Exist", Toast.LENGTH_SHORT).show();
				flag_insert=false;
			}
//			 curs=db.sqlQuery("Select * from "+db.tbl_warehouse_addsock+
//						" where "+db.key_warehouse_addstock_batchnumber+" = '"
//					 +stBatchnumber+"' AND "+db.key_warehouse_addstock_itemcode+" = '"
//						+stItemcode+"' AND "+db.key_warehouse_addstock_Stocktype+" = '"+stocktype_Selected+"'"
//								+ " AND "+db.key_warehouse_addstock_warehouseno+" = '"+stWareHouseNo+"'");
//			if(curs.getCount()>0){
//					Toast.makeText(Add_Stock.this, "Same Stock Already Exist", Toast.LENGTH_SHORT).show();
//					flag_insert=false;
//			}
			
			/**code for insert into table_
			 * category and sub category not inserted
			*/
			
			if(flag_insert){
				ContentValues cv=new ContentValues();
				cv.put(db.key_warehouse_addstock_Stocktype, stocktype_Selected);
				cv.put(db.key_warehouse_addstock_ordernumber, stOrdernumber);
				cv.put(db.key_warehouse_addstock_suppliercode, stsuppliercode);
				cv.put(db.key_warehouse_addstock_itemcode, stItemcode);
				cv.put(db.key_warehouse_addstock_RMARnumber, stRmarno);
				cv.put(db.key_warehouse_addstock_batchnumber, stBatchnumber);
				cv.put(db.key_warehouse_addstock_RmSpecNo, strmspecno);
				cv.put(db.key_warehouse_addstock_GIRNo, stgirno);
				cv.put(db.key_warehouse_addstock_commoditygrade, stcomgrade);
				cv.put(db.key_warehouse_addstock_variety, stvariety);
				cv.put(db.key_warehouse_addstock_EstYiels, stestimateyield);
				cv.put(db.key_warehouse_addstock_ExpDate, stexpdate);
				cv.put(db.key_warehouse_addstock_totalquantity, stTotalquantity);
				cv.put(db.key_warehouse_addstock_noofbags, stNoofbags);
				cv.put(db.key_warehouse_addstock_UnitPrice, stunitprice);
				cv.put(db.key_warehouse_addstock_lotnumber, stLotnumber);
				cv.put(db.key_warehouse_addstock_ArrivalForm, starrivalfrom);
				cv.put(db.key_warehouse_addstock_arrivaldate, stArrivaldate);
				cv.put(db.key_warehouse_addstock_intentstatus, stIntentstatus);
				cv.put(db.key_warehouse_addstock_Remarks, stRemarks);
				cv.put(db.key_warehouse_syncstatus, stStatus);
				
				long stockid=db.sqlins(db.tbl_warehouse_addsock, cv);
				if(stockid>0){
					Toast.makeText(Add_Stock2.this, "Stock Added Successfully "
							, Toast.LENGTH_SHORT).show();
					Bundle b=new Bundle();
					b.putLong("Stock_Id", stockid);
					Intent i=new Intent(Add_Stock2.this,QACheckList.class);
					i.putExtras(b);
					clearvalues();
					startActivity(i);
					finish();
								
			}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public void clearvalues(){
		btnarrival.setText(datef.format(new Date(System.currentTimeMillis())));
		btnexpdate.setText(datef.format(new Date(System.currentTimeMillis())));
		etOrdernumber.setText("");
		etItemcode.setText("");
		etItemname.setText("");
		etCategory.setText("");
		etSubCategory.setText("");
		etitemunit.setText("");
		etRmarno.setText("");
		etBatchnumber.setText("");
		etrmspecno.setText("");
		etgirno.setText("");
		etcomgrade.setText("");
		etvariety.setText("");
		etestimateyield.setText("");
		etTotalQuantity.setText("");
		etNoofbags.setText("");
		etunitprice.setText("");
		etLotnumber.setText("");
		etarrivalfrom.setText("");
		Date d=new Date(System.currentTimeMillis());
		datef=new SimpleDateFormat("dd/MM/yyyy");
		btnarrival.setText(datef.format(d));
		btnexpdate.setText(datef.format(d));
		etRemarks.setText("");
		radioorderno.setChecked(true);
		spinstocktype.setSelection(2);
		spinsuppliername.setSelection(0);
		flag_insert=true;
	}
	
	protected void showArrivalDate(int id) {
		// TODO Auto-generated method stub
		currentdatebtnid=id;
		OnDateSetListener dsl=new OnDateSetListener() {
			
			@Override
			public void onDateSet(DatePicker view, int year, int monthOfYear,
					int dayOfMonth) {
				// TODO Auto-generated method stub
				String date=String.valueOf(year)+" "+String.valueOf(monthOfYear)+" "+String.valueOf(dayOfMonth);
				
				
				
				Date d=new Date(System.currentTimeMillis());
				d.setYear(year-1900);
				d.setMonth(monthOfYear);
				d.setDate(dayOfMonth);
				setArrivaldate(d);
			}
		};
		Date temp=new Date(System.currentTimeMillis());
		Time today = new Time(Time.getCurrentTimezone());
		today.setToNow();
		DatePickerDialog dial=new DatePickerDialog(this,dsl,today.year,today.month,today.monthDay);
		dial.show();
	}
	
	public void setArrivaldate(Date date){
		Button b=(Button)findViewById(currentdatebtnid);
		b.setText(datef.format(date));
		try {
			java.util.Date d=datef.parse(b.getText().toString());
			System.out.println(d.getTime());
		} catch (Exception  e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println();
	    } 

	public boolean checkdate(String stringdate,int id){
		
		java.util.Date curdate = null,arrdate = null;
		try
		{
			 curdate=datef.parse(datef.format(new Date(System.currentTimeMillis())));
			 arrdate=datef.parse(stringdate.toString());
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		switch (id) {
		case R.id.btnarrivaldate:
			if(curdate.compareTo(arrdate)<0){
				flag_insert=false;
				return false;
			}
			break;
		case R.id.btnexpdate:
			if(curdate.compareTo(arrdate)>=0){
				flag_insert=false;
				return false;
			}
			break;

		default:
			break;
		}
		return true;
	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		super.onBackPressed();
		Intent i1 =new Intent(getApplicationContext(),Select_Activity.class);
		i1.putExtra("syncstatus",true);
		startActivity(i1);
		finish();
	}
}
