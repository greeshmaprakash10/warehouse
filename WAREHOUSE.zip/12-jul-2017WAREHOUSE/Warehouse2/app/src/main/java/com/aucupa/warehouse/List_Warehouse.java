package com.aucupa.warehouse;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;


public class List_Warehouse extends Activity{
	
	  
	ListView lvPlants;
	String PlantId,warehouseno;
	TextView tvNotificCount;
	ArrayList<HashMap<String, String>> myList = new ArrayList();
	//private Databaseadapter dbAdapter;
	SimpleAdapter myAdapter;
	Context context;
	Timer timer;
	TimerTask doAsynchronousTask;
	Sqldatabase dbAdapter;
	private SQLiteDatabase mydatabase;
//	private String syncstatus;
	boolean syncstatus ;
	private boolean login_uname;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{ 
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.list_warehouse);
		this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		context=this;
		dbAdapter = new Sqldatabase(this);
		lvPlants = (ListView)findViewById(R.id.listViewPlants);
	
		
		 getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				 WindowManager.LayoutParams.FLAG_FULLSCREEN);
	     getStatusBarHeight();
	     
	     
	syncstatus = getIntent().getExtras().getBoolean("syncstatus");
	login_uname = getIntent().getExtras().getBoolean("uname");
	
		if(syncstatus){
			
			if(Utils.CheckNet(context)){
				new WarehouseListing().execute("");
				  
				
			//	warHouseAssignList();
			}
		}else	{
			
			warHouseAssignList();
			
			//		Toast.makeText(context, "database sync is faild please connect to network", Toast.LENGTH_SHORT).show();
		
		}
		
	//     new	WarehouseListing().execute("");
	       
	     /*String warehouse= "Warehouse-1";
	     String id ="1";
	    
	     Sqldatabase db=new Sqldatabase(context);
			SQLiteDatabase sqlite=db.getdb();
			String sql="insert or replace into "+Sqldatabase.tbl_warehouse_no+" values (?,?)";
			
		      
		     try {
				sqlite.execSQL(sql, new String[]{id,warehouse});
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
		     
		     lvPlants.setOnItemClickListener(new OnItemClickListener() {
 
					@Override  
					public void onItemClick(AdapterView<?> arg0, View arg1, int position,
							long arg3) {
						// TODO Auto-generated method stub
						HashMap<String, String> map = (HashMap<String, String>)lvPlants.getItemAtPosition(position);
						warehouseno = map.get("warehouse_no");
		  				
						 Utils.setSharedPreferences(context, "Warehouse_No", warehouseno);
						 					
							Intent intent = new Intent(getApplicationContext(),Select_Activity.class);
							//intent.putExtra("PlantId", PlantId);
							startActivity(intent);
						//	finish();
						}
					
				});
		     
		
		    
	     
	     
	}
	    
	
	////////////////////// OFLINE WARE HOUSE SELECTION
	
	
	 private void warHouseAssignList() {
		// TODO Auto-generated method stub
		 

			
		 this.myList.clear();
		 Cursor cursor = warehousefromSqlite();
		 
		 if((cursor !=null)&&(cursor.getCount()>0))
		 {
			 cursor.moveToFirst();
			 do{
	               HashMap<String, String> map = new HashMap<String, String>();
	               
	               map.put("warehouse_no", cursor.getString(cursor.getColumnIndex("warehouse_no")));
	               this.myList.add(map);
	           }
	         while (cursor.moveToNext());
		 }
		 else
		 {
			
			 
			 PopupError("No plants alloted to this user.. contact server admin..");
				
		 }
		 
		 cursor.close();
	        
		 myAdapter = new SimpleAdapter(this, myList, R.layout.list_adapter,
				 
				 new String[]{"warehouse_no"},
				 
	               new int[]{R.id.textViewPlant});
	        this.lvPlants.setAdapter(myAdapter);
	        this.myAdapter.notifyDataSetChanged();
	
		  
		 
		
	}

 	 ///////////////////////////////////// WARE HOUSES FROM TBL
	 
	private Cursor warehousefromSqlite() {
		// TODO Auto-generated method stub
	
		
		Sqldatabase db = new Sqldatabase(context);
		String uname_id = "";
		String  qry = "";
			String name = Utils.SharedPreferencesContain(context, "user");
			
			Cursor n = db.sqlQuery(" SELECT "+db.key_mobileuser_id+" FROM "+db.tbl_mobile_user+" WHERE "+db.key_mobileuser_name+" = '"+name+"'");
			
		
				if(n != null){
					
					n.moveToFirst();
					uname_id = n.getString(0);
					
				}
				try {
			
					qry = "SELECT "+db.tbl_warehouse_no+"."+db.key_warehouse_no_plantno+ " FROM "+db.tbl_warehouse_no+"," +
	    		 		""+db.tbl_assign_warehouse+ " WHERE "+db.tbl_warehouse_no+"."
	    		 		+db.key_warehouse_no_id+" = " +db.tbl_assign_warehouse+"."
	    		 		+db.key_assign_warehouse_plantno+ " AND "
	    		 		+db.tbl_assign_warehouse+"." +db.key_assign_warehouse_uname+" = '"+uname_id+"'";
		    
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
				  return db.sqlQuery(qry);
				  
	}        
	//select a.warehouse_no from Warehouse_No a,Assign_WareHouse b where a.id=b.warehouse_no and b.enduser_id=userid;
                                                 
                   ///////////////////////// '"+stdate+"'

	public int getStatusBarHeight() {
	        int result = 0;
	        int resourceId = getResources().getIdentifier("status_bar_height", "dimen", "android");
	        if (resourceId > 0) {
	            result = getResources().getDimensionPixelSize(resourceId);
	        }
	        return result;
	      }
	 
	 public void list_plants()
		{
			
			 this.myList.clear();
			 Cursor cursor = this.dbAdapter.ListPlants();
			 if((cursor !=null)&&(cursor.getCount()>0))
			 {
				 cursor.moveToFirst();
				 do{
		               HashMap<String, String> map = new HashMap<String, String>();
		              // map.put("id", cursor.getString(cursor.getColumnIndex("PlantId")));
		               map.put("warehouse_no", cursor.getString(cursor.getColumnIndex("warehouse_no")));
		               this.myList.add(map);
		           }
		         while (cursor.moveToNext());
			 }
			 else
			 {
				 //*****************************************************  //locally filling the plant table
					
				/*	String[] PlantIds = getResources().getStringArray(R.array.plantId);
					String[] PlantNames = getResources().getStringArray(R.array.Plants);
					String[] groupIds = getResources().getStringArray(R.array.groupId);
					
					for(int i =0; i<PlantIds.length;i++)
					{
						String sql="insert or replace into tb_Plants values (?,?,?)";
			            sqlite.execSQL(sql, new String[]{PlantIds[i],PlantNames[i],groupIds[i]});
					}
					
					list_plants(); */
					
					//**************************************************** 
				 
				 PopupError("No plants alloted to this user.. contact server admin..");
					
			 }
			 
			 cursor.close();
		        
			 myAdapter = new SimpleAdapter(this, myList, R.layout.list_adapter,
					 
					 new String[]{"warehouse_no"},
					 
		               new int[]{R.id.textViewPlant});
		        this.lvPlants.setAdapter(myAdapter);
		        this.myAdapter.notifyDataSetChanged();
		}
	 
	 
	 
	 private class WarehouseListing extends AsyncTask<String, Void, Boolean> {
     	private final ProgressDialog dialog = new ProgressDialog(context);

     	String response;
     	
     	protected void onPreExecute() {
     		
     		this.dialog.setMessage("syncing warehouse...");

     		this.dialog.show();  
     		this.dialog.setCancelable(false);
     	}

     	protected Boolean doInBackground(final String... args) {

     		response = Utils.setWarehouseTable(context);
     		
     		return true;  
     	}

     	protected void onPostExecute(final Boolean success) {

     		if(response.trim().equals("Success")) 
     		{
     			
     			warHouseAssignList(); 
     		//	 list_plants(); 
     			
     		}
     		

     		if (this.dialog.isShowing())  
     		{
     			this.dialog.dismiss();
     		}  

     	}

     }
	 
	 
	 private void PopupError(String errormsg)
	  {
	    AlertDialog.Builder builder = new AlertDialog.Builder(this);
	    builder.setCancelable(true);
	    builder.setTitle("Message !!!");
	    builder.setInverseBackgroundForced(true);
	    builder.setMessage(errormsg);
	    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int arg1) {
				// TODO Auto-generated method stub
				dialog.dismiss();
			}
		});
	    builder.create().show();
	  }
	 
}
