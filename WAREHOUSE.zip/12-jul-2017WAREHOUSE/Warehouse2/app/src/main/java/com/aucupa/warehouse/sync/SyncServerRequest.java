package com.aucupa.warehouse.sync;

import android.content.Context;
import android.database.Cursor;
import android.util.Log;
import android.widget.Toast;

import com.aucupa.warehouse.Sqldatabase;
import com.aucupa.warehouse.Utils;
import com.google.gson.JsonArray;
import com.google.gson.JsonIOException;
import com.google.gson.JsonObject;

public class SyncServerRequest {
	Context context;
	Sqldatabase db;
	JsonObject jsonInObj;
	JsonArray jsonINArray;
	
	JsonObject jsonSyncObj;
	JsonArray jsonSyncArray;
	
//	private static String SYNC_IN="sync_in";
//	private static String SYNC_OUT="sync_out";
    private static String SYNC_IN="sync_ins";
	private static String SYNC_OUT="sync_outs";
	private static String DEV_ID="dev_id";
	private static String USER_ID="user_id";
	private static String LASTSYNC_TIME="last_sync";
	private static String DATA="data";
	private static String TABLE="table";
	String lastsynctime="0";
	String dev_id="";
	public SyncServerRequest(Context context) {
		this.context=context;
		db=new Sqldatabase(context);
	}
	
	private void commonRequestdatas(String table){
		lastsynctime="0";
		Cursor cr=db.getdb().query(db.tbl_Config,new String[]{"value"},"name = ? ",new String[]{table},
				null,null,null);
		while(cr.moveToNext()){
			if(cr.getCount()>0){
				if(!(cr.getString(0).toString().equals("")))
				{
					lastsynctime=cr.getString(0).toString();
				}
				else{
					lastsynctime="0";
				}
			}
		}
		
		dev_id=getdiviceid();
	}
	
	public String getdiviceid(){
		return Utils.SharedPreferencesContain(context, "Div_id");
	}
	
//	public void syncStockINRequest(){
//		jsonInObj=new JsonObject();
//		jsonINArray=new JsonArray();
//		JsonObject jsondata=null;
//		String[] select=new String[]{Sqldatabase.key_warehouse_addstock_stockid,
//				Sqldatabase.key_warehouse_addstock_Stocktype,
//				Sqldatabase.key_warehouse_addstock_ordernumber,
//				Sqldatabase.key_warehouse_addstock_suppliercode,
//				Sqldatabase.key_warehouse_addstock_itemcode,
//				Sqldatabase.key_warehouse_addstock_RmSpecNo,
//				Sqldatabase.key_warehouse_addstock_qcinspno,
//				Sqldatabase.key_warehouse_addstock_batchnumber,
//				Sqldatabase.key_warehouse_addstock_totalquantity,
//				Sqldatabase.key_warehouse_addstock_noofbags,
//				Sqldatabase.key_warehouse_addstock_lotnumber,
//				Sqldatabase.key_warehouse_addstock_UnitPrice,
//				Sqldatabase.key_warehouse_addstock_arrivaldate,
//				Sqldatabase.key_warehouse_addstock_intentstatus,
//				Sqldatabase.key_warehouse_addstock_location_status,
//				Sqldatabase.key_warehouse_addstock_Remarks,
//				Sqldatabase.key_warehouse_server_stockID,
//				Sqldatabase.key_warehouse_createdtime};
//		Cursor cr=db.getdb().query(Sqldatabase.tbl_warehouse_addsock,
//				select,
//				Sqldatabase.key_warehouse_syncstatus+" = ? ",
//				new String[]{"0"},
//				null,
//				null,
//				null);
//
//			try {
//
//				jsonInObj.addProperty(TABLE,"StockDetails");
//				jsonInObj.addProperty("username",Utils.SharedPreferencesContain(context, "user"));
//				jsonInObj.addProperty(DEV_ID,getdiviceid());
//				if(cr.getCount()>0){
//				//	Toast.makeText(context, "Ther is some value", Toast.LENGTH_SHORT).show();
//					while(cr.moveToNext()){
//						jsondata=new JsonObject();
//						for(int i=0;i<cr.getColumnCount();i++){
//							if(cr.isNull(i))
//								jsondata.addProperty(cr.getColumnName(i),"");
//							else{
//									jsondata.addProperty(cr.getColumnName(i), cr.getString(i));
//							}
//					}
//						jsonINArray.add(jsondata);
//					}
//				jsonInObj.add(DATA,jsonINArray);
//				SyncServer.SyncToServerStock(context,Utils.weburl+SYNC_IN, jsonInObj);
//				}else{
//					jsonInObj.addProperty(DATA,"");
//				}
//
//			} catch (JsonIOException e) {
//				e.printStackTrace();
//			}
//			Log.i("JSON ",jsonInObj.toString());
//			System.out.print("JSON RESULT : " +jsonInObj.toString());
//	}
public void syncStockINRequest(){
	jsonInObj=new JsonObject();
	jsonINArray=new JsonArray();
	JsonObject jsondata=null;
	String[] select=new String[]{

			Sqldatabase.key_warehouse_addstock_Stocktype,
			Sqldatabase.key_warehouse_addstock_itemcode,
			Sqldatabase.key_warehouse_addstock_lotnumber,
			Sqldatabase.key_warehouse_addstock_totalquantity,
			Sqldatabase.key_warehouse_addstock_warehousecode,
			Sqldatabase.key_warehouse_addstock_suppliercode,
			Sqldatabase.key_warehouse_addstock_ordernumber,
			Sqldatabase.key_warehouse_server_stockID,
			Sqldatabase.key_warehouse_createdtime};
	Cursor cr=db.getdb().query(Sqldatabase.tbl_warehouse_addsock,
			select,
			Sqldatabase.key_warehouse_syncstatus+" = ? ",
			new String[]{"0"},
			null,
			null,
			null);

	try {

		jsonInObj.addProperty(TABLE,"StockDetails");
		jsonInObj.addProperty("username",Utils.SharedPreferencesContain(context, "user"));
		jsonInObj.addProperty(DEV_ID,getdiviceid());
		if(cr.getCount()>0){
			//	Toast.makeText(context, "Ther is some value", Toast.LENGTH_SHORT).show();
			while(cr.moveToNext()){
				jsondata=new JsonObject();
				for(int i=0;i<cr.getColumnCount();i++){
					if(cr.isNull(i))
						jsondata.addProperty(cr.getColumnName(i),"");
					else{
						jsondata.addProperty(cr.getColumnName(i), cr.getString(i));
					}
				}
				jsonINArray.add(jsondata);
			}
			jsonInObj.add(DATA,jsonINArray);
			SyncServer.SyncToServerStock(context,Utils.weburl+SYNC_IN, jsonInObj);
		}else{
			jsonInObj.addProperty(DATA,"");
		}

	} catch (JsonIOException e) {
		e.printStackTrace();
	}
	Log.i("JSON ",jsonInObj.toString());
	System.out.print("JSON RESULT : " +jsonInObj.toString());
}
	
	public void SyncStockOUTRequest(){
		jsonInObj=new JsonObject();
		jsonINArray=new JsonArray();
		JsonObject jsondata=null;
		String[] select=new String[]{Sqldatabase.key_warehouse_issuestock_issueid,
				Sqldatabase.key_warehouse_issuestock_Stocktype,
				Sqldatabase.key_warehouse_issuestock_itemcode,
				Sqldatabase.key_warehouse_issuestock_lotnumber,
				Sqldatabase.key_warehouse_issuestock_batchnumber,
				Sqldatabase.key_warehouse_issuestock_RMARnumber,
				Sqldatabase.key_warehouse_issuestock_Plantid,
				Sqldatabase.key_warehouse_issuestock_OrderNumber,
				Sqldatabase.key_warehouse_issuestock_toWareHousid,
				Sqldatabase.key_warehouse_issuestock_RequiredQty,
				Sqldatabase.key_warehouse_issuestock_IssuedQty,
				Sqldatabase.key_warehouse_issuestock_IssuedTo,
				Sqldatabase.key_warehouse_issuestock_location_status,
				Sqldatabase.key_warehouse_server_stockissueID,
				Sqldatabase.key_warehouse_createdtime};
		Cursor cr=db.getdb().query(Sqldatabase.tbl_warehouse_issuestock,
				select,
				Sqldatabase.key_warehouse_syncstatus+" = ? ",
				new String[]{"0"},
				null,
				null,
				null);
			
			try {
				
				jsonInObj.addProperty(TABLE,"Stock_OUT");
				if(cr.getCount()>0){
					Toast.makeText(context, "Ther is some value", Toast.LENGTH_LONG).show();
					while(cr.moveToNext()){
						jsondata=new JsonObject();
						for(int i=0;i<cr.getColumnCount();i++){
							if(cr.isNull(i))
								jsondata.addProperty(cr.getColumnName(i),"");
							else
								jsondata.addProperty(cr.getColumnName(i), cr.getString(i));	
					}
						jsonINArray.add(jsondata);
					}
					jsonInObj.add(DATA,jsonINArray);
				}else{
					jsonInObj.addProperty(DATA,"");
				}
				
			} catch (JsonIOException e) {
				e.printStackTrace();
			}
			Log.i("JSON ",jsonInObj.toString());
			System.out.print("JSON RESULT : " +jsonInObj.toString());
	}
	
	public boolean synctoQA(){
		
		jsonInObj=new JsonObject();
		jsonINArray=new JsonArray();
		JsonObject jsondata=null;
		
		Cursor cr=db.getdb().query(Sqldatabase.tbl_Stock_QAChecklist,
				null,
				Sqldatabase.key_warehouse_syncstatus+" = ? AND NOT "+Sqldatabase.key_warehouse_server_stockID+" = ? ",
				new String[]{"0",""},
				null,
				null,
				null);
			
			try {
				jsonInObj.addProperty(TABLE,"QA");
				jsonInObj.addProperty("username",Utils.SharedPreferencesContain(context, "user"));
				jsonInObj.addProperty(DEV_ID,getdiviceid());

				if(cr.getCount()>0){
					while(cr.moveToNext()){
						jsondata=new JsonObject();
						for(int i=0;i<cr.getColumnCount();i++){
							if(cr.isNull(i))
								jsondata.addProperty(cr.getColumnName(i),"");
							else
								jsondata.addProperty(cr.getColumnName(i), cr.getString(i));	
					}
						jsonINArray.add(jsondata);
					}
					jsonInObj.add(DATA,jsonINArray); 
					SyncServer.SyncToQA(context,Utils.weburl+SYNC_IN, jsonInObj);
					
				}else{
					jsonInObj.addProperty(DATA,"");
				}
				
				
			} catch (JsonIOException e) {
				e.printStackTrace();
			}
			Log.i("JSON ",jsonInObj.toString());
			System.out.print("JSON RESULT : " +jsonInObj.toString());
			return true;
	}
	
	public void synctoLocationINRequest(){//TODO Stock Location sync by roy
		
		jsonInObj=new JsonObject();
		jsonINArray=new JsonArray();
		JsonObject jsondata=null;
		
		Cursor cr=db.getdb().query(Sqldatabase.tbl_warehouse_updatelocation,
				null,
				Sqldatabase.key_warehouse_syncstatus+" = ? AND NOT "+Sqldatabase.key_warehouse_server_stockID+" = ? ",
				new String[]{"0",""},
				null,
				null,
				null);
			
			try {
				jsonInObj.addProperty(TABLE,"Location_In");
				jsonInObj.addProperty("username",Utils.SharedPreferencesContain(context, "user"));
				jsonInObj.addProperty(DEV_ID,getdiviceid());

				if(cr.getCount()>0){
					while(cr.moveToNext()){
						jsondata=new JsonObject();
						for(int i=0;i<cr.getColumnCount();i++){
							if(cr.isNull(i))
								jsondata.addProperty(cr.getColumnName(i),"");
							else
								jsondata.addProperty(cr.getColumnName(i), cr.getString(i));	
					}
						jsonINArray.add(jsondata);
					}
					jsonInObj.add(DATA,jsonINArray); 
					SyncServer.SyncToServerLocation(context,Utils.weburl+SYNC_IN, jsonInObj);

					
				}else{
					jsonInObj.addProperty(DATA,"");
				}
				
			} catch (JsonIOException e) {
				e.printStackTrace();
			}
			Log.i("JSON ",jsonInObj.toString());
			System.out.print("JSON RESULT : " +jsonInObj.toString());
	}
	
	public void synctoIssueLocation(){
		
		jsonInObj=new JsonObject();
		jsonINArray=new JsonArray();
		JsonObject jsondata=null;
		
		Cursor cr=db.getdb().query(Sqldatabase.tbl_warehouse_update_issue_location,
				null,
				Sqldatabase.key_warehouse_syncstatus+" = ? AND NOT "+Sqldatabase.key_warehouse_server_stockissueID+" = ? ",
				new String[]{"0",""},
				null,
				null,
				null);
			
			try {
				jsonInObj.addProperty(TABLE,"IssueLocation_In");
				jsonInObj.addProperty("username",Utils.SharedPreferencesContain(context, "user"));
				jsonInObj.addProperty(DEV_ID,getdiviceid()); 
				if(cr.getCount()>0){
					while(cr.moveToNext()){
						jsondata=new JsonObject();
						for(int i=0;i<cr.getColumnCount();i++){
							if(cr.isNull(i))
								jsondata.addProperty(cr.getColumnName(i),"");
							else
								jsondata.addProperty(cr.getColumnName(i), cr.getString(i));	
					}
						jsonINArray.add(jsondata);
					}
					jsonInObj.add(DATA,jsonINArray); 
					SyncServer.SyncToServerIssueLocation(context,Utils.weburl+SYNC_IN, jsonInObj);
				}else{
					jsonInObj.addProperty(DATA,"");
				}
				
			} catch (JsonIOException e) {
				e.printStackTrace();
			}
			Log.i("JSON ",jsonInObj.toString());
			System.out.print("JSON RESULT : " +jsonInObj.toString());
	}
	
	public Boolean syncFromServerItemDetails(){
		
		jsonSyncObj=new JsonObject();
		jsonSyncArray=new JsonArray();
		JsonObject jsondata=null;
				commonRequestdatas(Sqldatabase.tbl_Items);
			
			try {
				
				jsonSyncObj.addProperty(TABLE,"itemdetails");
				jsonSyncObj.addProperty(DEV_ID,dev_id);
				jsonSyncObj.addProperty(USER_ID, "");
				jsonSyncObj.addProperty(LASTSYNC_TIME,lastsynctime);
				
			} catch (JsonIOException e) {
				e.printStackTrace();
			}
			Log.i("JSON request item",jsonSyncObj.toString());
			SyncServer.SyncFromServerItemDetails(context,Utils.weburl+SYNC_OUT, jsonSyncObj);
			return true;
	}
	
//	public boolean syncFromServerWarehouseDetails(){
//
//		jsonSyncObj=new JsonObject();
//		jsonSyncArray=new JsonArray();
//		JsonObject jsondata=null;
//				commonRequestdatas(Sqldatabase.tbl_palnts);
//
//			try {
//
//				jsonSyncObj.addProperty(TABLE,"warehouses");
//				jsonSyncObj.addProperty(DEV_ID,dev_id);
//				jsonSyncObj.addProperty(USER_ID, "");
//				jsonSyncObj.addProperty(LASTSYNC_TIME,lastsynctime);
//
//			} catch (JsonIOException e) {
//				e.printStackTrace();
//			}
//			Log.i("JSON request warehouse",jsonSyncObj.toString());
//			//SyncServer.SyncFromServerWareDetails(context,Utils.weburl+SYNC_OUT, jsonSyncObj);
//			return true;
//	}
	
	public void syncFromServerSupplierDetails(){
		
		jsonSyncObj=new JsonObject();
		jsonSyncArray=new JsonArray();
		JsonObject jsondata=null;
				commonRequestdatas(Sqldatabase.tbl_suppliers);
			
			try {
				
				jsonSyncObj.addProperty(TABLE,"suppliers");
				jsonSyncObj.addProperty(DEV_ID,dev_id);
				jsonSyncObj.addProperty(USER_ID, "");
				jsonSyncObj.addProperty(LASTSYNC_TIME,lastsynctime);
				
			} catch (JsonIOException e) {
				e.printStackTrace();
			}
			Log.i("JSON request Supplier ",jsonSyncObj.toString());
			SyncServer.SyncFromServerSupplierDetails(context,Utils.weburl+SYNC_OUT, jsonSyncObj);
			
	}
	public void synctoIssueINRequest(){ //TODO Issue Location sync by Roy
		
		jsonInObj=new JsonObject();
		jsonINArray=new JsonArray();
		JsonObject jsondata=null;
		
		Cursor cr=db.getdb().query(Sqldatabase.tbl_warehouse_issuestock,
				null,
				Sqldatabase.key_warehouse_syncstatus+" = ? ",
				new String[]{"0"},
				null,
				null,
				null); 
			
			try {
				jsonInObj.addProperty(TABLE,"Issue_In");
				jsonInObj.addProperty("username",Utils.SharedPreferencesContain(context, "user"));
				jsonInObj.addProperty(DEV_ID,getdiviceid());

				if(cr.getCount()>0){
					while(cr.moveToNext()){
						jsondata=new JsonObject();
						for(int i=0;i<cr.getColumnCount();i++){
							if(cr.isNull(i))
								jsondata.addProperty(cr.getColumnName(i),"");
							else
								jsondata.addProperty(cr.getColumnName(i), cr.getString(i));	
					}
						jsonINArray.add(jsondata);
					}
					jsonInObj.add(DATA,jsonINArray);
					SyncServer.SyncToServerIssue(context,Utils.weburl+SYNC_IN, jsonInObj);

					
				}else{
					jsonInObj.addProperty(DATA,"");
				}
				
			} catch (JsonIOException e) {
				e.printStackTrace();
			}
			Log.i("JSON ",jsonInObj.toString());
			System.out.print("JSON RESULT : " +jsonInObj.toString());
	}	
	

}
