package com.aucupa.warehouse;


import java.util.ArrayList;
import java.util.HashMap;

import com.aucupa.warehouse.sync.SyncServerRequest;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;

public class UpdateLocation extends Activity {

	LayoutInflater inflator; 
	
	LinearLayout add_layout,llstockBalance;
	HorizontalScrollView horizontalScrollView;
	
	Context context;
	
	TextView txtvstockbalance;
	
	EditText etpalletno,etrakerow,etrakecolumn,etreferenceposition,etqty,etitemcode;
	AutoCompleteTextView etwarehousename;
	
	
	ArrayList<String> WareHouseList,WareHouseidlist;
	ArrayList<HashMap<String, String>> alistitemlocationchange;
	HashMap<String, String> hm_locationdetail;
	
	String	stwarehousename,stpalletno,strakerow,strakecolumn,
	streferenceposition,stqty,stwarehouseid,ststatus=""+0,stitemcode;
	
	float stStockBalance=0,totalqtylocationchange=0,locqty;
		
	boolean stinput_flag=true,sucess_flag=true;
	
	String location_id,stserverStockid;
	long StStockid,loc_id;
	
	Sqldatabase db;
	Utils utility;
	SQLiteDatabase sdb;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_update_location);
		
		context=UpdateLocation.this;
		
		add_layout=(LinearLayout)findViewById(R.id.ullladditem);
		
		llstockBalance=(LinearLayout)findViewById(R.id.ulllstockbalance);
		horizontalScrollView=(HorizontalScrollView)findViewById(R.id.ulhrzlayout);
		
		txtvstockbalance=(TextView)findViewById(R.id.ultextqty);
		
		alistitemlocationchange=new ArrayList<HashMap<String,String>>();
		
		
		etitemcode=(EditText)findViewById(R.id.uledititemcode);
		etwarehousename=(AutoCompleteTextView)findViewById(R.id.uleditwarehousename);
		etpalletno=(EditText)findViewById(R.id.uleditpalletno);
		etrakerow=(EditText)findViewById(R.id.uleditrakerow);
		etrakecolumn=(EditText)findViewById(R.id.uleditrakecolumn);
		etreferenceposition=(EditText)findViewById(R.id.uleditrefposition);
		etqty=(EditText)findViewById(R.id.uleditqty);

		WareHouseList=new ArrayList<String>();	
		WareHouseidlist=new ArrayList<String>();
		
		db=new Sqldatabase(UpdateLocation.this);
		sdb=db.getdb();
		
		txtvstockbalance.setText(stStockBalance+"");
		

		clearAllValues();
		
		if( this.getIntent().getExtras() != null)
		{
			Bundle b=this.getIntent().getExtras();
			StStockid=b.getLong("Stock_id");
			if(StStockid<=0){
				StStockid=b.getLong("Stock_id");
				showToast(0,"No Stock Id Recieved");
			}else{
				Cursor critem=db.sqlQuery(" select "+db.key_warehouse_addstock_itemcode+","+
						db.key_warehouse_item_itemname+","+db.key_warehouse_addstock_totalquantity+","+
						db.key_warehouse_server_stockID+" from "+db.tbl_warehouse_addsock+","+db.tbl_Items+
						" where "+db.key_warehouse_item_itemcode+"="+
						db.key_warehouse_addstock_itemcode+" and "+
						db.key_warehouse_addstock_stockid+"='"+StStockid+"'");
						
					if(critem.getCount()>0){
					critem.moveToFirst();
					stitemcode=critem.getString(0);
					etitemcode.setText(critem.getString(0)+" ("+critem.getString(1)+")");
					stStockBalance=Float.parseFloat(critem.getString(2));
					stserverStockid=critem.getString(3);
					txtvstockbalance.setText(""+stStockBalance);
					
//					//for  already updates location details
//					critem=db.sqlreadwhere(db.tbl_warehouse_updatelocation, 
//							null,db.key_warehouse_updatelocation_stockid+" = ? ", 
//							new String[]{String.valueOf(StStockid)});
//					if(critem.getCount()>0){
//						location_id=critem.getString(0);
//						etpalletno.setText(critem.getString(0));
//						etrakerow.setText(critem.getString(0));
//						etrakecolumn.setText(critem.getString(0));
//						etreferenceposition.setText(critem.getString(0));
//						etqty.setText(critem.getString(0));
//					}
					
					
				}
			}
		  
		}
		
		etwarehousename.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				// TODO Auto-generated method stub
				stwarehouseid=WareHouseidlist.get(WareHouseList.indexOf(((TextView)view).getText().toString()));
			}
		});
			
}
	
	public void clicktoSave(View view){
		stinput_flag=true;
		if(etwarehousename.length()>0||etpalletno.length()>0||
				etrakerow.length()>0||etrakecolumn.length()>0||etreferenceposition.length()>0
				||etqty.length()>0){
			if(checkfullentries()){
				if(stStockBalance-(totalqtylocationchange+Float.parseFloat(etqty.getText().toString()))>0){
					showToast(0,"Total Quantity Entered is less than actual quantity");
					stinput_flag=false;
					 sucess_flag=false;
				}else{
				containerTostring();
				insertToHash();
				stinput_flag=true;
				sucess_flag=true;
				}
			}else{
				stinput_flag=false;
				sucess_flag=false;
			}
		}
		else{
			if(stinput_flag){
				if(stStockBalance-totalqtylocationchange>0){
					if(alistitemlocationchange.size()>0){
						showToast(0,"Total Quantity Entered is less than actual quantity");
						 stinput_flag=false;
						 sucess_flag=false;
					}
					
				}else{
					stinput_flag=true;
					sucess_flag=true;
				}
			}
		}
		
		HashMap< String, String> data=new HashMap<String, String>();
		
		if(stinput_flag)
		{
			if(alistitemlocationchange.size()<=0){
				showToast(0,"No Location Enter");
				sucess_flag=false;
			}
			else
			{
				for(int i=0;i<alistitemlocationchange.size();i++){
					data=alistitemlocationchange.get(i);
					ContentValues cv=new ContentValues();
					if(!(stserverStockid==null||stserverStockid.equals(""))){
						cv.put(db.key_warehouse_server_stockID,stserverStockid);
					}
					cv.put(db.key_warehouse_updatelocation_warehouseid, data.get("warehouseid"));
					cv.put(db.key_warehouse_updatelocation_itemcode,stitemcode);
					cv.put(db.key_warehouse_updatelocation_stockid, data.get("Stockid"));
					cv.put(db.key_warehouse_updatelocation_palletno, data.get("PalletNo"));
					cv.put(db.key_warehouse_updatelocation_rakerow, data.get("RakeRow"));
					cv.put(db.key_warehouse_updatelocation_rakecolumn, data.get("RakeColumn"));
					cv.put(db.key_warehouse_updatelocation_refposition, data.get("RefPosition"));
					cv.put(db.key_warehouse_updatelocation_qty, data.get("Qty"));
					cv.put(db.key_warehouse_createdtime, Utils.getSystemTimeStamp());
					cv.put(db.key_warehouse_syncstatus,"0");
					
					if(checkLocation( data.get("warehouseid"),
							 data.get("PalletNo"),
							 data.get("RakeRow"),
							 data.get("RakeColumn")))	{

						if(db.sqlins(db.tbl_warehouse_updatelocation, cv)>0){
							ContentValues cvupdate=new ContentValues();
							cvupdate.put(db.key_warehouse_addstock_location_status,""+1);
							cv.put(db.key_warehouse_createdtime, Utils.getSystemTimeStamp());
							cvupdate.put(db.key_warehouse_syncstatus, ""+0);
							if(sdb.update(db.tbl_warehouse_addsock, cvupdate,db.key_warehouse_addstock_stockid+" = ? ",
									new String[]{Integer.toString((int)StStockid)})>0){
								sucess_flag=true;
							}else{
								sucess_flag=false;
							}
						}else{
							sucess_flag=false;
						}
					}
					else{
						ContentValues cvupdateduplicate=new ContentValues();
						locqty=locqty+Float.parseFloat(data.get("Qty"));
						cvupdateduplicate.put(db.key_warehouse_updatelocation_qty, String.valueOf(locqty));
						if(sdb.update(db.tbl_warehouse_updatelocation, cvupdateduplicate,db.key_warehouse_updatelocation_locationid+" = ? ",
								new String[]{Integer.toString((int)loc_id)})>0){
							ContentValues cvupdate=new ContentValues();
							cvupdate.put(db.key_warehouse_addstock_location_status,""+1);
							cv.put(db.key_warehouse_createdtime, Utils.getSystemTimeStamp());
							cvupdate.put(db.key_warehouse_syncstatus, ""+0);
							if(sdb.update(db.tbl_warehouse_addsock, cvupdate,db.key_warehouse_addstock_stockid+" = ? ",
									new String[]{Integer.toString((int)StStockid)})>0){
								sucess_flag=true;
							}else{
								sucess_flag=false;
							}
						}else{
							sucess_flag=false;
						}
					}

					
				}
			}
		}
		
		if(sucess_flag){
			showToast(1,"Successfully Update Location");
			clearAllContainerInflaors(view);
			clearAllValues();
			alistitemlocationchange.clear();
			Intent i=new Intent(UpdateLocation.this,Viewstock.class);
			startActivity(i);
			finish();
		}

		
		
	}
	
	public boolean checkLocation(String wid,String pn,String rr,String rc){
		Cursor cr=sdb.query(db.tbl_warehouse_updatelocation,new String[]{db.key_warehouse_updatelocation_locationid,db.key_warehouse_updatelocation_qty},
				db.key_warehouse_updatelocation_warehouseid+" = ? AND "
				+db.key_warehouse_updatelocation_palletno+" = ? AND "
		+db.key_warehouse_updatelocation_rakerow+" = ? AND "
		+db.key_warehouse_updatelocation_rakecolumn+" = ? AND "
		+db.key_warehouse_updatelocation_itemcode+" = ? AND "
		+db.key_warehouse_updatelocation_stockid+" = ? "
		,new String[]{wid,pn,rr,rc,stitemcode,Integer.toString((int)StStockid)}, null, null, null);
		if(cr.getCount()>0){
			cr.moveToFirst();
			loc_id=Long.parseLong(cr.getString(0).toString());
			locqty=Float.parseFloat(cr.getString(1).toString());
			return false;
		}else{
			loc_id=0;
			locqty=0;
		}
		
		return true;
		
	}
	
	public void addNewlocation(View view){
		
		if(checkContainerentries()){
			horizontalScrollView.setVisibility(View.VISIBLE);
			inflator=(LayoutInflater)this.getSystemService(this.LAYOUT_INFLATER_SERVICE);
			View v1=inflator.inflate(R.layout.addlocation, null);
			containerTostring();
			setAddItemDetails(v1);
			add_layout.addView(v1);
			clearcontainervalues();
		}
						
	}
	
	public void setAddItemDetails(View v) {
		EditText etvwarehousename=(EditText)v.findViewById(R.id.vuleditwarehousename);
		EditText etvpalletno=(EditText)v.findViewById(R.id.vuleditpalletno);
		EditText etvrakerow=(EditText)v.findViewById(R.id.vuleditrakerow);
		EditText etvrakecolumn=(EditText)v.findViewById(R.id.vuleditrakecolumn);
		EditText etvrefpos=(EditText)v.findViewById(R.id.vuleditrefposition);
		EditText etvqty=(EditText)v.findViewById(R.id.vuleditqty);
		etvwarehousename.setText(stwarehousename);
	 	etvpalletno.setText(stpalletno);
		etvrakerow.setText(strakerow);
		etvrakecolumn.setText(strakecolumn);
		etvrefpos.setText(streferenceposition);
		etvqty.setText(stqty);
		insertToHash();
	}
	
	public void containerTostring() {
		stwarehousename=etwarehousename.getText().toString();
		stpalletno=etpalletno.getText().toString();
		strakerow=etrakerow.getText().toString();
		strakecolumn=etrakecolumn.getText().toString();
		streferenceposition=etreferenceposition.getText().toString();
		stqty=etqty.getText().toString();
		totalqtylocationchange=totalqtylocationchange+Float.parseFloat(stqty);
		stinput_flag=true;
	}

	public void Remove(View v) {
		showToast(1,"Remove");
	     ViewGroup Grandparent = (ViewGroup) v.getParent().getParent().getParent();
	     ViewGroup parent = (ViewGroup) v.getParent().getParent();
	     int pos=Grandparent.indexOfChild(parent);	
	     Grandparent.removeView(parent);
	     totalqtylocationchange=totalqtylocationchange-Float.parseFloat(alistitemlocationchange.get(pos).get("Qty").toString());
	     alistitemlocationchange.remove(pos);
	     if(Grandparent.getChildCount()<1)
	    	 horizontalScrollView.setVisibility(View.GONE);
	}
	
	public boolean checkqty(){
		if(stStockBalance<(totalqtylocationchange+Float.parseFloat(etqty.getText().toString()))){
			return false;
		}
		return true;
	}
	
	public void autoCompletefill(int status,int listnumber) {
		
		Cursor c=null;
		ArrayAdapter<String> adapter;
		
		switch (listnumber){
			case R.id.uleditwarehousename:
			WareHouseList.clear();
			WareHouseidlist.clear();
			switch (status)
			{
			case 1:
				c=sdb.query(true,db.tbl_warehouse_no,null,null,
						null,null,null,null,null);
				
				break;
			default:break;
			}
			if(c.getCount()>0){
				while (c.moveToNext()) {
				WareHouseList.add(c.getString(1));
				WareHouseidlist.add(c.getString(0));
			}
				adapter =new ArrayAdapter<String>(UpdateLocation.this,R.layout.autolistview,WareHouseList);
				etwarehousename.setAdapter(adapter);
		}
			break;
		}
	}
	
	public void clearAllValues(){
		etitemcode.setText("");
		stStockBalance=0;
		totalqtylocationchange=0;
		txtvstockbalance.setText(stStockBalance+"");
		WareHouseList.clear();
		clearcontainervalues();
	}
	
	public void clearAllContainerInflaors(View v)   ///check all child and parent in this function 30/4/2016
	{
		//find lay out from view
		clearcontainervalues();
		ViewGroup parent=(ViewGroup) v.getParent().getParent();
		String itcode="";
		ViewGroup Childsrollview=(ViewGroup) parent.getChildAt(2);
		ViewGroup linearview0=(ViewGroup) Childsrollview.getChildAt(0);
		ViewGroup linearview=(ViewGroup) linearview0.getChildAt(1);
		int i=0;
		while(i<linearview.getChildCount())
		{
			
			
			ViewGroup container=(ViewGroup) linearview.getChildAt(i);
			linearview.removeView(container);
		}
		
		horizontalScrollView.setVisibility(View.GONE);
	}
	
	public void clearcontainervalues(){
		etwarehousename.setText("");
		autoCompletefill(1,R.id.uleditwarehousename);
		etpalletno.setText("");
		etrakerow.setText("");
		etrakecolumn.setText("");
		etreferenceposition.setText("");
		etqty.setText("");
		//containerTostring();
	}

	
	public void insertToHash(){

		try {
			hm_locationdetail=new HashMap<String, String>();
		hm_locationdetail.put("warehouseid",String.valueOf(stwarehouseid));
		hm_locationdetail.put("Stockid",String.valueOf(StStockid));
		hm_locationdetail.put("PalletNo",stpalletno);
		hm_locationdetail.put("RakeRow",strakerow);
		hm_locationdetail.put("RakeColumn",strakecolumn);
		hm_locationdetail.put("RefPosition",streferenceposition);
		hm_locationdetail.put("Qty",stqty);
			
			alistitemlocationchange.add(hm_locationdetail);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public boolean checkfullentries(){
		if(checkContainerentries()){

			return true;
		}else{
				return false;
			}
				
	}
	
	public boolean checkContainerentries(){
	
		if(etwarehousename.length()>0){
			if(db.sqlreadwhere(db.tbl_warehouse_no,null,
					db.key_warehouse_no_plantno+" = ? ",new String[]{etwarehousename.getText().toString()}).getCount()>0){
				if(etpalletno.length()>0){
					if(etrakerow.length()>0){
						if(etrakecolumn.length()>0){
								if(etqty.length()>0){
									if(Float.parseFloat(etqty.getText().toString())!=0){

										if(checkqty()){
											return true;
									}else{
										showToast(0,"Insufficient Stock");
										return false;
									}
									}else{
										showToast(0,"Quantity must greater than 0");
										return false;
									}
								}else{
									showToast(0,"Enter Quantity");
									return false;
								}
							}else{
								showToast(0,"Enter Rake Column");
							return false;
						}
					}else{
						showToast(0,"Enter Rake Row");
						return false;
					}
				}else{
					showToast(0,"Enter Pallet Number");
					return false;
				}
		}else{
			showToast(0,"WareHouse Not Found");
			return false;
			}
		}else{
			showToast(0,"Enter WareHouse Name");
			return false;
		}		
	}
	
	 public void showToast(int a,String t)
     { 
     	 try {
     		 LayoutInflater inflater = getLayoutInflater();
     		 View layout = inflater.inflate(R.layout.successtoat,
     		                                (ViewGroup) findViewById(R.id.ll_custoast_parent));

     		 ImageView image = (ImageView) layout.findViewById(R.id.ll_custoast_iv);
     		 if(a==1) image.setImageResource(R.drawable.greentick);		 
     		 else image.setImageResource(R.drawable.attentionred);			 
     		 TextView text = (TextView) layout.findViewById(R.id.ll_custoast_msg);
     		 text.setText(t);
     		 Toast toast = new Toast(getApplicationContext());
     		 toast.setGravity(Gravity.FILL_HORIZONTAL|Gravity.BOTTOM | Gravity.CENTER_VERTICAL, 0, 0);
     		 toast.setDuration(Toast.LENGTH_SHORT);
     		 toast.setView(layout);
     		 toast.show();
     	} catch (Exception e1) {
     		// TODO Auto-generated catch block
     		e1.printStackTrace();
     	} 
     }
	
	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		super.onBackPressed();
		Intent i1 =new Intent(getApplicationContext(),Select_Activity.class);
		i1.putExtra("syncstatus",true);
		startActivity(i1);
		finish();
	}
}
