package com.aucupa.warehouse.adapter;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.TextView;

import com.aucupa.warehouse.R;
import com.aucupa.warehouse.Sqldatabase;

public class Stock_adapter extends CursorAdapter{
    TextView itemcode,lotno,stockid,quantity;
    String itemcode1,lotno1,stockid1,quantity1,itemname,item,sync_status;


    public Stock_adapter(Context context, Cursor c) {
        super(context, c);
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup viewGroup) {
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        View view = layoutInflater.inflate(R.layout.viewstocklist,null);
        return view;
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {
        stockid=(TextView)view.findViewById(R.id.txt_stockid);
        itemcode=(TextView)view.findViewById(R.id.txt_itemcode);
        lotno=(TextView)view.findViewById(R.id.txt_lotno);
        quantity=(TextView)view.findViewById(R.id.txt_totalquantity);

        stockid1=cursor.getString(cursor.getColumnIndexOrThrow("_id"));
        itemname=cursor.getString(cursor.getColumnIndexOrThrow("ItemId"));
        itemcode1=cursor.getString(cursor.getColumnIndexOrThrow("ItemCode"));
        lotno1=cursor.getString(cursor.getColumnIndexOrThrow("LotNumber"));
        quantity1=cursor.getString(cursor.getColumnIndexOrThrow("TotalQuantity"));
        sync_status=cursor.getString(cursor.getColumnIndexOrThrow("error_sync"));
        Sqldatabase db=new Sqldatabase(context);
        Cursor c1=db.getItemname(itemname);
        if(c1.moveToNext())
        {
            item=c1.getString(2).toString();
        }

            stockid.setText(item);
            itemcode.setText(itemcode1);
            lotno.setText(lotno1);
            quantity.setText(quantity1);


    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = super.getView(position, convertView, parent);
        if(sync_status.equals("502"))
        {
            view.setBackgroundColor(Color.RED);
        }
        else
        {
            view.setBackgroundColor(Color.LTGRAY);

            if (position % 2 == 1)
            {
                view.setBackgroundColor(Color.parseColor("#ff666666"));
            }
            else
            {
                view.setBackgroundColor(Color.parseColor("#ff999999"));
            }
        }
        return view;
    }
}


