package com.aucupa.warehouse;

import com.aucupa.warehouse.sync.SyncServerRequest;

import android.app.Application;
import android.content.Context;

public class WhApp extends Application{
	 public  SyncServerRequest syncRequest;
	 public Sqldatabase sql;
	 public Context context;
 	
	@Override
	public void onCreate() {
		super.onCreate();
		syncRequest=new SyncServerRequest(getApplicationContext());
		sql=new Sqldatabase(getApplicationContext());
		context=getApplicationContext();
	}

}
