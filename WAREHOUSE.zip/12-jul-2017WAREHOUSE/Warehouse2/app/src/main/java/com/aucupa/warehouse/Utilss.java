package com.aucupa.warehouse;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.provider.Settings.Secure;
import android.util.Log;
import android.view.inputmethod.InputMethodManager;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import static com.aucupa.warehouse.Utils.WarehouseUsernameidFromServer;

public class Utilss {


    static Context context;

    //public static String weburl = "http://aucupa.com/plcwh/";
    //public static String weburl = "http://proctore.com/plc/wh/";

    public static String weburl = "http://sellowa.com/proctore/";
    //public static String weburl="http://localhost/proctore";

    private static String offlinelogin;


    private static String offname;


    private static String offpass;


    Utilss(Context con) {
        context = con;
    }

    public static String getSystemTimeStamp() {
        return String.valueOf(System.currentTimeMillis());
    }

    public static String getDeviceid() {
        return Secure.getString(context.getContentResolver(), Secure.ANDROID_ID);
    }

    //////////////////////////// POST DATA TO SERVER

    public static String postDataToServer(String pagename, ContentValues postcontents) {


        try {
            String u = weburl + pagename;
            Log.i("url", u + "" + pagename);
            org.apache.http.client.HttpClient cl = new DefaultHttpClient();
            org.apache.http.client.methods.HttpPost req = new org.apache.http.client.methods.HttpPost(u);


            List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(
                    postcontents.size());
            Set<Entry<String, Object>> t = postcontents.valueSet();
            for (Entry<String, Object> entry : t) {

                nameValuePairs.add(new BasicNameValuePair(entry.getKey()
                        .toString(), entry.getValue().toString()));
            }
            req.setEntity(new UrlEncodedFormEntity(nameValuePairs));
            HttpResponse resp = cl.execute(req);
            Log.i("http post request`", req.getURI().getPath().toString());
            BufferedReader reader = new BufferedReader(new InputStreamReader(resp.getEntity().getContent()));
            if (reader != null) {
                StringBuilder sb = new StringBuilder();

                String line = null;
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
                Log.d("post_response", sb.toString());
                return sb.toString();
            }
            Log.d("post_response null", reader.readLine() + " ");
        } catch (Exception e) {
            Log.d("@utils.unamepswd", e.toString());

        }
        return "";
    }
    public static String trimName(String s,int c)
    {
        if(s.length()>c)
        {	s=s.substring(0,c-3);

        }
        return s;
    }

    public static String SharedPreferencesContain(Context contect, String key) {

        SharedPreferences myPrefs = contect.getSharedPreferences("myPrefs",
                Context.MODE_WORLD_READABLE);
        return myPrefs.getString(key, null);


    }


    public static void setSharedPreferences(Context contect, String key,
                                            String Value) {

        final String id = Value;


        SharedPreferences myPrefs = contect.getSharedPreferences("myPrefs",
                Context.MODE_WORLD_READABLE);

        SharedPreferences.Editor prefsEditor = myPrefs.edit();

        prefsEditor.putString(key, id);
        prefsEditor.commit();

    }


    public static boolean CheckNet(Context context)
    {
        boolean haveConnectedWifi = false;
        boolean haveConnectedMobile = false;


        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo[] netInfo = cm.getAllNetworkInfo();
        for (NetworkInfo ni : netInfo) {
            if (ni.getTypeName().equalsIgnoreCase("WIFI"))
                if (ni.isConnected())
                    haveConnectedWifi = true;
            if (ni.getTypeName().equalsIgnoreCase("MOBILE"))
                if (ni.isConnected())
                    haveConnectedMobile = true;
        }


        return haveConnectedWifi || haveConnectedMobile;
    }
    public static void tableUnamePassword(String name, String password)
    {
        // TODO Auto-generated method stub

        Log.v("REACH IN ", "table creation");

        Sqldatabase db=new Sqldatabase(context);
        SQLiteDatabase sqlite=db.getdb();
        String sql="insert or replace into "+
                db.tbl_mobile_userOffline+" values (?,?,?)";
        sqlite.execSQL(sql, new String[]{
                null,
                name,
                password});


    }
    public static String setRegDetailFromServer(Context context,
                                                String GroupId, String username, String password, String DeviceId) {

        System.out.print("WAREHOUSE REGISTER  SERVER INSERT");


        JSONArray jsonarray = null;
        JSONObject json = null;
        String resfrmserver = "";
        String res = null;
        jsonarray = new JSONArray();
        json = new JSONObject();

        try {

            json.put("table", "WarehouseDevices");
            json.put("Organization_Id", GroupId);
            json.put("username", username);
            json.put("password", password);
            json.put("Device_Id", DeviceId);
            jsonarray.put(json);

            System.out.println(json);

            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost(weburl + "sync_outs");
            StringEntity se = new StringEntity(jsonarray.toString());
            httppost.setEntity(se);
            httppost.setHeader("Accept", "application/json");
            httppost.setHeader("Content-type", "application/json");
            // Execute HTTP Post Request
            // System.out.println(json.toString());
            HttpResponse response = httpclient.execute(httppost);
            // ***************************************************************************//*
            InputStream is2 = response.getEntity().getContent();
            BufferedReader reader = new BufferedReader(new InputStreamReader(is2));
            StringBuilder sb = new StringBuilder();
            String line = null;

            try {
                while ((line = reader.readLine()) != null) {
                    sb.append(line + "\n");
                }



                res= sb+"";



                Log.i("response set Registration details", sb.toString());
                //	Utility.appendLog("set down time table from server response : "+ sb.toString());

            } catch (IOException e) {
                e.printStackTrace();

            }
            // ***************************************************************************//*
            response = httpclient.execute(httppost);

        }
        catch (JsonParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            resfrmserver="registrationfailed";
            res = resfrmserver;
        } catch (UnsupportedEncodingException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            resfrmserver="registrationfailed";
            res = resfrmserver;
        } catch (ClientProtocolException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            resfrmserver="registrationfailed";
            res = resfrmserver;
        } catch (IllegalStateException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            resfrmserver="registrationfailed";
            res = resfrmserver;
        } catch (JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            resfrmserver="registrationfailed";
            res = resfrmserver;
        } catch (IOException e) {
            // TODO Auto-generated catch block
            resfrmserver="registrationfailed";
            res = resfrmserver;
            e.printStackTrace();
        }

        return res;

    }
/////////////////////////// WARE SUPER VISOR SERVER


    public static  void setSuperVisorTableFromServer(Context context){

        System.out.print(" WARE SUPER VISOR SERVER");

        // Log.i("setItemReportTableFromServer", "setItemReportTableFromServer");
        JSONArray jsonarray = null;
        JSONObject json = null;
        jsonarray = new JSONArray();
        json = new JSONObject();
        try {

            json.put("table", "MobileUsers");
            jsonarray.put(json);
            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost(weburl + "sync_outs");
            StringEntity se = new StringEntity(jsonarray.toString());
            httppost.setEntity(se);
            httppost.setHeader("Accept", "application/json");
            httppost.setHeader("Content-type", "application/json");
            // Execute HTTP Post Request
            System.out.println(json.toString());
            HttpResponse response = httpclient.execute(httppost);
            System.out.println(response.getStatusLine());
            Sqldatabase db=new Sqldatabase(context);
            SQLiteDatabase sqlite=db.getdb();

            if (response != null) {
                InputStream is = response.getEntity().getContent();


                JsonFactory fact=new JsonFactory();


                JsonParser par=fact.createParser(is);
                //	        System.out.println(par.toString());
                par.nextToken();
                while (par.nextToken() != JsonToken.END_ARRAY) {

                    String id="",name="";
                    while (par.nextToken() != JsonToken.END_OBJECT) {

                        String namefield = par.getCurrentName();
                        //             System.out.println(namefield);
                        par.nextToken(); // move to value
                        if (Sqldatabase.key_mobileuser_id.equals(namefield)) {
                            id=par.getText();
                        }else if(Sqldatabase.key_mobileuser_name.equals(namefield)){
                            name=par.getText();
                        }


                    }
                    String sql="insert or replace into "+Sqldatabase.tbl_mobile_user+" values (?,?)";
                    sqlite.execSQL(sql, new String[]{id,name});


                }

            }

        } catch (Exception e) {
            e.printStackTrace();


        }
    }


    ///////////////////////////////////  WAREHOUSE LOG_IN SERVER INSERT

    public static String loggingSuperviser(Context context, String name, String pass) {

        System.out.print("WAREHOUSE LOG_IN SERVER INSERT");

        JSONArray jsonarray = null;
        JSONObject json = null;
        String resfrmserver = "";
        String res = null;
        jsonarray = new JSONArray();
        json = new JSONObject();

        try {


            json.put("table", "MobileuserLogin");
            json.put("username", name);
            json.put("password", pass);

            jsonarray.put(json);

            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost(weburl + "sync_outs");
            StringEntity se = new StringEntity(jsonarray.toString());
            httppost.setEntity(se);
            httppost.setHeader("Accept", "application/json");
            httppost.setHeader("Content-type", "application/json");
            // Execute HTTP Post Request
            // System.out.println(json.toString());
            HttpResponse response = httpclient.execute(httppost);
            // ***************************************************************************//*
            InputStream is2 = response.getEntity().getContent();
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    is2));
            StringBuilder sb = new StringBuilder();
            String line = null;

            try {
                while ((line = reader.readLine()) != null) {
                    sb.append(line + "\n");
                }


                res= sb+"";

                Log.i("response set Registration details", sb.toString());
                //	Utility.appendLog("set down time table from server response : "+ sb.toString());

            } catch (IOException e) {
                e.printStackTrace();

            }
            // ***************************************************************************//*
            response = httpclient.execute(httppost);


        } catch (JsonParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            resfrmserver="registrationfailed";
        } catch (UnsupportedEncodingException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            resfrmserver="registrationfailed";
        } catch (ClientProtocolException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            resfrmserver="registrationfailed";
        } catch (IllegalStateException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            resfrmserver="registrationfailed";
        } catch (JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            resfrmserver="registrationfailed";
        } catch (IOException e) {
            // TODO Auto-generated catch block
            resfrmserver="registrationfailed";
            e.printStackTrace();
        }

        WarehouseUsernameidFromServer(context);

        return res;


    }
    public static  String WarehouseUsernameidFromServer(Context context){

        System.out.print("AssignedwarehouseUsername");



        Sqldatabase db = new Sqldatabase(context);
        JSONArray jsonarray = null;
        JSONObject json = null;
        jsonarray = new JSONArray();
        json = new JSONObject();
        String id="" ;
        String responcess = "Success";
        String tbl = "Assign_WareHouse";

// db.sqlQuery("DELETE TABLE "+tbl);

        try {


            json.put("table", "AssignedwarehouseUsername");

            jsonarray.put(json);
            System.out.print(json);


            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost(weburl + "sync_outs");
            StringEntity se = new StringEntity(jsonarray.toString());
            httppost.setEntity(se);
            httppost.setHeader("Accept", "application/json");
            httppost.setHeader("Content-type", "application/json");
// Execute HTTP Post Request
            System.out.println(json.toString());
            HttpResponse response = httpclient.execute(httppost);
            System.out.println(response.getStatusLine());
// Sqldatabase db=new Sqldatabase(context);
            SQLiteDatabase sqlite=db.getdb();

            sqlite.delete("Assign_WareHouse", null, null);

            if (response != null) {
                InputStream is = response.getEntity().getContent();
                JsonFactory fact=new JsonFactory();
                JsonParser par=fact.createParser(is);
                System.out.println(par.toString());
                par.nextToken();
                while (par.nextToken() != JsonToken.END_ARRAY) {
                    String warid="",warnameid ="",aid = "";
                    while (par.nextToken() != JsonToken.END_OBJECT) {

                        String namefield = par.getCurrentName();
//System.out.println(namefield);
                        par.nextToken(); // move to value
                        if ("warehouse_id".equals(namefield)) {
                            warid=par.getText();
                        }else if("enduser_id".equals(namefield)){
                            warnameid=par.getText();
                        }else if("id".equals(namefield)){
                            aid=par.getText();
                        }

                    }

                    String sqlw="insert or replace into "+Sqldatabase.tbl_assign_warehouse+" values (?,?,?)";
                    sqlite.execSQL(sqlw, new String[]{aid,warid,warnameid});

                }

            }

        } catch (Exception e) {
            e.printStackTrace();


        }
        return responcess;
    }
//    public static boolean Dailysync(Context context,String offlineuser,String offlinepass) {
//
//        long currenttime_stamp;
//        Sqldatabase db = new Sqldatabase(context);
//        Calendar calendar = Calendar.getInstance();
//        currenttime_stamp = calendar.getTimeInMillis();
//        SQLiteDatabase sqlite=db.getdb();
//
//        try {
////            if (Utils.CheckNet(context)==true) {
////                String respon=Utils.setWarehouseTable(context);//get all Assigned Warehouses
////            }
////
////            if (Utilss.CheckNet(context)==true) {
////                Utilss.getAllWareHouseName(context);//get all warehouses
////            }
//
////            if(Utils.CheckNet(context)==true){
////                Utils.insertplants(context); // INSERT PLANTS FROM SERVER
////            }
//
//            if(Utilss.CheckNet(context)==true){
//               // Utilss.offlineTableCreate(offlineuser, offlinepass, context);
//            }
//
//            if(Utilss.CheckNet(context)==true){
//
////			sqlite.delete(db.tbl_warehouse_in+" WHERE '"+db.key_warehouse_in_expdatetimestamp+"' < '"+currenttime_stamp+"'",null,null);
////			sqlite.delete(db.tbl_warehouse_out+" WHERE '"+db.key_warehouse_out_timestamp+"' < '"+currenttime_stamp+"'",null,null);
//            }
//
//
//
//
//            //Utilss.offlineTableCreate(offlineuser, offlinepass, context);
//
//        } catch (Exception e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//        return true;
//    }
//    /*** get all ware house datas from database**/
    public static void getAllWareHouseName(Context context){
        System.out.print("warehouseUsername");



        Sqldatabase db = new Sqldatabase(context);
        JSONArray jsonarray = null;
        JSONObject json = null;
        jsonarray = new JSONArray();
        json = new JSONObject();
        String id="" ;
        String responcess = "Success";
        String tbl = "Warehouses";


        try {


            json.put("table", "warehouses");
            jsonarray.put(json);
            System.out.print(json);


            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost(weburl + "sync_outs");
            StringEntity se = new StringEntity(jsonarray.toString());
            httppost.setEntity(se);
            httppost.setHeader("Accept", "application/json");
            httppost.setHeader("Content-type", "application/json");
            // Execute HTTP Post Request
            System.out.println(json.toString());
            HttpResponse response = httpclient.execute(httppost);
            System.out.println(response.getStatusLine());
            // Sqldatabase db=new Sqldatabase(context);
            SQLiteDatabase sqlite=db.getdb();

            sqlite.delete(db.tbl_warehouse_no, null, null);

            if (response != null) {
                InputStream is = response.getEntity().getContent();
                JsonFactory fact=new JsonFactory();
                JsonParser par=fact.createParser(is);
                System.out.println(par.toString());
                par.nextToken();
                while (par.nextToken() != JsonToken.END_ARRAY) {
                    String warid="",warname="";
                    while (par.nextToken() != JsonToken.END_OBJECT) {

                        String namefield = par.getCurrentName();
                        par.nextToken();
                        if ("id".equals(namefield)) {
                            warid=par.getText();
                        }else if("warehouse_no".equals(namefield)){
                            warname=par.getText();
                        }
                    }

                    String sqlw="insert or replace into "+Sqldatabase.tbl_warehouse_no+" values (?,?)";
                    sqlite.execSQL(sqlw, new String[]{warid,warname});

                }

            }

        } catch (Exception e) {
            e.printStackTrace();


        }

 }

//    public static String postStockTable(Context context) {
//        String status="";
//        JSONArray jsonarray = null;
//        JSONObject json = null;
//        Sqldatabase db = new Sqldatabase(context);
//        Cursor cs = null;
//        boolean state=false;
//        cs = db.sqlQuery("select * from " + db.tbl_warehouse_addsock + " where "+db.key_warehouse_syncstatus+" = '1'");
//        cs.moveToFirst();
//        if (cs.getCount()>0)
//        {
//            cs.moveToFirst();
//            jsonarray = new JSONArray();
//            json = new JSONObject();
//            try {
//                json.put("Table", "StockDetails");
//                json.put("Username", Utils.SharedPreferencesContain(context, "user"));
//                json.put("Device_id", Utils.SharedPreferencesContain(context, "Div_id"));
//                jsonarray.put(json);
//            } catch (JSONException e1) {
//                // TODO Auto-generated catch block
//                e1.printStackTrace();
//            }
//            jsonarray.put(json);
//            while (cs.isAfterLast() == false) {
//
//                try {
//                    json = new JSONObject();
//                    for (int i = 0; i < cs.getColumnCount(); i++)
//                        json.put(cs.getColumnName(i), cs.getString(i));
//                    jsonarray.put(json);
//                    cs.moveToNext();
//
//                }
//                catch (Exception e) {
//                    Log.d("Android", "JSON Error");
//                }
//                cs.moveToNext();
//            }
//            try {
//                Log.d("Jarray", jsonarray.toString());
//                HttpClient httpclient = new DefaultHttpClient();
//                HttpPost httppost = new HttpPost(weburl + "sync_ins");
//                StringEntity se = new StringEntity(jsonarray.toString());
//                httppost.setEntity(se);
//                httppost.setHeader("Accept", "application/json");
//                httppost.setHeader("Content-type", "application/json");
//                System.out.print(json);
//                HttpResponse response = httpclient.execute(httppost);
//                if (response != null) {
//                    InputStream is = response.getEntity().getContent();
//                    JsonFactory fact=new JsonFactory();
//                    JsonParser par=fact.createParser(is);
//                    System.out.println(par.toString());
//                    par.nextToken();
//                    while (par.nextToken() != JsonToken.END_ARRAY) {
//
//                        while (par.nextToken() != JsonToken.END_OBJECT) {
//                            String namefield = par.getCurrentName();
//                            par.nextToken();
//                            if ("status".equals(namefield))
//                            {
//                                status=par.getText();
//                                return status;
//                            }
//                        }
//
//                    }
//
//                }
//            }
//            catch (Exception e) {
//                e.printStackTrace();
//            }
//
//        }
//        try {
//            cs.close();
//            db.sqlclose();
//        } catch (Exception e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//
//        return status;
//    }
//    public static String offlinePasswordselection(String offlinepass, String offlineuser,Context context) {
//
//        Sqldatabase db=new Sqldatabase(context);
//        SQLiteDatabase sqlite=db.getdb();
//        Cursor cs = null;
//
//        String Tname = db.tbl_mobile_userOffline;
//
//        cs = db.sqlQuery("select *  from " +db. tbl_mobile_userOffline  + " where " + db.key_mobileuserOffline_uname+ " = '" +offlineuser+"'" );
//
//        if(cs.getCount()>0){
//
//            cs.moveToFirst();
//
//            while(cs.isAfterLast()==false){
//
//                offname = cs.getString(cs.getColumnIndex("enduser_username"));
//                offpass =cs.getString(cs.getColumnIndex("enduser_password"));
//
//                System.out.println(offname);
//                System.out.println("man from now ware");
//
//                cs.moveToNext();
//            }
//        }
////	else{
////
////		offlinelogin = "nullvalue";
////
////	}
//
//        if(offlinepass.equalsIgnoreCase(offpass)&&offlineuser.equalsIgnoreCase(offname))
//        {
//
//            offlinelogin = "Sucess";
//
//        }
//        else {
//
//            return	offlinelogin = "Faild";
//
//        }
//        return offlinelogin;
//    }
//    public static  void offlineTableCreate(String offlinepass, String offlineuser,Context context) {
//        // TODO Auto-generated method stub
//
//
//        Sqldatabase dbp = new Sqldatabase(context);
//        SQLiteDatabase sqlitep = dbp.getdb();
//
//        String sql="insert or replace into "+Sqldatabase.tbl_mobile_userOffline+" values (?,?,?)";
//        sqlitep.execSQL(sql, new String[]{null,offlinepass,offlineuser});
//
//
//    }
    public static void hideSoftKeyboard(Activity activity)
    {
        InputMethodManager inputMethodManager = (InputMethodManager)  activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), 0);
    }
}