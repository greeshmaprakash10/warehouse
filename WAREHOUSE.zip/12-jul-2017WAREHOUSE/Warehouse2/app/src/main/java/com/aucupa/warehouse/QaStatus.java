package com.aucupa.warehouse;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import com.aucupa.warehouse.adapter.QaListAdapter;

public class QaStatus extends Activity {
    ListView qaList;
    QaListAdapter adapter;
    String qa_status,sync;
    String name, id,lotno,qastatus,spec,remark,createdtime,qastart,qaupdate,stockid,comment;
    ProgressDialog conectingDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qa_status);

        qaList = (ListView) findViewById(R.id.qa_list);
        ImageButton referesh=(ImageButton)findViewById(R.id.referesh);
        Sqldatabase db = new Sqldatabase(QaStatus.this);
        Cursor c = db.getqaDetails();
        adapter = new QaListAdapter(getApplicationContext(), c);
        qaList.setAdapter(adapter);
        referesh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Utils.CheckNet(getApplicationContext()))
                {
                    showConnectingProgreesDialog(QaStatus.this,true,"Syncing.....");
                    new Thread()
                    {
                        public void run()
                        {
                            Sqldatabase db=new Sqldatabase(QaStatus.this);
                            SharedPreferences sharedPreferences=getSharedPreferences("sample",MODE_PRIVATE);
                            name=sharedPreferences.getString("username","");
                            Cursor c1=db.getMobileuser(name);
                            if(c1.moveToNext()){
                                id=c1.getString(c1.getColumnIndex("enduser_id"));
                            }
                            db.postqaDetails(getApplicationContext(),"wh_qa",id);
                            db.getUpdateFromServerQa(getApplicationContext());
                        }
                    }.start();
                    updateQA();
                    finish();
                    startActivity(getIntent());
                }
            }
        });
        qaList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                final String id = String.valueOf(adapter.getItemId(i));
                Sqldatabase db=new Sqldatabase(QaStatus.this);
                Cursor c=db.getqaDetails(id);
                if(c.moveToNext())
                {
                    qa_status=c.getString(c.getColumnIndex("qa_status"));
                    if(qa_status.equals("1"))
                    {
                        Intent ne=new Intent(QaStatus.this,QaAddStock.class);
                        ne.putExtra("item",id);
                        startActivity(ne);
                        return;
                    }
                    else{
                        Toast.makeText(getApplicationContext(),"Qa Status is Pending ",Toast.LENGTH_LONG).show();
                        return;
                    }

                }



            }
        });
    }

    @Override
    public void onBackPressed() {
        Intent i=new Intent(QaStatus.this,Select_Activity.class);
        startActivity(i);
    }
    public void updateQA()
    {
        Sqldatabase db=new Sqldatabase(QaStatus.this);
        Cursor c2=db.getqaupdateDetails();
        int count=c2.getCount();
        for(int i=0;i<count;i++)
        {
            if(c2.moveToNext())
            {
                lotno=c2.getString(3);
                qastatus=c2.getString(11);
                spec=c2.getString(6);
                remark=c2.getString(7);
                comment=c2.getString(8);
                createdtime=c2.getString(13);
                qastart=c2.getString(9);
                qaupdate=c2.getString(14);
                stockid=c2.getString(12);
                sync="1";
            }
            db.updateqaDetails(lotno,qastatus,spec,remark,comment,createdtime,qastart,qaupdate,stockid,sync);

        }
    }
    public void showConnectingProgreesDialog(Context context, Boolean show, String Message)
    {

        if(show) {
            conectingDialog=new ProgressDialog(context);
            conectingDialog.setMessage(Message);
            conectingDialog.setCancelable(false);
            conectingDialog.show();

            System.out.println("Shown dialog");
        } else {
            conectingDialog.cancel();
        }

    }
}
