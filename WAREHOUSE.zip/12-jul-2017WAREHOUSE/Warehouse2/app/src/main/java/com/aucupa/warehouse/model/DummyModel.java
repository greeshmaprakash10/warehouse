package com.aucupa.warehouse.model;

public class DummyModel {
	
	private long mId;
	private String mImageURL,stock_id,server_stock_id,loc_status;
	private String fletter,itemname,qty;

	public DummyModel() { 
	} 
  
	public DummyModel(long id, String imageURL,String letter, String name, String itemqty,String stockid,String loc_status) {
		mId = id;
		mImageURL = imageURL; 
		fletter = letter;
		itemname=name;
		qty = itemqty;
		stock_id=stockid;
		this.loc_status=loc_status;
	}
   
	public long getId() {
		return mId;
	}

	public void setId(long id) {
		mId = id;
	}


	public String getText() {
		return fletter;
	}

	public void setText(String text) {
		fletter = text;
	}
	public String getItemname() {
		return itemname;
	}

	public void setItemname(String name) {
		itemname = name;
	}
	public String getItemqty() {
		return qty;
	}
	public String getlocstatus() {
		return loc_status;
	}
	public String getserverstockid(){
		return server_stock_id;
	}

	public void setItemqty(String iconRes) {
		qty = iconRes;
	}

	@Override
	public String toString() {
		return fletter;
	}
	public String getStockid() {
		return stock_id;
	}
}
