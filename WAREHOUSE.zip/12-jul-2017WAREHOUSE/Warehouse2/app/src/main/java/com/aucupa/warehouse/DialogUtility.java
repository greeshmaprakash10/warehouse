package com.aucupa.warehouse;

import android.app.ProgressDialog;
import android.content.Context;

public class DialogUtility {
	private  static ProgressDialog dialog;
	
	public static void DialogManage(Context context,int key){
		
		if(dialog==null){
			dialog=new ProgressDialog(context);
		}
			if(dialog.isShowing()&&key==0){
				dialog.dismiss();
			}
			else
			{
				if(dialog.isShowing()&&key==1){
					
				}else{
					try {
						dialog.setMessage("Syncing...");
						dialog.show();
						dialog.setCancelable(false);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
			}
	}
		

}
