package com.aucupa.warehouse;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.aucupa.warehouse.sync.SyncServerRequest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
public class Login extends Activity {
	ProgressDialog syncProgressDialog;
	Context context;
	EditText etUsername,etPassword;
	String stUsername,stPassword,response,name,password;
	private Handler mHandler ;
	ContentValues cv;
	ProgressBar bar;
	Sqldatabase db ;
	Spinner sp1;
	Utils utils;
	TextView network,txtuser,backupbutton,qaNotification;
	private String offlineResponce;
	private String offlineuser;
	private String offlinepass;
	private int key=0;
	String label;
	SyncServerRequest synctoserverRequest;
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.loginlayout);
		this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		context=this;
		db = new Sqldatabase(this);
		txtuser=(TextView)findViewById(R.id.txt_123456);
		synctoserverRequest=((WhApp)getApplication()).syncRequest;
		mHandler = new Handler();
		etPassword=(EditText) findViewById(R.id.et_login_password);
		sp1= (Spinner) findViewById(R.id.sp_login_username);
		backupbutton=(TextView)findViewById(R.id.backup);
		List_Warehouse list_Warehouse  = new List_Warehouse();
		boolean flage = true;
		if(checkGroupIdExist()==true)  // check the group id has set in the local db
		{
			try {
				OfflineImportSupervisor();
				if(Utilss.CheckNet(context)==true)
				{
					new	ImportSupervisorNames().execute("");
				}
				else if(Utilss.CheckNet(context)==false)
				{
					showToast(0,"Network Connectivity requered");
					OfflineImportSupervisor();
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		try {
			stUsername=Utilss.SharedPreferencesContain(context, "Username");
			stPassword=Utilss.SharedPreferencesContain(context, "Password");
			if(stUsername.length()>0)
			{
				etUsername.setText(stUsername);
				etPassword.setText(stPassword);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		backupbutton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				AlertDialog.Builder builder = new AlertDialog.Builder(Login.this);
				builder.setCancelable(true);
				builder.setTitle("Backup");
				builder.setInverseBackgroundForced(false);
				builder.setCancelable(false);
				builder.setMessage("Do you want to backup your DB ?");

				final EditText input=new EditText(Login.this);
				LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
				input.setLayoutParams(lp);
				input.setHint("Backup Auth CODE");
				input.setInputType(InputType.TYPE_NUMBER_VARIATION_PASSWORD);
				builder.setView(input);

				builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int arg1) {
						try {
							if(input.length()>0){
								if(input.getText().toString().equals("12345")){
									new BackupAppAct().backupAppSQLite(Login.this,"com.aucupa.warehouse",Sqldatabase.database_name);
									Toast.makeText(getApplicationContext(), "BACKUP Successfull", Toast.LENGTH_SHORT).show();
									dialog.dismiss();
								}else{
									Toast.makeText(getApplicationContext(),
											"Invalid Auth. Code ! Backup Failed",
											Toast.LENGTH_SHORT).show();
								}
							}else{
								Toast.makeText(getApplicationContext(),
										"Can't backup DB without Backup Auth. Code",
										Toast.LENGTH_SHORT).show();
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
					}

				});
				builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int arg1) {
						dialog.dismiss();
					}
				});
				builder.show();
			}
		});

	}

	private String OfflineImportSupervisor() {
		Sqldatabase db=new Sqldatabase(context);
		SQLiteDatabase sqlite=db.getdb();
		Cursor c = null;
		c= db.sqlQuery("select enduser_username "+db.key_mobileuser_name+" from " +
				db.tbl_mobile_user+" order by "  +  db.key_mobileuser_id);
		List<String> list = new ArrayList<String>();
		try
		{
			int i=1;
			if(c.getCount()>0){
				c.moveToFirst();
				String add;
				while(!c.isAfterLast()){
					add=c.getString(c.getColumnIndex(db.key_mobileuser_name));
					//Log.i("Addresss********************", "********************   "+add);
					try{
						add=add.substring(0,add.indexOf("~"));
					}
					catch(Exception e)
					{

					}
					list.add(add);
					c.moveToNext();
					i++;
				}
			}
		}
		catch(Exception e)
		{

		}
		ArrayList al = (ArrayList) list;
		Collections.sort(list);
		ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,R.layout.spinner_item, list);
		dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		sp1.setAdapter(dataAdapter);
		sp1.setSelection(list.size()-1);
		sp1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
		{
			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2,long arg3)
			{
				label=arg0.getItemAtPosition(arg2).toString();
				txtuser.setText(label);
				SharedPreferences sharedPreferences=getSharedPreferences("sample",MODE_PRIVATE);
				final SharedPreferences.Editor editor=sharedPreferences.edit();
				editor.putString("username",label);
				editor.commit();

			}
			@Override
			public void onNothingSelected(AdapterView<?> arg0) {}
		});
		return "";
	}
	public void Login_Button_Click (View view)
	{

		try
		{
			if(etPassword.length()<1)
			{
				Toast.makeText(context, "Please Enter Password", Toast.LENGTH_SHORT).show();
				return;
			}
			else
			{
				offlineuser = sp1.getSelectedItem().toString();
				offlinepass = etPassword.getText().toString();
				if(checkGroupIdExist()==true)  // check the group id has set in the local db
				{
					if(Utilss.CheckNet(context))
						new	RegisteringInServer().execute("");
					else
					{
						try {
							offlineuser = sp1.getSelectedItem().toString();
							offlinepass = etPassword.getText().toString();
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						String offlineResponce = Utils.offlinePasswordselection(offlinepass,offlineuser, context);
						if(offlineResponce.equalsIgnoreCase("Sucess"))
						{
							etPassword.clearComposingText();
							Intent i1 =new Intent(Login.this,Select_Activity.class);
							i1.putExtra("uname", offlineuser);
							i1.putExtra("usename",label);
							i1.putExtra("syncstatus",false);
							startActivity(i1);
						}
						else{
							showToast(0, ""+"Login Failed");
						}
					}
				}
			}
		}catch(Exception e) {
			showToast(0,"Password Required");
			return;
		}

	}
	public void close(View v) {
		AlertDialog.Builder alermsg = new AlertDialog.Builder(this);
		alermsg.setCancelable(true);
		alermsg.setTitle("Exit ..");
		alermsg.setMessage(" Are you sure you want to exit ? ");
		alermsg.setPositiveButton("yes", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				System.exit(0);
			}
		});
		alermsg.setNegativeButton("no", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				dialog.dismiss();
			}
		});
		alermsg.show();
	}
	public void addItemsOnspinner() {
		Cursor c=db.sqlQuery("select enduser_username "+db.key_mobileuser_name+" from " +
				db.tbl_mobile_user+" order by "  +  db.key_mobileuser_id);
		final List<String> list = new ArrayList<String>();
		try{
			int i=1;
			if(c.getCount()>0){
				c.moveToFirst();
				String add;

				while(!c.isAfterLast()){
					add=c.getString(c.getColumnIndex(db.key_mobileuser_name));
					//Log.i("Addresss********************", "********************   "+add);
					try{
						add=add.substring(0,add.indexOf("~"));
					}catch(Exception e) {

					}
					list.add(add);
					c.moveToNext();
					i++;
				}
			}
		}catch(Exception e) {

		}
		ArrayList al = (ArrayList) list;
		Collections.sort(list);
		ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, list);
		dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		sp1.setAdapter(dataAdapter);
		if(list.size()>0){
			sp1.setSelection(list.size()-1);
		}
		sp1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2,long arg3) {
				label=arg0.getItemAtPosition(arg2).toString();
				txtuser.setText(label);
				SharedPreferences sharedPreferences=getSharedPreferences("sample",MODE_PRIVATE);
				final SharedPreferences.Editor editor=sharedPreferences.edit();
				editor.putString("username",label);
				editor.commit();
			}
			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
			}
		});
	}
	public void showConnectingProgreesDialog(Context contect, Boolean show, String Message){
		ProgressDialog pdialoge = new ProgressDialog(context);
		if(show)
		{
			pdialoge=new ProgressDialog(contect);
			pdialoge.setMessage(Message);
			pdialoge.show();
			pdialoge.setCancelable(false);

			System.out.println("Shown dialog");
		} else {
			pdialoge.cancel();
		}
	}
	private Runnable showDimage = new Runnable(){
		public void run(){
			showConnectingProgreesDialog(context,false,"Connecting to server");
			Log.i("response", response);
			try{
				int id= Integer.parseInt(response);
				if(id>-1) {
					showToast(1,"Successfull Authentication");

					Utilss.setSharedPreferences(context, "Username", name);
					Utilss.setSharedPreferences(context, "Password", password);
					Utilss.tableUnamePassword(name,password);

					finish();

				} else {

					etPassword.clearComposingText();
					showToast(0,"Login Failed");

				}
			}
			catch(Exception e) {

				etPassword.clearComposingText();
				showToast(0,"Login Failed : "+ response);

			}

		}
	};
	private Runnable showUpdate = new Runnable(){
		public void run(){
			showConnectingProgreesDialog(context,false,"Connecting to server");

		}
	};

	public boolean checkGroupIdExist()

	{

		String res;
		try {
			res = Utilss.SharedPreferencesContain(context, "Responce");
			if (res==null)
			{
				Intent intent = new Intent(Login.this, Registration.class);
				finish();
				startActivity(intent);
				return false;
			}
			else
				return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
	}


	private class ImportSupervisorNames extends AsyncTask<String, Void, Boolean> {
		private final ProgressDialog dialog = new ProgressDialog(context);



		protected void onPreExecute() {

			try {
				this.dialog.setMessage("Syncing supervisors...");
				this.dialog.show();
				this.dialog.setCancelable(false);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		protected Boolean doInBackground(final String... args) {

			try {
				Utilss.setSuperVisorTableFromServer(context);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return true;
		}
		protected void onPostExecute(final Boolean success) {
			try {
				addItemsOnspinner();
				showToast(1,"Supervisor names synced from server");

				if (this.dialog.isShowing())
				{
					this.dialog.dismiss();
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}

	private class Importsync extends AsyncTask<String, Void, Boolean>{

		@Override
		protected Boolean doInBackground(String... params) {
			// TODO Auto-generated method stub

			try {
				if(Utils.CheckNet(context)==true)
				{
					Utils.offlineTableCreate(offlineuser, offlinepass, context);
				}
				Utils.offlineTableCreate(offlineuser, offlinepass, context);

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return true;
		}

	}
	/*
     *  asynchronous task for registration
     */
	private class RegisteringInServer extends AsyncTask<String, Void, Boolean> {
		private final ProgressDialog dialog = new ProgressDialog(context);

		String response;


		protected void onPreExecute() {

			this.dialog.setMessage("Logging in...");

			this.dialog.show();
			this.dialog.setCancelable(false);
		}

		protected Boolean doInBackground(final String... args) {

			response = Utilss.loggingSuperviser(context,sp1.getSelectedItem().toString(),etPassword.getText().toString());
			return true;
		}




		protected void onPostExecute(final Boolean success)
		{
			try{
				if(response.trim().equals("Success")){
					Utilss.setSharedPreferences(context, "user",sp1.getSelectedItem().toString());
					Utilss.setSharedPreferences(context, "pass", etPassword.getText().toString());
					// network.clearComposingText();
					etPassword.clearComposingText();
					if(Utilss.CheckNet(context))
					{
						synctoserverRequest.syncFromServerItemDetails();
					}
					if(Utilss.CheckNet(context)){
						//synctoserverRequest.syncFromServerWarehouseDetails();
						new Thread()
						{
							public void run()
							{
								Sqldatabase db=new Sqldatabase(Login.this);
								db.setWareHouseDetails(getApplication());

							}

						}.start();
					}
					if(Utilss.CheckNet(context)){
						//synctoserverRequest.syncFromServerSupplierDetails();
						new Thread()
						{
							public void run()
							{
								Sqldatabase db=new Sqldatabase(Login.this);
								db.setSupplierDetails(getApplication());

							}

						}.start();


					}


					Intent i1 =new Intent(Login.this,Select_Activity.class);
					i1.putExtra("syncstatus",true);
					i1.putExtra("username",label);
					startActivity(i1);
//            		     finish();
					/** Cahnge by kaja start***/
					////////////////////////////////////////////

					try {

						syncProgressDialog = ProgressDialog.show(Login.this, "Updating Database", "Building database..",true);

						new Thread(new Runnable() {

							@Override
							public void run() {

								// TODO Auto-generated method stub

								Utils.Dailysync(context,offlineuser,offlinepass);

								runOnUiThread(new Runnable() {

									@Override
									public void run() {
										// TODO Auto-generated method stub

										syncProgressDialog.dismiss();
										finish();
									}
								});
							}
						}).start();

					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}


					////////////////////////////////////////
					/*** Change By Kaja end ****/
					//finish();

				}
				else
					showToast(0, ""+response.trim());
				etPassword.setText("");

				if (this.dialog.isShowing())
				{
					this.dialog.dismiss();
				}
			}catch(Exception e){
				if (this.dialog.isShowing())
				{
					this.dialog.dismiss();
				}

				try {
					offlineuser = sp1.getSelectedItem().toString();
					offlinepass = etPassword.getText().toString();
				} catch (Exception ex) {
					// TODO Auto-generated catch block
					ex.printStackTrace();
				}
				//	showToast(1,"Network Connectivity requered you are entering off line mode");

				//DBTransact.getUserCount(new UserFetchRequest(offlineuser, offlinepass));

				String offlineResponce = Utils.offlinePasswordselection(offlinepass,offlineuser, context);
				if(offlineResponce.equalsIgnoreCase("Sucess"))
				{

					etPassword.clearComposingText();
					Intent i1 =new Intent(Login.this,Select_Activity.class);
					i1.putExtra("uname", offlineuser);
					i1.putExtra("syncstatus",false);
					startActivity(i1);
					finish();

				}
				else{
					showToast(0, ""+"Login Failed");
				}
			}


			/** Cahnge by kaja start***/
//////////////////////////////////////////////
//
//        		try {
//
//   				 syncProgressDialog = ProgressDialog.show(Login.this, "Updating Database", "Building database..",true);
//
//   				new Thread(new Runnable() {
//
//   					@Override
//   					public void run() {
//
//   						// TODO Auto-generated method stub
//
//   						Utils.Dailysync(context,offlineuser,offlinepass);
//
//   						runOnUiThread(new Runnable() {
//
//   							@Override
//   							public void run() {
//   								// TODO Auto-generated method stub
//
//   								syncProgressDialog.dismiss();
//
//   							}
//   						});
//   					}
//   				}).start();
//
//
//
//
////   				syncProgressDialog.setMessage("Building database..");
////   				syncProgressDialog.show();
////   				syncProgressDialog.setCancelable(false);
////
//////   				OnPreExecute();
////
////
////
////   				if(this.syncProgressDialog.isShowing()){
////
////   					this.syncProgressDialog.dismiss();
////
////   				}
//
//   			//	new	Importsync().execute("");
//   			} catch (Exception e) {
//   				// TODO Auto-generated catch block
//   				e.printStackTrace();
//   			}


			////////////////////////////////////////
			/*** Change By Kaja end ****/



		}

	}




	private Runnable showUpdate1 = new Runnable(){
		public void run(){
			showConnectingProgreesDialog(context,false,"Connecting to server");


		}
	};

	public void showToast(int a,String t)
	{
		try {
			LayoutInflater inflater = getLayoutInflater();
			View layout = inflater.inflate(R.layout.successtoat,
					(ViewGroup) findViewById(R.id.ll_custoast_parent));

			ImageView image = (ImageView) layout.findViewById(R.id.ll_custoast_iv);
			if(a==1) image.setImageResource(R.drawable.greentick);
			else image.setImageResource(R.drawable.attentionred);
			TextView text = (TextView) layout.findViewById(R.id.ll_custoast_msg);
			text.setText(t);
			Toast toast = new Toast(getApplicationContext());
			toast.setGravity(Gravity.FILL_HORIZONTAL|Gravity.BOTTOM | Gravity.CENTER_VERTICAL, 0, 0);
			toast.setDuration(Toast.LENGTH_SHORT);
			toast.setView(layout);
			toast.show();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	public void btnclick1(View view){
		etPassword.setText(etPassword.getText().toString()+"1");
	}
	public void btnclick2(View view){
		etPassword.setText(etPassword.getText().toString()+"2");
	}
	public void btnclick3(View view){
		etPassword.setText(etPassword.getText().toString()+"3");
	}
	public void btnclick4(View view){
		etPassword.setText(etPassword.getText().toString()+"4");
	}
	public void btnclick5(View view){
		etPassword.setText(etPassword.getText().toString()+"5");
	}
	public void btnclick6(View view){
		etPassword.setText(etPassword.getText().toString()+"6");
	}
	public void btnclick7(View view){
		etPassword.setText(etPassword.getText().toString()+"7");
	}
	public void btnclick8(View view){
		etPassword.setText(etPassword.getText().toString()+"8");
	}
	public void btnclick9(View view){
		etPassword.setText(etPassword.getText().toString()+"9");
	}
	public void btnclick0(View view){
		etPassword.setText(etPassword.getText().toString()+"0");
	}
	public void onclickback(View view){

		if(etPassword.length()>0){
			String s=etPassword.getText().toString();
			int length=s.length();
			etPassword.setText(s.substring(0, length-1));
		}
	}

	public void onclichuperviserchange(View view){

		sp1.performClick();
	}
	private Boolean exit = false;
	@Override
	public void onBackPressed() {
		if (exit)
		{
			Login.this.finish();
			moveTaskToBack(true);
		}
		else
		{
			Toast.makeText(this, "Press Back again to Exit.",
					Toast.LENGTH_SHORT).show();
			exit = true;

		}

	}


}


