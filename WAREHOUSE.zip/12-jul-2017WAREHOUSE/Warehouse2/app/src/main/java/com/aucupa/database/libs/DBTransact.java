package com.aucupa.database.libs;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;

public class DBTransact {
	
	//Db Details	
	public static final String database_name = "AUCUPA_WAREHOUSE";
	public static final int database_ver =1;
	
	//Table Name 
	public final static String tbl_warehouse_no ="Warehouse_No";
	public final static String tbl_Allwarehouses ="AllWarehouses";
	public final static String tbl_mobile_user ="Mobile_User";
	public final static String tbl_mobile_userOffline ="Mobile_UserOffline";  
	public final static String tbl_palnts ="Plants";
	public final static String tbl_assign_warehouse ="Assign_WareHouse";
	public final static String tbl_orderno_lotno ="Orderno_Lotno";
	public final static String tbl_suppliers ="suppliers";
	public final static String tbl_Items ="Items";
	public final static String tbl_Stock_QAChecklist="Stock_QA_Check";
	public final static String tbl_warehouse_addsock ="Add_Stock";
	public final static String tbl_warehouse_addsocks ="Add_Stocks";
	public final static String tbl_warehouse_issuestock ="Issue_Stock";
	public final static String tbl_warehouse_updatelocation ="Update_Location";
	public final static String tbl_warehouse_update_issue_location ="Update_issue_Location";
	
	//Keywords Used For Fields in Each tables
	
	//keyword For Sync Status
		public static final String key_warehouse_syncstatus ="Sync_Status";
		
	/**user Table**/
	public static final String key_mobileuser_id ="enduser_id";
	public static final String key_mobileuser_name ="enduser_username";
	public static final String key_mobileuser_password ="enduser_password";
	
	/**Mobile OfflineUser**/
	public static final String key_mobileuserOffline_id ="enduser_id";
	public static final String key_mobileuserOffline_uname ="enduser_username";
	public static final String key_mobileuserOffline_password ="enduser_password";
	
	/**Supplier Table **/
	public static final String key_supplier_id ="supplier_id";
	public static final String key_supplier_Server_id ="supplier_server_id";
	public static final String key_supplier_code ="supplier_code";
	public static final String key_supplier_name = "supplier_name";
	
	/**Orderno_lotNo**/
	public static final String key_orderno_lotno_id ="id";
	public static final String key_orderno_lotno_lotno ="lotno";
	public static final String key_orderno_lotno_orderno ="orderno";
	public static final String key_orderno_lotno_item_name ="item_name";
	public static final String key_orderno_lotno_raw_quantity ="raw_quantity";
	
	/**Warehouse_no**/
	public static final String key_warehouse_no_id ="id";
	public static final String key_warehouse_no_plantno ="warehouse_no";

	/**Assign WareHouse**/
	public static final String key_assign_warehouse_id ="id";
	public static final String key_assign_warehouse_plantno ="warehouse_no";
	public static final String key_assign_warehouse_uname ="username";
	
	/**Plants**/
	public static final String key_plants_id="id";
	public static final String key_plants_name ="plantName";
	
	/**Item **/
	public static final String key_warehouse_item_itemcode ="Item_code";
	public static final String key_warehouse_item_itemname="Item_name";
	public static final String key_warehouse_item_category ="Category";
	public static final String key_warehouse_item_subcategory ="Sub_category";
	public static final String key_warehouse_item_itemUnit ="Item_Unit";
	public static final String key_warehouse_item_itemtype ="Item_type";
	
	/**add stock*/
	public static final String key_warehouse_addstock_stockid ="Stock_id";
	public static final String key_warehouse_addstock_Stocktype ="StockType";
	public static final String key_warehouse_addstock_ordernumber ="OrderNo";
	public static final String key_warehouse_addstock_suppliercode ="SupplierCode";
	public static final String key_warehouse_addstock_itemcode ="ItemCode";
	public static final String key_warehouse_addstock_datetime ="datetime";
	public static final String key_warehouse_addstock_itemunit ="ItemUnit";
	public static final String key_warehouse_addstock_batchnumber ="BatchNumber";
	public static final String key_warehouse_addstock_RMARnumber ="RMARNumber";
	public static final String key_warehouse_addstock_RmSpecNo ="RmSpecNo";
	public static final String key_warehouse_addstock_GIRNo ="GIRNo";
	public static final String key_warehouse_addstock_commoditygrade ="CommodityGrade";
	public static final String key_warehouse_addstock_variety ="Variety";
	public static final String key_warehouse_addstock_EstYiels ="EstYield";
	public static final String key_warehouse_addstock_ExpDate ="ExpDate";
	public static final String key_warehouse_addstock_totalquantity ="TotalQuantity";
	public static final String key_warehouse_addstock_noofbags ="NoOfBags";
	public static final String key_warehouse_addstock_UnitPrice ="UnitPrice";
	public static final String key_warehouse_addstock_lotnumber ="LotNumber";
	public static final String key_warehouse_addstock_ArrivalForm ="ArrivalForm";
	public static final String key_warehouse_addstock_arrivaldate ="ArrivalDate";
	public static final String key_warehouse_addstock_intentstatus ="IntentStatus";
	public static final String key_warehouse_addstock_location_status ="Location_Status";
	public static final String key_warehouse_addstock_Remarks ="Remarks";
	public static final String key_warehouse_addstock_warehousecode ="WarehouseCode";

	/**Add Stocks **/

	
	/** issue stock**/
	public static final String key_warehouse_issuestock_issueid ="Issueid";
	public static final String key_warehouse_issuestock_Stocktype ="StockType";
	public static final String key_warehouse_issuestock_itemcode ="ItemCode";
	public static final String key_warehouse_issuestock_timestamp ="timestamp";
	public static final String key_warehouse_issuestock_lotnumber ="LotNumber";
	public static final String key_warehouse_issuestock_batchnumber ="BatchNumber";
	public static final String key_warehouse_issuestock_RMARnumber ="RMARNumber";
	public static final String key_warehouse_issuestock_Plantid  ="Plantid";
	public static final String key_warehouse_issuestock_OrderNumber ="OrderNumber";
	public static final String key_warehouse_issuestock_toWareHousid ="ToWareHouseid"; 
	public static final String key_warehouse_issuestock_RequiredQty ="RequiredQty";
	public static final String key_warehouse_issuestock_IssuedQty ="IssuedQty";
	public static final String key_warehouse_issuestock_IssuedTo ="IssuedTo";
	public static final String key_warehouse_issuestock_location_status ="Location_Status";
	
	/**Location update (Add stock & Issue stock) **/
	public static final String key_warehouse_updatelocation_locationid ="locationid";
	public static final String key_warehouse_updatelocation_warehouseid ="WareHouseid";
	public static final String key_warehouse_updatelocation_stockid ="Stock_id";
	public static final String key_warehouse_updatelocation_palletno ="PalletNo";
	public static final String key_warehouse_updatelocation_rakerow ="RakeRow";
	public static final String key_warehouse_updatelocation_rakecolumn ="RakeColumn";
	public static final String key_warehouse_updatelocation_refposition ="RefPosition";
	public static final String key_warehouse_updatelocation_qty ="Quantity";
	public static final String key_warehouse_updatelocation_itemcode ="ItemCode";
	
	public static final String key_warehouse_issuestockupdatelocation_issueid ="issueid";
	
	/**QACHECKlist**/
	public static final String key_Stock_QAChecklist_qaid ="qa_id";
	public static final String key_Stock_QAChecklist_stockid ="Stock_id";
	public static final String key_Stock_QAChecklist_IntegrityofBags="IntegrityofBags";
	public static final String key_Stock_QAChecklist_Appearance ="Appearance";
	public static final String key_Stock_QAChecklist_ExtraneousMatter ="Extraneous_Matter";
	public static final String key_Stock_QAChecklist_Other="Other";
	public static final String key_Stock_QAChecklist_Remarks ="Remarks";
	
	public static void getCount(String tablename){
		SQLiteDatabase db = null;
		SQLiteStatement stmt = null;
		try {
			db = DatabaseUtil.getDatabaseInstance();
			new DBResponse.Count().count=db.query(tablename,null,null,null,null,null,null).getCount();
		} catch (DbException e) {
			e.printStackTrace();
		} finally {
			DatabaseUtil.closeResource(db, stmt, null);
		}
	}
	
	public static void insertUser(DBInsertValues.UserInsertValue userinsertvalues){
			SQLiteDatabase db = null;
			SQLiteStatement stmt = null;
			try {
				db = DatabaseUtil.getDatabaseInstance();
				ContentValues cv=new ContentValues();
				cv.put(key_mobileuserOffline_uname, userinsertvalues.uname);
				cv.put(key_mobileuserOffline_password, userinsertvalues.password);
				db.insert(tbl_mobile_userOffline, null, cv);
			} catch (DbException e) {
				e.printStackTrace();
			} finally {
				DatabaseUtil.closeResource(db, stmt, null);
			}
	}
	
	public static void getUserCount(DBFetchRequest.UserFetchRequest userFetchRequest){
		SQLiteDatabase db = null;
		SQLiteStatement stmt = null;
		try {
			db = DatabaseUtil.getDatabaseInstance();
			new DBResponse.Count().count=db.query(tbl_mobile_userOffline,
					null,
					key_mobileuserOffline_uname+" = ? AND "+key_mobileuserOffline_password+" = ? ",
					new String[]{userFetchRequest.uname,userFetchRequest.password},
					null,null,null).getCount();
		} catch (DbException e) {
			e.printStackTrace();
		} finally {
			DatabaseUtil.closeResource(db, stmt, null);
		}
	}


}
