package com.aucupa.warehouse.adapter;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.TextView;

import com.aucupa.warehouse.R;

/**
 * Created by roy on 21-Jun-17.
 */

public class ListAdapter extends CursorAdapter
{
    TextView acc,amount1,item_id;
    TextView date1,remark1;
    String type,item,amount,date,remark;
    public ListAdapter(Context context, Cursor c)
    {
        super(context, c);
    }
    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        View view = layoutInflater.inflate(R.layout.customlist,null);
        return view;
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor)
    {
        acc= (TextView) view.findViewById(R.id.acc);
//        item_id=(TextView)view.findViewById(R.id.item_id);
//        amount1= (TextView) view.findViewById(R.id.amount1);
//        date1=(TextView) view.findViewById(R.id.date1);
//        remark1=(TextView) view.findViewById(R.id.remark1);

        type=cursor.getString(cursor.getColumnIndexOrThrow("supplier_name"));
//        item=cursor.getString(cursor.getColumnIndexOrThrow("StockType"));
//        amount= cursor.getString(cursor.getColumnIndexOrThrow("Warehousecode"));
//        date= cursor.getString(cursor.getColumnIndexOrThrow("TotalQuantity"));
//        remark=cursor.getString(cursor.getColumnIndexOrThrow("LotNumber"));


        acc.setText(type);
//        item_id.setText(item);
//        amount1.setText(amount);
//        date1.setText(date);
//        remark1.setText(remark);
    }
}
