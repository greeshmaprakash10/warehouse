package com.aucupa.warehouse;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewDebug.FlagToString;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class QACheckList extends Activity {
	
	Sqldatabase db;
	Utils utils;
	Context context;
	
	EditText etintegrityofbags,etappearance,etextraneousmatter,
	etother,etremarks;
	
	String	stintegrityofbags,stappearance,stextraneousmatter,
	stother,stremarks;
	String stStatus = 0+"";

	long ststockid; 
	
	boolean flag_insert=true;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_qacheck_list);
		
		context=this;
		db=new Sqldatabase(context);
		
		ststockid= this.getIntent().getExtras().getLong("Stock_Id");
		
		etintegrityofbags=(EditText)findViewById(R.id.editintegrityofbags);
		etappearance=(EditText)findViewById(R.id.editappearance);
		etextraneousmatter=(EditText)findViewById(R.id.editextraneousmatter);
		etother=(EditText)findViewById(R.id.editother);
		etremarks=(EditText)findViewById(R.id.editqaremarks);
		
		
	}
	public void onqaSave(View v){
		if(saveQA()){

			Intent i1 =new Intent(getApplicationContext(),Add_Stock.class);
			startActivity(i1);
			finish();
		}
	}
	
	public void onUpdateLocation(View v){
		if(saveQA()){
			Bundle b=new Bundle();
			b.putLong("Stock_id", ststockid);
			Intent i1 =new Intent(getApplicationContext(),UpdateLocation.class);
			i1.putExtras(b);
			startActivity(i1);
			finish();
		}
		
	}
	
	public boolean saveQA(){
		
		flag_insert=true;
		
		if(etintegrityofbags.length()<1){
			showToast(0, "Enter Integrity of Bags");
			flag_insert=false;
		}else{
			stintegrityofbags=etintegrityofbags.getText().toString();
			stappearance=etappearance.getText().toString();
			stextraneousmatter=etextraneousmatter.getText().toString();
			stother=etother.getText().toString();
			stremarks=etremarks.getText().toString();
		}
		if(flag_insert){
			ContentValues cv=new ContentValues();
				
			cv.put(db.key_Stock_QAChecklist_stockid,String.valueOf(ststockid));
			cv.put(db.key_Stock_QAChecklist_IntegrityofBags, stintegrityofbags);
			cv.put(db.key_Stock_QAChecklist_Appearance, stappearance);
			cv.put(db.key_Stock_QAChecklist_ExtraneousMatter, stextraneousmatter);
			cv.put(db.key_Stock_QAChecklist_Other, stother);
			cv.put(db.key_Stock_QAChecklist_Remarks, stremarks);
			cv.put(db.key_warehouse_createdtime,Utils.getSystemTimeStamp());
			cv.put(db.key_warehouse_syncstatus, "0");
			
			if(db.sqlins(db.tbl_Stock_QAChecklist, cv)>0){
				showToast(1, "Stock QA Added Successfully ");
				clearValues();
				return flag_insert;
			}
		}
		
		return flag_insert;
	}
	
	 public void showToast(int a,String t)
     { 
     	 try {
     		 LayoutInflater inflater = getLayoutInflater();
     		 View layout = inflater.inflate(R.layout.successtoat,
     		                                (ViewGroup) findViewById(R.id.ll_custoast_parent));

     		 ImageView image = (ImageView) layout.findViewById(R.id.ll_custoast_iv);
     		 if(a==1) image.setImageResource(R.drawable.greentick);		 
     		 else image.setImageResource(R.drawable.attentionred);			 
     		 TextView text = (TextView) layout.findViewById(R.id.ll_custoast_msg);
     		 text.setText(t);
     		 Toast toast = new Toast(getApplicationContext());
     		 toast.setGravity(Gravity.FILL_HORIZONTAL|Gravity.BOTTOM | Gravity.CENTER_VERTICAL, 0, 0);
     		 toast.setDuration(Toast.LENGTH_SHORT);
     		 toast.setView(layout);
     		 toast.show();
     	} catch (Exception e1) {
     		// TODO Auto-generated catch block
     		e1.printStackTrace();
     	} 
     }
	
	public void onSkip(View v){
		Intent i1 =new Intent(getApplicationContext(),Add_Stock.class);
		startActivity(i1);
		finish();
	}
	
	public void clearValues(){
		etintegrityofbags.setText("");
		etappearance.setText("");
		etextraneousmatter.setText("");
		etother.setText("");
		etremarks.setText("");
	}
	

}
