package com.aucupa.warehouse;

import java.util.ArrayList;
import java.util.List;

import com.aucupa.warehouse.adapter.DefaultIssueAdapter;
import com.aucupa.warehouse.adapter.DefaultLivestockAdapter;
import com.aucupa.warehouse.model.DummyModelLiveStock;
import com.aucupa.warehouse.sync.SyncResponseDataWrapper;
import com.aucupa.warehouse.sync.SyncResponseDatatypes;
import com.aucupa.warehouse.utils.DummyContent;
import com.aucupa.warehouse.view.AnimatedExpandableListView;
import com.aucupa.warehouse.view.AnimatedExpandableListView.AnimatedExpandableListAdapter;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;
import com.nhaarman.listviewanimations.appearance.AnimationAdapter;
import com.nhaarman.listviewanimations.appearance.simple.AlphaInAnimationAdapter;
import com.nhaarman.listviewanimations.itemmanipulation.DynamicListView;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.ActionBar.LayoutParams;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Point;
import android.os.Bundle;
import android.support.v4.widget.SimpleCursorAdapter;
import android.support.v4.widget.SimpleCursorAdapter.ViewBinder;
import android.util.Log;
import android.util.TypedValue;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import android.widget.ExpandableListView.OnGroupClickListener;

public class ViewLiveStock extends Activity {
	
	public static final String LIST_VIEW_OPTION_4 = "Appearance animation (alpha)";

	private DynamicListView mDynamicListView; 
	static ListView locationlist;  
	TextView edittxtclear,searchtxt;
	ToggleButton byiname,byicode; 
	EditText serchedt; 
	public static Boolean byname=true;
	private Context context;
	String key_type="in";
	static Context cnt;
	
	static int width=500;
	static int height=700;
	
	
	JsonObject jsonInObj;
	JsonArray jsonINArray;
	
	SyncResponseDatatypes.SyncLivestockResponse synclivesstock;
	

	@SuppressLint("NewApi")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.view_live_stock);
		
		context=ViewLiveStock.this;
		cnt=ViewLiveStock.this;
		
		byicode=(ToggleButton)findViewById(R.id.tb_view_livesk_fitemcode);
		byiname=(ToggleButton)findViewById(R.id.tb_view_livesk_fitemname);
		edittxtclear=(TextView)findViewById(R.id.txt_view_livesk_sclear);
		searchtxt=(TextView)findViewById(R.id.txt_view_livesk_search);
		serchedt=(EditText)findViewById(R.id.edt_view_livesk_search_field);
		mDynamicListView = (DynamicListView) findViewById(R.id.livest_list_view);
		serchedt.clearFocus();
		
		try {
			Display display = getWindowManager().getDefaultDisplay();
			Point size = new Point();
			display.getSize(size);  
			width = size.x; 
			height = size.y-50; 

		} catch (Exception e1) { 
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	
		edittxtclear.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				serchedt.setText(null);
			}
		});
		
		searchtxt.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if(Utils.CheckNet(context)){
				sendRequest();
				showToast(1,"Searching..");
				}
			}
		});
		
		byicode.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				byname=false;
				key_type="ic";
				byiname.setChecked(false);
				byicode.setChecked(true);
			}
		});
		byiname.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				byname=true;
				key_type="in";
				byicode.setChecked(false);
				byiname.setChecked(true);
			}
		});

	}
	
	public void sendRequest(){
		jsonInObj=new JsonObject();
		jsonINArray=new JsonArray();
		
		jsonInObj.addProperty("table","StockList");
		jsonInObj.addProperty("username",Utils.SharedPreferencesContain(context, "user"));
		jsonInObj.addProperty("dev_id",Utils.SharedPreferencesContain(context, "Div_id")																				);
		jsonInObj.addProperty("keytype",key_type);
		jsonInObj.addProperty("value",serchedt.getText().toString() );
		jsonINArray.add(jsonInObj);
		
		synclivesstock=new SyncResponseDatatypes.SyncLivestockResponse();
		
		try {
	       	FutureCallback<JsonObject> futureCallBack=new FutureCallback<JsonObject>() {
	       		
		            @Override
		            public void onCompleted(Exception e, JsonObject result) {
		            	if(e==null)
		            	{
		            		if(result!=null)
		            		{
		            			try
		            			{
		            				synclivesstock=new Gson().fromJson(result, SyncResponseDatatypes.SyncLivestockResponse.class);
		            			}
		            			catch(Exception ee)
		            			{
		            				Log.e("Result Error  :", ee.toString());
		            			}
		            		}
		            		
		            		Log.i("Result json livestock : ", result.toString());

		            		if(synclivesstock.isSuccess()){
		            			if(synclivesstock.data.size()>0){

			            			String category = LIST_VIEW_OPTION_4;		
			        				setUpListView(category);
		            			}  
		            		}else{
		            			mDynamicListView.setAdapter(null);
		            			showToast(0,"No data found");
		            		}
		            	}
		            }
		        };
		        
		        Log.i("Request json livestock : ", jsonINArray.toString());
				 Ion.with(context)
	                .load(Utils.weburl+"sync_out")
	                .setJsonArrayBody(jsonINArray)
	                .asJsonObject()
	                .setCallback(futureCallBack);
			
	      
		}catch (Exception e) {
		// TODO: handle exception
			System.out.print(e.toString());
		
		}
		
	}
	private void setUpListView(String category) {

		appearanceAnimate(0);

	} 
	private void appearanceAnimate(int key) {

		try {
			BaseAdapter adapter = new DefaultLivestockAdapter(this,
					DummyContent.getLivestockList(synclivesstock), false);
			AnimationAdapter animAdapter;		
			animAdapter = new AlphaInAnimationAdapter(adapter);		
			animAdapter.setAbsListView(mDynamicListView);
			mDynamicListView.setAdapter(animAdapter);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
	}
	public static void editLocation(final ArrayList<SyncResponseDataWrapper.LivestockLocation> location)
	{	
		final Dialog dialog = new Dialog(cnt);	
		dialog.setTitle("Location");			   
		dialog.setContentView(R.layout.locationview);	
		locationlist=(ListView)dialog.findViewById(R.id.lv_locationview_loc);
		TextView noloc=(TextView)dialog.findViewById(R.id.txt_locationview_noloc);
		Button cancel=(Button)dialog.findViewById(R.id.bt_locationview_cancel);
		ImageView addnewloc=(ImageView)dialog.findViewById(R.id.iv_locationview_newloc);
		cancel.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				dialog.dismiss();
			}
		});
			try {
				if(location.size()>0)
				{
				noloc.setVisibility(View.INVISIBLE); 
				addnewloc.setVisibility(View.INVISIBLE); 
				locationlist.setVisibility(View.VISIBLE);
				locationlist.setAdapter(new LocationAda(cnt,location));

				}
				else{
					locationlist.setVisibility(View.GONE);
					addnewloc.setVisibility(View.INVISIBLE); 
					noloc.setVisibility(View.VISIBLE);

				} 
				try {
					Window window = dialog.getWindow();
					window.setLayout(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
					window.setGravity(Gravity.CENTER);
				dialog.show();
				
				dialog.getWindow().setLayout(width, height);
				dialog.setCancelable(false);
			} catch (Exception e) {
				// TODO Auto-generated catch block  
				e.printStackTrace();
			}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
	public static class LocationAda extends BaseAdapter{
		private ArrayList<SyncResponseDataWrapper.LivestockLocation> liveloc;
		private Context mContext;
		private LayoutInflater mInflater;
		public LocationAda(Context context,ArrayList<SyncResponseDataWrapper.LivestockLocation> liveloc) {
			this.liveloc=liveloc;
			mContext = context;
			mInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		}
		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return liveloc.size();
		}

		@Override
		public Object getItem(int position) {
			return position;
		}

		@Override
		public long getItemId(int position) {
			return position;
		}
		private class Holder{
			TextView wh;
			TextView rake;
			TextView col;
			TextView qty;
			LinearLayout itemcodelabel;
			
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			Holder holder=new Holder();
			View rowView=mInflater.inflate(R.layout.locationedititem2,null);
			holder.itemcodelabel=(LinearLayout)rowView.findViewById(R.id.llll_itemcode);
			holder.wh=(TextView)rowView.findViewById(R.id.txt_locediti_warehouse);
			holder.rake=(TextView)rowView.findViewById(R.id.txt_locediti_rakerow);
			holder.col=(TextView)rowView.findViewById(R.id.txt_locediti_rakecolumn);
			holder.qty=(TextView)rowView.findViewById(R.id.txt_locediti_qty);
			holder.itemcodelabel.setVisibility(View.GONE);
			holder.wh.setText(liveloc.get(position).warehouse_no);
			holder.rake.setText(liveloc.get(position).rake_row);
			holder.col.setText(liveloc.get(position).rake_column);
			holder.qty.setText(liveloc.get(position).lqty);
			return rowView;
		}
		
	}
	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		super.onBackPressed();
		Intent i1 =new Intent(getApplicationContext(),Select_Activity.class);
		i1.putExtra("syncstatus",true);
		startActivity(i1);
		finish();
	}
	 public void showToast(int a,String t)
     { 
     	 try {
     		 LayoutInflater inflater = getLayoutInflater();
     		 View layout = inflater.inflate(R.layout.successtoat,
     		                                (ViewGroup) findViewById(R.id.ll_custoast_parent));

     		 ImageView image = (ImageView) layout.findViewById(R.id.ll_custoast_iv);
     		 if(a==1) image.setImageResource(R.drawable.greentick);		 
     		 else image.setImageResource(R.drawable.attentionred);			 
     		 TextView text = (TextView) layout.findViewById(R.id.ll_custoast_msg);
     		 text.setText(t);
     		 Toast toast = new Toast(getApplicationContext());
     		 toast.setGravity(Gravity.FILL_HORIZONTAL|Gravity.BOTTOM | Gravity.CENTER_VERTICAL, 0, 0);
     		 toast.setDuration(Toast.LENGTH_SHORT);
     		 toast.setView(layout);
     		 toast.show();
     	} catch (Exception e1) {
     		// TODO Auto-generated catch block
     		e1.printStackTrace();
     	} 
     }
}
