package com.aucupa.warehouse.adapter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import com.aucupa.warehouse.R;
import com.aucupa.warehouse.ViewIssueStock;
import com.aucupa.warehouse.ViewLiveStock;
import com.aucupa.warehouse.model.DummyModelIssueStock;
import com.aucupa.warehouse.model.DummyModelLiveStock;
import com.nhaarman.listviewanimations.itemmanipulation.swipedismiss.OnDismissCallback;
import com.nhaarman.listviewanimations.itemmanipulation.swipedismiss.undo.UndoAdapter;
import com.nhaarman.listviewanimations.util.Swappable;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class DefaultLivestockAdapter extends BaseAdapter implements Swappable, UndoAdapter, OnDismissCallback {
	
	private Context mContext;
	private LayoutInflater mInflater;
	private ArrayList<DummyModelLiveStock> mDummyModelList;
	private boolean mShouldShowDragAndDropIcon;
	public DefaultLivestockAdapter(Context context, ArrayList<DummyModelLiveStock> dummyModelList, boolean shouldShowDragAndDropIcon) {
		// TODO Auto-generated constructor stub
		mContext = context;
		mInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		mDummyModelList = dummyModelList;
		mShouldShowDragAndDropIcon = shouldShowDragAndDropIcon;
	}
	@Override
	public boolean hasStableIds() {
		return true;
	}  

		
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return mDummyModelList.size(); 
	}
	
	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		final ViewHolder holder;
		try {
			if (convertView == null) {

				convertView = mInflater.inflate(R.layout.livestockgroupitem, parent, false);
				if(position%2==1){
				convertView.setBackgroundColor(Color.parseColor("#e2ddc7"));
				}
				holder = new ViewHolder();  
				holder.ic=(TextView) convertView.findViewById(R.id.txt_livestock_icode);
				holder.in=(TextView) convertView.findViewById(R.id.txt_livestock_iname);
				holder.it=(TextView) convertView.findViewById(R.id.txt_livestock_itype);
				holder.iq=(TextView) convertView.findViewById(R.id.txt_livestock_iqty);
				convertView.setTag(holder); 
			} else {  
				holder = (ViewHolder) convertView.getTag();   
			}; 
			final DummyModelLiveStock dm = mDummyModelList.get(position);
			holder.ic.setText(dm.getic());
			holder.in.setText(dm.getin());
			holder.it.setText(dm.getit());
			holder.iq.setText(dm.getiq());	
			convertView.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					ViewLiveStock.editLocation(mDummyModelList.get(position).getloction());
				}
			});
//			holder.editloc.setOnClickListener(new OnClickListener() {
//				
//				@Override
//				public void onClick(View v) {
//					// TODO Auto-generated method stub
//				//	ViewIssueStock.editLocation(dm.getIssueid());
//					
//				}
//			});
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return convertView;
	}
	
	private static class ViewHolder {
		TextView ic;
		TextView in;
		TextView it;
		TextView iq;
		
	}

	@Override 
	@NonNull
	public View getUndoClickView(@NonNull View view) {
		return view.findViewById(R.id.undo_button);
	}

	@Override
	@NonNull
	public View getUndoView(final int position, final View convertView,
			@NonNull final ViewGroup parent) {
		View view = convertView;
		if (view == null) {
			view = LayoutInflater.from(mContext).inflate(R.layout.list_item_undo_view,
					parent, false);
		}
		return view;
	}

	@Override
	public void onDismiss(@NonNull final ViewGroup listView,
			@NonNull final int[] reverseSortedPositions) {
		for (int position : reverseSortedPositions) {
			remove(position);
		}
	}
	public void remove(int position) {
		mDummyModelList.remove(position);
	}

	@Override
	public void swapItems(int positionOne, int positionTwo) {
		// TODO Auto-generated method stub  
		Collections.swap(mDummyModelList, positionOne, positionTwo);
	}
	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return position;
	}
	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

}
