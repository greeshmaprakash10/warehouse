package com.aucupa.warehouse;

import com.aucupa.warehouse.adapter.DefaultAdapter;
import com.aucupa.warehouse.adapter.DefaultIssueAdapter;
import com.aucupa.warehouse.utils.DummyContent;
import com.nhaarman.listviewanimations.appearance.AnimationAdapter;
import com.nhaarman.listviewanimations.appearance.simple.AlphaInAnimationAdapter;
import com.nhaarman.listviewanimations.itemmanipulation.DynamicListView;

import android.app.Activity;
import android.app.Dialog;
import android.app.ActionBar.LayoutParams;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Point;
import android.os.Bundle;
import android.support.v4.widget.SimpleCursorAdapter;
import android.support.v4.widget.SimpleCursorAdapter.ViewBinder;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Display;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.ToggleButton;

public class ViewIssueStock extends Activity {

	public static final String LIST_VIEW_OPTION_4 = "Appearance animation (alpha)";
	Cursor cs;
	static Cursor cs1;
	static Sqldatabase db; 
	Utils utility;
	static ListView locationlist; 
	private DynamicListView mDynamicListView;   
	TextView edittxtclear;
	String stWareHouseNo;
	ToggleButton byiname,byicode; 
	EditText serchedt; 
	static Context cnt;
	static int width=500;
	static int height=700;
	static SimpleCursorAdapter adapt;
	static Boolean alertstatus;
	public static Boolean byname=true;
	 public static Activity activity = null;
	 
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_view_issue_stock);
		
		cnt=ViewIssueStock.this;
		activity=this;
		mDynamicListView = (DynamicListView) findViewById(R.id.dynamic_listview);
		byicode=(ToggleButton)findViewById(R.id.tb_viewsk_fitemcode);
		byiname=(ToggleButton)findViewById(R.id.tb_viewsk_fitemname);
		edittxtclear=(TextView)findViewById(R.id.txt_viewsk_sclear);
		serchedt=(EditText)findViewById(R.id.edt_viewsk_search_field);
		db = new Sqldatabase(this);
		try {
			Display display = getWindowManager().getDefaultDisplay();
			Point size = new Point();
			display.getSize(size);  
			width = size.x; 
			height = size.y-50; 

		} catch (Exception e1) { 
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		edittxtclear.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				serchedt.setText(null);
			}
		});
		byicode.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				byname=false;
				byiname.setChecked(false);
			}
		});
		byiname.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				byname=true;
				byicode.setChecked(false);
			}
		});
		serchedt.addTextChangedListener(new TextWatcher() {
			
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				// TODO Auto-generated method stub
				 
			} 
			
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub 
				try { 
					String where=Sqldatabase.key_warehouse_issuestock_itemcode+" like '"+serchedt.getText().toString()+"%' ";
					if(byname) where=Sqldatabase.key_warehouse_item_itemname+" like '"+serchedt.getText().toString()+"%' ";
					cs=db.sqlQuery("Select * from "+db.tbl_warehouse_issuestock+","+db.tbl_Items+" where "+
					db.key_warehouse_item_itemcode+"="+db.key_warehouse_issuestock_itemcode+" and "+where+
							" order by "+db.key_warehouse_item_itemname); 

					if(cs.getCount()>0)
					{cs.moveToFirst(); 
						String category = LIST_VIEW_OPTION_4;		
						setUpListView(category);  
					}
				
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
	
		 
		
		try {
			cs=	cs=db.sqlQuery("Select * from "+db.tbl_warehouse_issuestock+","+db.tbl_Items+" where "+
					db.key_warehouse_item_itemcode+"="+db.key_warehouse_issuestock_itemcode+
					" order by "+db.key_warehouse_item_itemname);
					
					
				
			if(cs.getCount()>0)
			{cs.moveToFirst(); 
				String category = LIST_VIEW_OPTION_4;		
				setUpListView(category);  
			}
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
	}
   
	@Override   
	public boolean onOptionsItemSelected(MenuItem item) { 
		if (item.getItemId() == android.R.id.home) {
			finish(); 
			return true; 
		} 
		return super.onOptionsItemSelected(item);
	}

	private void setUpListView(String category) {

			appearanceAnimate(0);
	
	} 
private void appearanceAnimate(int key) {

	
		try {
			BaseAdapter adapter = new DefaultIssueAdapter(this,
					DummyContent.getDummyModelIssueStockList(cs), false);
			AnimationAdapter animAdapter;		
				animAdapter = new AlphaInAnimationAdapter(adapter);		
			animAdapter.setAbsListView(mDynamicListView);
			mDynamicListView.setAdapter(animAdapter);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
	}
 
@Override
public void onBackPressed() {
	// TODO Auto-generated method stub
	super.onBackPressed();
	Intent i1 =new Intent(getApplicationContext(),Select_Activity.class);
	i1.putExtra("syncstatus",true);
	startActivity(i1);
	finish();
}

public static void editLocation(final String issue_id)
{	
	final Dialog dialog = new Dialog(cnt);	
	dialog.setTitle("Location of Issue ID:"+issue_id);			   
	dialog.setContentView(R.layout.locationview);	
	locationlist=(ListView)dialog.findViewById(R.id.lv_locationview_loc);
	TextView noloc=(TextView)dialog.findViewById(R.id.txt_locationview_noloc);
	ImageView addnewloc=(ImageView)dialog.findViewById(R.id.iv_locationview_newloc);
	addnewloc.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			dialog.dismiss();
			Intent i1 =new Intent(cnt,UpdateIssueLocation.class);
			i1.putExtra("Issue_id",Long.parseLong(issue_id));
			//i1.putExtra("Issue_id",issue_id);
			cnt.startActivity(i1);
			activity.finish();
			
		}
	});
	Button cancel=(Button)dialog.findViewById(R.id.bt_locationview_cancel);
	cancel.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			dialog.dismiss();
		}
	});
		try { 
			cs1=db.sqlQuery("Select *,"+db.key_warehouse_issuestockupdatelocation_issueid+" as _id,"
					+Sqldatabase.key_warehouse_no_plantno
					+ " from "+db.tbl_warehouse_update_issue_location+","+Sqldatabase.tbl_warehouse_no+
					" where "+Sqldatabase.key_warehouse_no_id+" = "+Sqldatabase.key_warehouse_updatelocation_warehouseid+
					" and "+db.key_warehouse_issuestockupdatelocation_issueid+"='"+issue_id+"'");
			if(cs1.getCount()>0)
			{
			noloc.setVisibility(View.INVISIBLE); 
			locationlist.setVisibility(View.VISIBLE);
			addnewloc.setVisibility(View.GONE); 

			cs1.moveToFirst(); 
			adapt=new SimpleCursorAdapter(cnt, R.layout.locationedititem2, cs1, 
					new String[]{db.key_warehouse_no_plantno,db.key_warehouse_updatelocation_itemcode,
					db.key_warehouse_updatelocation_qty,db.key_warehouse_updatelocation_rakerow,
					db.key_warehouse_updatelocation_rakecolumn}, 
					new int[]{R.id.txt_locediti_warehouse,R.id.txt_locediti_itemcode,
					R.id.txt_locediti_qty,R.id.txt_locediti_rakerow,R.id.txt_locediti_rakecolumn}, SimpleCursorAdapter.NO_SELECTION);
			adapt.setViewBinder(new ViewBinder() {      
				 
				@Override    
				public boolean setViewValue(View arg0, Cursor arg1, int arg2) {
					// TODO Auto-generated method stub 


					if(13==arg2){  
						try { 
							TextView frname=(TextView)arg0;	
							
		 					frname.setText(arg1.getString(arg2));   
						} catch (NumberFormatException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						  
					} 
					else if(5==arg2){   
						try {
							TextView frname=(TextView)arg0;	
							
		 					frname.setText(arg1.getString(arg2));   
						} catch (NumberFormatException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						  
					}	
					else if(6==arg2){   
						try {
							TextView frname=(TextView)arg0;	
							
		 					frname.setText(arg1.getString(arg2));   
						} catch (NumberFormatException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						  
					}
					else if(3==arg2){   
						try {
							TextView frname=(TextView)arg0;	
							
		 					frname.setText(arg1.getString(arg2));   
						} catch (NumberFormatException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						  
					}
					else if(8==arg2){  
						try {
							TextView frname=(TextView)arg0;	
							
		 					frname.setText(arg1.getString(arg2));   
						} catch (NumberFormatException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						  
						  
					}
					return true;
					}
					});
			locationlist.setAdapter(adapt);
			 
			}
			else{
				locationlist.setVisibility(View.GONE);
				noloc.setVisibility(View.VISIBLE);
				addnewloc.setVisibility(View.VISIBLE); 

			} 
			try {
				Window window = dialog.getWindow();
				window.setLayout(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
				window.setGravity(Gravity.CENTER);
			dialog.show();
			
			dialog.getWindow().setLayout(width, height);
			dialog.setCancelable(false);
		} catch (Exception e) {
			// TODO Auto-generated catch block  
			e.printStackTrace();
		}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}