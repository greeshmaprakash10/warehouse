package com.aucupa.warehouse.utils;

import java.util.ArrayList;

import android.database.Cursor;
import android.widget.Toast;

import com.aucupa.warehouse.Sqldatabase;
import com.aucupa.warehouse.model.DummyModel;
import com.aucupa.warehouse.model.DummyModelIssueStock;
import com.aucupa.warehouse.model.DummyModelLiveStock;
import com.aucupa.warehouse.sync.SyncResponseDatatypes;
import com.aucupa.warehouse.sync.SyncResponseDatatypes.SyncLivestockResponse;

public class DummyContent {
 
	public static ArrayList<DummyModel> getDummyModelList(Cursor cs) {
		ArrayList<DummyModel> list = new ArrayList<>();
		int i=0;
		while(cs.isAfterLast()==false) 
		{	String f=cs.getString(cs.getColumnIndex(Sqldatabase.key_warehouse_item_itemname)).toString().substring(0, 1).toUpperCase();
			list.add(new DummyModel(i, "", f, cs.getString(cs.getColumnIndex(Sqldatabase.key_warehouse_item_itemname)),
					cs.getString(cs.getColumnIndex(Sqldatabase.key_warehouse_addstock_totalquantity)),
					cs.getString(cs.getColumnIndex(Sqldatabase.key_warehouse_addstock_stockid)),
					cs.getString(cs.getColumnIndex(Sqldatabase.key_warehouse_addstock_location_status))));
			i++;
			cs.moveToNext();

		}
		
		return list;
	}
	public static ArrayList<DummyModelIssueStock> getDummyModelIssueStockList(Cursor cs) {
		ArrayList<DummyModelIssueStock> list = new ArrayList<>();
		int i=0;cs.moveToFirst();
		while(cs.isAfterLast()==false) 
		{	String f=cs.getString(cs.getColumnIndex(Sqldatabase.key_warehouse_item_itemname)).toString().substring(0, 1).toUpperCase();
		list.add(new DummyModelIssueStock(i, "", f, cs.getString(cs.getColumnIndex(Sqldatabase.key_warehouse_item_itemname)),
				cs.getString(cs.getColumnIndex(Sqldatabase.key_warehouse_issuestock_IssuedQty)), 
				cs.getString(cs.getColumnIndex(Sqldatabase.key_warehouse_issuestock_issueid)),
				cs.getString(cs.getColumnIndex(Sqldatabase.key_warehouse_issuestock_location_status)))); 
		i++;
		cs.moveToNext();

		}
		
		return list;
	}
	
	public static ArrayList<DummyModelLiveStock> getLivestockList(SyncResponseDatatypes.SyncLivestockResponse liveresponse) {
		ArrayList<DummyModelLiveStock> list = new ArrayList<>();
		for(int i=0;i<liveresponse.data.size();i++) 
		{	
		list.add(new DummyModelLiveStock(liveresponse.data.get(i).itemcode,
				liveresponse.data.get(i).itemname,
				liveresponse.data.get(i).itemtype,
				liveresponse.data.get(i).quantity,
				liveresponse.data.get(i).location)); 
		

		}
		return list;
	}
	
	}
 
 