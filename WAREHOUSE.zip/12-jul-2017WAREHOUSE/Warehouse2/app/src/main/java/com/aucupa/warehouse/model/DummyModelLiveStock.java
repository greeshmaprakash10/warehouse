package com.aucupa.warehouse.model;

import java.util.ArrayList;

import com.aucupa.warehouse.sync.SyncResponseDataWrapper;
import com.aucupa.warehouse.sync.SyncResponseDataWrapper.SyncLivestockResponseData;

public class DummyModelLiveStock {
	private String ic,in,it,iq;
	private ArrayList<SyncResponseDataWrapper.LivestockLocation> livloc;
	
	public DummyModelLiveStock(String ic,String in, String it, String iq,ArrayList<SyncResponseDataWrapper.LivestockLocation> livloc){
		this.ic = ic;
		this.in = in; 
		this.it = it;
		this.iq=iq;
		this.livloc=livloc;
	}
	public String getic() {
		return ic;
	}
	public void setic(String ic) {
		this.ic = ic;
	}
	
	public String getin() {
		return in;
	}
	public void setin(String in) {
		this.in = in;
	}
	
	public String getit() {
		return it;
	}
	public void setit(String it) {
		this.it = it;
	}
	
	public String getiq() {
		return iq;
	}
	public void setiq(String iq) {
		this.iq = iq;
	}
	
	public ArrayList<SyncResponseDataWrapper.LivestockLocation> getloction(){
		return livloc;
	}
	
}
