package com.aucupa.warehouse;




 

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.net.ConnectivityManager;
import android.net.NetworkInfo.State;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings.Secure;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;


public class Registration extends Activity { 
	
	Context context;
	EditText etUsername;  
	TextView tvAppName,tvDeviceId; 
	String stUsername,stPassword,response,name,password;
	private Handler mHandler ;
	ContentValues cv;
	ProgressDialog conectingDialog;
	Sqldatabase db ;   
	EditText etPlantId,etGroupId,etUserName,etPassword;
	Spinner sp1;  
    protected void onCreate(Bundle savedInstanceState) {  
        super.onCreate(savedInstanceState);
		setContentView(R.layout.registerxml);
		this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		  
		  
//		Intent i1 =new Intent(Registration.this,Login.class);
//		i1.putExtra("syncstatus",true); 
//		startActivity(i1);
//		finish();  
		db = new Sqldatabase(this); 
//		db.configins(db.tbl_Items, "");
//		db.configins(db.tbl_palnts, "");
//		db.configins(db.tbl_suppliers, "");
		 try {
			 Utilss.setSharedPreferences(getApplicationContext(), "Div_id", Secure.getString(this.getContentResolver(),
					       Secure.ANDROID_ID) );
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		etGroupId = (EditText)findViewById(R.id.et_reg_orgid);
		etUserName = (EditText)findViewById(R.id.et_reg_username);
		etPassword = (EditText)findViewById(R.id.et_reg_password);
		//setupUI(findViewById(R.id.parentReg));
		context = this;

tvDeviceId = (TextView)findViewById(R.id.txt_reg_devid);

tvDeviceId.setText(""+Secure.getString(this.getContentResolver(), Secure.ANDROID_ID));



 // networkcheck();



}

public boolean networkcheck() {
	
	ConnectivityManager manager = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
	
	android.net.NetworkInfo wifi = manager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
	android.net.NetworkInfo mob = manager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
	android.net.NetworkInfo wimax = manager.getNetworkInfo(ConnectivityManager.TYPE_WIMAX);
	android.net.NetworkInfo ethernet = manager.getNetworkInfo(ConnectivityManager.TYPE_ETHERNET);
	android.net.NetworkInfo bluth = manager.getNetworkInfo(ConnectivityManager.TYPE_BLUETOOTH);
	android.net.NetworkInfo dfalt = manager.getNetworkInfo(ConnectivityManager.DEFAULT_NETWORK_PREFERENCE);
	
	if(wifi.getState() == State.CONNECTED || mob.getState() == State.CONNECTED || wimax.getState() == State.CONNECTED
			|| ethernet.getState() == State.CONNECTED || bluth.getState() == State.CONNECTED
			|| dfalt.getState() == State.CONNECTED){
		showToast(2, "Network is available ");
		//Toast.makeText(getApplicationContext(), "Network is available ", Toast.LENGTH_SHORT).show();
		
		return true;
	}else {
		showToast(1,  "network is available ");
		//Toast.makeText(getApplicationContext(),, Toast.LENGTH_SHORT).show();
		
		return false;
	}
	
}

public void Register_btn_Click (View view){

		if(etUserName.length()<1) {
			showToast(2, "Enter User Name" );
			//Toast.makeText(context, "Enter User Name", Toast.LENGTH_SHORT).show();
			return;
		}
		else if(etPassword.length()<1) {
			showToast(2, "Enter Password" );
			//Toast.makeText(context, "Enter Password", Toast.LENGTH_SHORT).show();
			return;
		}
//	   try{
//			if(etPassword.length()<1) {
//				Toast.makeText(context, "Enter Password", Toast.LENGTH_SHORT).show();
//				return;
//			}
//			}catch(Exception e) {
//				Toast.makeText(context, "Enter Password", Toast.LENGTH_SHORT).show();
//				return;
//			}
//
//	   try{
//			if(etGroupId.length()<1) {
//				Toast.makeText(context, "Enter Organisation Id", Toast.LENGTH_SHORT).show();
//				return;
//			}
//			}catch(Exception e) {
//				Toast.makeText(context, "Enter Organisation Id", Toast.LENGTH_SHORT).show();
//				return;
//			}
//
//	   try{
//			if(etUserName.length()<1) {
//				Toast.makeText(context, "Enter User Name", Toast.LENGTH_SHORT).show();
//				return;
//			}
//			}catch(Exception e) {
//				Toast.makeText(context, "Enter User Name", Toast.LENGTH_SHORT).show();
//				return;
//			}
//	
	
	
	if(Utilss.CheckNet(context)) {
	new RegisteringInServer().execute("");
	}
	else
		showToast(2,  "Network Connectivity requered");
		//Toast.makeText(context, "Network Connectivity requered", Toast.LENGTH_LONG).show();

   }
/*
 *  asynchronous task for registration
 */
private class RegisteringInServer extends AsyncTask<String, Void, Boolean> {
	private final ProgressDialog dialog = new ProgressDialog(context);

	String response;
	
	protected void onPreExecute() {
		
		this.dialog.setMessage("Registering...");

		this.dialog.show();  
		this.dialog.setCancelable(false);
	}

	protected Boolean doInBackground(final String... args) {

		response = Utilss.setRegDetailFromServer(context,etGroupId.getText().toString(),
				etUserName.getText().toString(),etPassword.getText().toString(),tvDeviceId.getText().toString());  
		return true;  
	}

	protected void onPostExecute(final Boolean success) {

		try {
			if(response.trim().equals("1")) 
			{
				
				 Utilss.setSharedPreferences(context, "Responce", "Registerd");
				 showToast(1, "Successfully Registered" );
				//Toast.makeText(context, , Toast.LENGTH_SHORT).show();
				
				Intent intent = new Intent(Registration.this, Login.class);
				finish();
				startActivity(intent);	
			}
			else
				showToast(2,  ""+response.trim());
				//Toast.makeText(context, , Toast.LENGTH_SHORT).show();

			if (this.dialog.isShowing())  
			{
				this.dialog.dismiss();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  

	}

}



public void setupUI(View view) {

    //Set up touch listener for non-text box views to hide keyboard.
    if(!(view instanceof EditText)) {

        view.setOnTouchListener(new OnTouchListener() {

            public boolean onTouch(View v, MotionEvent event) {
                Utilss.hideSoftKeyboard(Registration.this);
                return false;
            }

        });
    }
}
public void showToast(int a,String t)
{ 
	 try {
		 LayoutInflater inflater = getLayoutInflater();
		 View layout = inflater.inflate(R.layout.successtoat,
		                                (ViewGroup) findViewById(R.id.ll_custoast_parent));
		 Animation bottomUp = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.bottom_up);
		 layout.startAnimation(bottomUp); 
		 ImageView image = (ImageView) layout.findViewById(R.id.ll_custoast_iv);
		 if(a==1) image.setImageResource(R.drawable.greentick);		 
		 else image.setImageResource(R.drawable.attentionred);			 
		 TextView text = (TextView) layout.findViewById(R.id.ll_custoast_msg);
		 text.setText(t);
		 Toast toast = new Toast(getApplicationContext());
		 toast.setGravity(Gravity.FILL_HORIZONTAL|Gravity.BOTTOM | Gravity.CENTER_VERTICAL, 0, 0);
		 toast.setDuration(Toast.LENGTH_LONG);
		 toast.setView(layout);
		 
		 toast.show(); 
	} catch (Exception e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	} 
}
}
