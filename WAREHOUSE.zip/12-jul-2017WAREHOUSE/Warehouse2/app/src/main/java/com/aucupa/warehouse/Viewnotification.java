package com.aucupa.warehouse;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;




import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.os.Bundle;
import android.text.format.Time;
import android.widget.ListView;
import android.widget.SimpleAdapter;

public class Viewnotification  extends Activity{
	
	ListView lv;
	SimpleAdapter myAdapter;
    Sqldatabase dbAdapter;
	String Today,currenttimestamp,endtimestamp;
	SimpleDateFormat dateFormat;
	Context context;
	int i=0;
	ArrayList<String[]> list =new ArrayList<String []>();
    ArrayList<HashMap<String, String>> myList = new ArrayList();
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.warehouse);
		this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		Date d=new Date();
		context=this;
		dateFormat = new SimpleDateFormat("dd/MM/yyyy"); 
		dbAdapter = new Sqldatabase(this);
		lv=(ListView)findViewById(R.id.listnotification);
		
	
	
	
	
	 Time today = new Time(Time.getCurrentTimezone());
	   today.setToNow();
	   Today= today.monthDay+"/"+(today.month+1)+"/"+today.year;
	   Calendar c = Calendar.getInstance();
	
	try {
	    Date dt = dateFormat.parse(Today); 
	    c.setTime(dt);
	    System.out.println( c.getTime());   
	    System.out.println(dt.toString());   
	   
	} catch (ParseException e) {
	    System.err.println("There's an error in the Date!");
	} 
	long currentdate = c.getTimeInMillis();
	
	try {  
	    Date dt = dateFormat.parse(Today); 
	    c.setTime(dt);
	    c.add( Calendar.DATE,8 );
	    System.out.println( c.getTime());   
	    System.out.println(dt.toString());   
	  
	} catch (ParseException e) {
	    System.err.println("There's an error in the Date!");
	} 
	long Enddate = c.getTimeInMillis();
	
	String st= currentdate+"";
	String en= Enddate+"";
	
	currenttimestamp = st.substring(0, Math.min(st.length(), 10));
	endtimestamp = en.substring(0, Math.min(en.length(), 10)); 
	
	Utils.setSharedPreferences(context, "Current", currenttimestamp);
	Utils.setSharedPreferences(context, "End", endtimestamp); 
    Listnotification();
	
	}
	
	public void Listnotification(){
		

		 this.myList.clear();
		   
 
		
		}
			

public void onBackPressed() {
		
		
		Intent i = new Intent(Viewnotification.this, Select_Activity.class);
		startActivity(i);
		finish();
		
	}
	

}
