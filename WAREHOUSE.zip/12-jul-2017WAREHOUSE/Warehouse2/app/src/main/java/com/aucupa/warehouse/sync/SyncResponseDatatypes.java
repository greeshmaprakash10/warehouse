package com.aucupa.warehouse.sync;

import com.aucupa.warehouse.sync.SyncResponseDataWrapper.SyncFromServerItemDetailsResponseData;
import com.aucupa.warehouse.sync.SyncResponseDataWrapper.SyncFromServerLocationInResponseData;
import com.aucupa.warehouse.sync.SyncResponseDataWrapper.SyncFromServerLocationOutResponseData;
import com.aucupa.warehouse.sync.SyncResponseDataWrapper.SyncFromServerStockInResponseData;
import com.aucupa.warehouse.sync.SyncResponseDataWrapper.SyncFromServerStockOutResponseData;
import com.aucupa.warehouse.sync.SyncResponseDataWrapper.SyncFromServerSupplierDetailsResponseData;
import com.aucupa.warehouse.sync.SyncResponseDataWrapper.SyncFromServerWareDetailsResponseData;
import com.aucupa.warehouse.sync.SyncResponseDataWrapper.SyncLivestockResponseData;
import com.aucupa.warehouse.sync.SyncResponseDataWrapper.SyncToServerResponseData;

import java.util.ArrayList;


public class SyncResponseDatatypes {
	
	public static class Response
	{
		private static String _SUCCESS="200";
		private static String _NODATA="300";
		private static String _FAILED="404";
		private static String _NOTREGISTER="500";
		
		public String status=_FAILED;
		public String status_msg="";
		
		public boolean isSuccess(){
			return status.toString().equals(_SUCCESS);
		}
		public boolean isNodata(){
			return status.toString().equals(_NODATA);
		}
		public boolean isActive(){
			return status.toString().equals(_NOTREGISTER);
		}
	}
	
	public static class SyncToServerResponse extends Response{
		public  ArrayList<SyncToServerResponseData> data;
	}
	
	public static class SyncFromServerStockInResponse extends Response{
		public ArrayList<SyncFromServerStockInResponseData> data;
	}
	
	public static class SyncFromServerStockOutResponse extends Response{
		public ArrayList<SyncFromServerStockOutResponseData> data;
	}
	public static class SyncFromServerLocationInResponse extends Response{
		public ArrayList<SyncFromServerLocationInResponseData> data;
	}
	public static class SyncFromServerLocationOutResponse extends Response{
		public ArrayList<SyncFromServerLocationOutResponseData> data;
	}
	public static class SyncFromServerItemDetailsResponse extends Response{
		public ArrayList<SyncFromServerItemDetailsResponseData> data;
	}
	public static class SyncFromServerWareDetailsResponse extends Response{
		public ArrayList<SyncFromServerWareDetailsResponseData> data;
	}
	public static class SyncFromServerSupplierDetailsResponse extends Response{
		public ArrayList<SyncFromServerSupplierDetailsResponseData> data;
	}
	public static class SyncLivestockResponse extends Response{
		public ArrayList<SyncLivestockResponseData> data;
	}
	
}
