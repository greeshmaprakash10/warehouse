package com.aucupa.warehouse.adapter;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.TextView;

import com.aucupa.warehouse.R;

/**
 * Created by roy on 03-Jul-17.
 */

public class ItemAdapter extends CursorAdapter
{
    TextView acc,amount1,item_id;
    TextView date1,remark1;
    String type,item,amount,date,remark;
    public ItemAdapter(Context context, Cursor c)
    {
        super(context, c);
    }
    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        View view = layoutInflater.inflate(R.layout.signma_item,null);
        return view;
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor)
    {
        acc= (TextView) view.findViewById(R.id.accdata);
//        item_id=(TextView)view.findViewById(R.id.item_id);
//        amount1= (TextView) view.findViewById(R.id.amount1);
//        date1=(TextView) view.findViewById(R.id.date1);
//        remark1=(TextView) view.findViewById(R.id.remark1);

         item=cursor.getString(cursor.getColumnIndexOrThrow("_id"));
         type=cursor.getString(cursor.getColumnIndexOrThrow("Item_code"));

//        amount= cursor.getString(cursor.getColumnIndexOrThrow("Warehousecode"));
//        date= cursor.getString(cursor.getColumnIndexOrThrow("TotalQuantity"));
//        remark=cursor.getString(cursor.getColumnIndexOrThrow("LotNumber"));


        acc.setText(type);
//        item_id.setText(item);
//        amount1.setText(amount);
//        date1.setText(date);
//        remark1.setText(remark);
    }
}
