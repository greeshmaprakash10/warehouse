package com.aucupa.warehouse;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.format.Time;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.aucupa.warehouse.adapter.ItemAdapter;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import static com.aucupa.warehouse.Sqldatabase.key_warehouse_createdtime;

public class Add_Stock extends Activity {
	ListView list_id,listcode;
	ListAdapter listAdapter;
	int currentdatebtnid;
	SimpleDateFormat datef;
	Button btnarrival;
	String stocktype_Selected;
	Spinner spinware;
	ItemAdapter itemAdapter;
	TextView txtorderorintent,unit;
	TableRow trOrderIntent,trOrdernumber,trsupplier,trwarehousecode,trtotalqty;
	EditText etOrdernumber,etTotalQuantity,etLotnumber,spinsupplier,itemcode;
	String stItemcode,stOrdernumber,stLotnumber,stTotalquantity,stsuppliercode,stwarehousecode,id,itemid,warehouse,select,supplyid,supplier_id;
	boolean flag_insert=true;
	ArrayList<String> itemcodelist;
	ArrayList<String> warenamecodelist;
	Sqldatabase db;
	Context context;
	
	@Override 
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_add__stock);
		context=this;
		db = new Sqldatabase(this);
		btnarrival=(Button)findViewById(R.id.btnarrivaldate);
		trOrderIntent=(TableRow)findViewById(R.id.tr_orderintent);
		trOrdernumber=(TableRow)findViewById(R.id.tr_ordernumber);
		trsupplier=(TableRow)findViewById(R.id.tr_suppliername);
		trwarehousecode=(TableRow)findViewById(R.id.tr_warename);
		trtotalqty=(TableRow)findViewById(R.id.tr_totalquantity);

		ImageButton _slectsupplier=(ImageButton)findViewById(R.id.ib_bill_acivity_select_customer);
		ImageButton selectcode=(ImageButton)findViewById(R.id.itemcode_select_icon);
		txtorderorintent=(TextView)findViewById(R.id.txt_orderorintent);
		spinsupplier=(EditText) findViewById(R.id.et_bill_acivity_customer_mob);
		spinware=(Spinner)findViewById(R.id.spinware);

		//unit=(TextView)findViewById(R.id.uom);
		
		etOrdernumber=(EditText)findViewById(R.id.editordernumber);
		itemcode=(EditText)findViewById(R.id.itemcode_selector);
		etTotalQuantity=(EditText)findViewById(R.id.edittotalqty);
		etLotnumber=(EditText)findViewById(R.id.editlotno);
		etLotnumber.requestFocus();
		Date d=new Date(System.currentTimeMillis());
		datef=new SimpleDateFormat("dd/MM/yyyy");
		//autoCompletefill();
		selectcode.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				String item=itemcode.getText().toString();
				slectitemcode(item);
			}
		});


		_slectsupplier.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				String supplier=spinsupplier.getText().toString();
				selectsupplier(supplier);
			}
		});
		fillwarehouse();
		spinware.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
				// TODO Auto-generated method stub
				String select=((TextView)view).getText().toString();
//                int indexstart=select.indexOf("(")+1;
//                int indexend=select.indexOf(")");
//                stwarehousecode=select.substring(indexstart, indexend);
				stwarehousecode=select;
			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				// TODO Auto-generated method stub
				spinware.setSelection(0);
			}
		});
}
	public void slectitemcode(final String itemname)
	{
		try {
			final Dialog dialogs = new Dialog(Add_Stock.this);
			dialogs.requestWindowFeature(Window.FEATURE_NO_TITLE);
			dialogs.setContentView(R.layout.dialog_select_itemcode);
			listcode=(ListView)dialogs.findViewById(R.id.list14);
			EditText et_cstomer_name = (EditText) dialogs.findViewById(R.id.et_dialog_customer_name);
			et_cstomer_name.setText(itemname+ "" + et_cstomer_name.getText().toString().trim());
			String searchText = et_cstomer_name.getText().toString();
			Sqldatabase handler = new Sqldatabase(Add_Stock.this);
			// final Cursor cursors = handler.getdata(searchText);
			final Cursor cursors = handler.getdata(searchText);
			itemAdapter = new ItemAdapter(Add_Stock.this, cursors);
			listcode.setAdapter(itemAdapter);
			listcode.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
					String Supplier = cursors.getString(1);
					itemcode.setText(Supplier);
					dialogs.hide();

				}

			});
			dialogs.show();
			dialogs.setCancelable(true);

			et_cstomer_name.addTextChangedListener(new TextWatcher() {
				@Override
				public void beforeTextChanged(CharSequence s, int start, int count, int after)
				{

				}

				@Override
				public void onTextChanged(CharSequence s, int start, int before, int count) {

				}

				@Override
				public void afterTextChanged(Editable s) {
					EditText et_cstomer_name = (EditText) dialogs.findViewById(R.id.et_dialog_customer_name);
					String searchText = et_cstomer_name.getText().toString();
					Sqldatabase handler = new Sqldatabase(Add_Stock.this);
					final Cursor cursor = handler.getItemCodes();
					itemAdapter = new ItemAdapter(Add_Stock.this, cursor);
					listcode.setAdapter(itemAdapter);
					listcode.setOnItemClickListener(new AdapterView.OnItemClickListener() {
						@Override
						public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
							String Supplier = cursor.getString(1);
							itemcode.setText(Supplier);
							dialogs.hide();

						}

					});
					dialogs.show();
					dialogs.setCancelable(true);
				}
			});
			dialogs.show();
			dialogs.setCancelable(true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void selectsupplier(final String supplier)
	{
		try {
			final Dialog dialog = new Dialog(Add_Stock.this);
			dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
			dialog.setContentView(R.layout.dialog_customer_select);
			list_id = (ListView) dialog.findViewById(R.id.list1);
			EditText et_cstomer_name = (EditText) dialog.findViewById(R.id.et_dialog_customer_name);
			et_cstomer_name.setText(supplier + "" + et_cstomer_name.getText().toString().trim());
			String searchText = et_cstomer_name.getText().toString();
			Sqldatabase handler = new Sqldatabase(Add_Stock.this);
			final Cursor cursor = handler.getDetails(searchText);
			listAdapter = new com.aucupa.warehouse.adapter.ListAdapter(Add_Stock.this, cursor);
			list_id.setAdapter(listAdapter);
			list_id.setOnItemClickListener(new OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
					String supplier = cursor.getString(2);
					spinsupplier.setText(supplier);
					dialog.hide();
				}

			});
			et_cstomer_name.addTextChangedListener(new TextWatcher() {
				@Override
				public void beforeTextChanged(CharSequence s, int start, int count, int after) {

				}

				@Override
				public void onTextChanged(CharSequence s, int start, int before, int count) {

				}

				@Override
				public void afterTextChanged(Editable s) {
					EditText et_cstomer_name = (EditText) dialog.findViewById(R.id.et_dialog_customer_name);
					String searchText = et_cstomer_name.getText().toString();

					Sqldatabase handler = new Sqldatabase(Add_Stock.this);
					final Cursor cursor = handler.getDataDetails();
					listAdapter = new com.aucupa.warehouse.adapter.ListAdapter(Add_Stock.this, cursor);
					list_id.setAdapter(listAdapter);
					list_id.setOnItemClickListener(new OnItemClickListener() {
						@Override
						public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
							String supplier = cursor.getString(2);
							spinsupplier.setText(supplier);
							dialog.hide();

						}

					});
					dialog.show();
					dialog.setCancelable(true);
				}
			});
			dialog.show();
			dialog.setCancelable(true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}

	public void fillwarehouse(){
		warenamecodelist=new ArrayList<>();
		warenamecodelist.clear();
		Sqldatabase db=new Sqldatabase(getApplicationContext());
		Cursor cc=db.getWarehouseDetails();
		if(cc.getCount()>0)
		{
			warenamecodelist.add("--Select--");
			while(cc.moveToNext())
			{
				warenamecodelist.add(cc.getString(2).toString());
			}
		}
		ArrayAdapter<String> adapter =new ArrayAdapter<String>(getApplicationContext(),R.layout.autolistview,warenamecodelist);
		spinware.setAdapter(adapter);
	}
	
//	public void autoCompletefill() {
//		itemcodelist=new ArrayList<>();
//		itemcodelist.clear();
//		Sqldatabase db=new Sqldatabase(Add_Stock.this);
//        Cursor c=db.getItemCodes();
//		if(c.getCount()>0){
//            itemcodelist.add("Item Code");
//			while (c.moveToNext()) {
//
//				itemcodelist.add(c.getString(1));
//			}
//			ArrayAdapter<String> adapter =new ArrayAdapter<String>(getApplicationContext(),R.layout.autolistview,itemcodelist);
//			etItemcode.setAdapter(adapter);
//		}
//
//	}
	public void clicktoSave(View v){ 
		
		flag_insert=true;
		if(
		stocktype_Selected=="1" && etOrdernumber.getText().toString().length()<1){
			String s=etOrdernumber.getText().toString();
			String msg="Enter "+etOrdernumber.getHint().toString();
				showToast(0,msg);
				flag_insert=false;
			
		}
		else if(etTotalQuantity.length()<1||Float.parseFloat(etTotalQuantity.getText().toString())==0){
			showToast(0,"Enter Toatal Quantity");
			flag_insert=false;
		}
		else if(etLotnumber.length()<1) {
			showToast(0, "Enter Lot Number ");
			flag_insert = false;
		}
		else{
			stOrdernumber=etOrdernumber.getText().toString();
			stTotalquantity=etTotalQuantity.getText().toString();
			stLotnumber=etLotnumber.getText().toString();
			stsuppliercode=spinsupplier.getText().toString();
			stItemcode=itemcode.getText().toString();
			flag_insert=true;
		}
		
		
		try {
						
				if(flag_insert) {
					Cursor curs = db.sqlQuery("Select * from " + db.tbl_Items +
							" where " + db.key_warehouse_item_itemcode + " = '"
							+ stItemcode + "'");
					if (curs.getCount() <= 0) {
						showToast(0, "No Item Code Found");
						flag_insert = false;
					}
				}
			if(flag_insert) {
				Sqldatabase db = new Sqldatabase(getApplicationContext());
				Cursor cursor = db.getUOMStock(stLotnumber);
				int count = cursor.getCount();
				if (count > 0) {
					showToast(0, "Lot Number Already Exist !");
				} else {
					Cursor c = db.getItemCodes(stItemcode);
					if (c.moveToNext()) {
						itemid = c.getString(0);
					}
				Cursor c1=db.getWarehouseDetails(stwarehousecode);
				if(c1.moveToNext())
				{
					warehouse=c1.getString(c1.getColumnIndexOrThrow("warehouse_id"));
				}
					Cursor c2 = db.getSupplierId(stsuppliercode);
					if (c2.moveToNext()) {
						supplier_id = c2.getString(c2.getColumnIndexOrThrow("supplier_id"));
					}
					ContentValues cv = new ContentValues();
					cv.put(db.key_warehouse_addstock_Stocktype, "1");
					cv.put(db.key_warehouse_addstock_itemid, itemid);
					cv.put(db.key_warehouse_addstock_itemcode, stItemcode);
					cv.put(db.key_warehouse_addstock_ordernumber, stOrdernumber);
					cv.put(db.key_warehouse_addstock_warehousecode, warehouse);
					cv.put(db.key_warehouse_addstock_suppliercode, supplier_id);
					cv.put(db.key_warehouse_addstock_totalquantity, stTotalquantity);
					cv.put(db.key_warehouse_addstock_lotnumber, stLotnumber);
					cv.put(key_warehouse_createdtime, Utils.getSystemTimeStamp());
					cv.put(db.key_warehouse_syncerrorstatus, "0");
					cv.put(db.key_warehouse_syncstatus, "0");

					if (db.sqlins(db.tbl_warehouse_addsock, cv) > 0) {
						showToast(1, "Stock Added Successfully ");
						Intent i = new Intent(Add_Stock.this, Select_Activity.class);
						startActivity(i);

						if (Utilss.CheckNet(getApplicationContext())) {
							new Thread() {
								public void run() {
//								SyncServerRequest synctoserverRequest;
//								synctoserverRequest=((WhApp)getApplication()).syncRequest;
//								synctoserverRequest.syncStockINRequest();
									Sqldatabase db = new Sqldatabase(getApplicationContext());
									SharedPreferences sharedPreferences = getSharedPreferences("sample", MODE_PRIVATE);
									String name = sharedPreferences.getString("username", "");
									Cursor c1 = db.getMobileuser(name);
									if (c1.moveToNext()) {
										id = c1.getString(c1.getColumnIndex("enduser_id"));
									}
									db.postAddStock(getApplicationContext(), "Add_Stock", id);
								}
							}.start();

						} else {
							Toast.makeText(getApplicationContext(), "No internet Connection", Toast.LENGTH_SHORT).show();
						}
					}
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public void clearvalues(){
		btnarrival.setText(datef.format(new Date(System.currentTimeMillis())));
		etOrdernumber.setText("");
		etTotalQuantity.setText("");
		etLotnumber.setText("");
		Date d=new Date(System.currentTimeMillis());
		datef=new SimpleDateFormat("dd/MM/yyyy");
		flag_insert=true;
	}
	
	protected void showArrivalDate(int id) {
		// TODO Auto-generated method stub
		currentdatebtnid=id;
		OnDateSetListener dsl=new OnDateSetListener() {
			
			@Override
			public void onDateSet(DatePicker view, int year, int monthOfYear,
					int dayOfMonth) {
				// TODO Auto-generated method stub
				String date=String.valueOf(year)+" "+String.valueOf(monthOfYear)+" "+String.valueOf(dayOfMonth);
				
				
				
				Date d=new Date(System.currentTimeMillis());
				d.setYear(year-1900);
				d.setMonth(monthOfYear);
				d.setDate(dayOfMonth);
				setArrivaldate(d);
			}
		};
		Date temp=new Date(System.currentTimeMillis());
		Time today = new Time(Time.getCurrentTimezone());
		today.setToNow();
		DatePickerDialog dial=new DatePickerDialog(this,dsl,today.year,today.month,today.monthDay);
		dial.getDatePicker().setCalendarViewShown(false);
		dial.show();
	}
	
	public void setArrivaldate(Date date){
		Button b=(Button)findViewById(currentdatebtnid);
		b.setText(datef.format(date));
		try {
			java.util.Date d=datef.parse(b.getText().toString());
			System.out.println(d.getTime());
		} catch (Exception  e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println();
	    } 

	public boolean checkdate(String stringdate,int id){
		
		java.util.Date curdate = null,arrdate = null;
		try
		{
			 curdate=datef.parse(datef.format(new Date(System.currentTimeMillis())));
			 arrdate=datef.parse(stringdate.toString());
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		switch (id) {
		case R.id.btnarrivaldate:
			if(curdate.compareTo(arrdate)<0){
				flag_insert=false;
				return false;
			}
			break;
		default:
			break;
		}
		return true;
	}
	 public void showToast(int a,String t)
     { 
     	 try {
     		 LayoutInflater inflater = getLayoutInflater();
     		 View layout = inflater.inflate(R.layout.successtoat,
     		                                (ViewGroup) findViewById(R.id.ll_custoast_parent));

     		 ImageView image = (ImageView) layout.findViewById(R.id.ll_custoast_iv);
     		 if(a==1) image.setImageResource(R.drawable.greentick);		 
     		 else image.setImageResource(R.drawable.attentionred);			 
     		 TextView text = (TextView) layout.findViewById(R.id.ll_custoast_msg);
     		 text.setText(t);
     		 Toast toast = new Toast(getApplicationContext());
     		 toast.setGravity(Gravity.FILL_HORIZONTAL|Gravity.BOTTOM | Gravity.CENTER_VERTICAL, 0, 0);
     		 toast.setDuration(Toast.LENGTH_SHORT);
     		 toast.setView(layout);
     		 toast.show();
     	} catch (Exception e1) {
     		// TODO Auto-generated catch block
     		e1.printStackTrace();
     	} 
     }
	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		super.onBackPressed();
		Intent i1 =new Intent(getApplicationContext(),Select_Activity.class);
		i1.putExtra("syncstatus",true);
		startActivity(i1);
		finish();
	}
}
