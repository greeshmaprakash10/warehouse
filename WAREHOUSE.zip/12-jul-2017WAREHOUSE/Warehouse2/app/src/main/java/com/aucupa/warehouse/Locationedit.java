package com.aucupa.warehouse;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Locationedit extends Activity {
	Sqldatabase db; 
	String stockid="";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.locationedit);
		Button save=(Button)findViewById(R.id.bt_locedit_save);
		stockid=getIntent().getStringExtra("stock_id");  

		db = new Sqldatabase(this);
		save.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				EditText locid,whid,rrow,rclmn,qty,pno;
				TextView stoc=(TextView)findViewById(R.id.txt_locedit_stokid);
				stoc.setText(stockid);
				locid=(EditText)findViewById(R.id.et_locedit_locid);
				whid=(EditText)findViewById(R.id.et_locedit_whid);
				rrow=(EditText)findViewById(R.id.et_locedit_rrow);
				rclmn=(EditText)findViewById(R.id.et_locedit_rcolm);
				qty=(EditText)findViewById(R.id.et_locedit_qty);
				pno=(EditText)findViewById(R.id.et_locedit_pno);
				String loc_id,wh_id,r_row,r_clmn,qnty,p_no;
				loc_id=locid.getText().toString();
				wh_id=whid.getText().toString();
				r_row=rrow.getText().toString();
				r_clmn=rclmn.getText().toString();
				qnty=qty.getText().toString();
				p_no=pno.getText().toString();
				//TODO validation
				//if("".equalsIgnoreCase(loc_id)) Toast.makeText(getApplicationContext(), "Enter Location ID", Toast.LENGTH_SHORT).show();
				 if("".equalsIgnoreCase(wh_id))Toast.makeText(getApplicationContext(), "Enter WareHouse ID", Toast.LENGTH_SHORT).show();
				else if("".equalsIgnoreCase(r_row))Toast.makeText(getApplicationContext(), "Enter RakeRow", Toast.LENGTH_SHORT).show();
				else if("".equalsIgnoreCase(r_clmn))Toast.makeText(getApplicationContext(), "Enter RakeColumn", Toast.LENGTH_SHORT).show();
				else if("".equalsIgnoreCase(qnty))Toast.makeText(getApplicationContext(), "Enter Quantity", Toast.LENGTH_SHORT).show();
				else if("".equalsIgnoreCase(p_no))Toast.makeText(getApplicationContext(), "Enter Pallet No", Toast.LENGTH_SHORT).show();
				else
				{
					//TODO save details 
					
					try { 
						ContentValues cv=new ContentValues();
						//cv.put(db.key_warehouse_updatelocation_locationid, loc_id);
						cv.put(db.key_warehouse_updatelocation_warehouseid, wh_id);
						cv.put(db.key_warehouse_updatelocation_rakerow, r_row);
						cv.put(db.key_warehouse_updatelocation_rakecolumn, r_clmn);
						cv.put(db.key_warehouse_updatelocation_qty, qnty);
						cv.put(db.key_warehouse_updatelocation_palletno, p_no);
						cv.put(db.key_warehouse_syncstatus, "1");
						cv.put(db.key_warehouse_updatelocation_refposition, " "); 
						cv.put(db.key_warehouse_updatelocation_stockid, stockid);
						
						long stockid=db.sqlins(db.tbl_warehouse_updatelocation, cv);
						if(stockid>0)
							{Toast.makeText(getApplicationContext(), "Added Successfully", Toast.LENGTH_SHORT).show();
						onBackPressed();}
					} catch (Exception e) {
						// TODO Auto-generated catch block 
						e.printStackTrace();
					}
				}
				
			}
			
		});
	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		super.onBackPressed();
	
	}
}
