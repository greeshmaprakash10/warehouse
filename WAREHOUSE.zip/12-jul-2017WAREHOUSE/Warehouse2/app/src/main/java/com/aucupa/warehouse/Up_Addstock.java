package com.aucupa.warehouse;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.aucupa.warehouse.adapter.ItemAdapter;
import com.aucupa.warehouse.adapter.ListAdapter;

import java.util.ArrayList;

public class Up_Addstock extends Activity {
    TextView lotno;
    TextView quantity;
    TextView unit;
    TextView supplier_names;
    TextView item_names;
    TextView ordernum;
    TextView spinware;
    String itemcode1,lotno1,quantity1,supplier_name1,stwarehousecode,ordernum1,supplier_id,ware_id,label,item_id,id,result,message;
//    Spinner spinware,itemcode;
    Spinner itemcode;
    ArrayList<String> itemcodelist;
    ArrayList<String> warenamecodelist;
    ListView list_id,listcode;
    ListAdapter listAdapter;
    ItemAdapter itemAdapter;
    boolean flag_insert=true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.up_addstocks);
        lotno = (TextView) findViewById(R.id.qa_editlotno);
        lotno.requestFocus();
        quantity = (EditText) findViewById(R.id.qa_edittotalqty);
        unit = (EditText) findViewById(R.id.qa_editunit);
        supplier_names = (TextView) findViewById(R.id.et_bill_acivity_customer_mob);
        item_names = (TextView) findViewById(R.id.et_bill_acivity_item_code);
        ordernum = (EditText) findViewById(R.id.qa_editordernumber);
        spinware = (EditText) findViewById(R.id.qa_warehouse);

        //spinware = (Spinner) findViewById(R.id.qa_spinware);
        //String passedArg = getIntent().getExtras().getString("item");
        Bundle bundle = getIntent().getExtras();
        message = bundle.getString("item");
        //itemSelect(message);
        Sqldatabase db = new Sqldatabase(Up_Addstock.this);
        Cursor c = db.getaddSupplierdata(message);
        if (c.moveToNext()) {
            String supp = c.getString(c.getColumnIndex("supplier_name"));
            supplier_names.setText(supp);
        }

        Cursor cs = db.getItemCodesstockdatas(message);
        if (cs.moveToNext()) {
            String supps = cs.getString(cs.getColumnIndex("Item_code"));
            item_names.setText(supps);
        }
        Cursor ce = db.getWarehousesstockdatas(message);
        if (ce.moveToNext())
        {
            String lots = ce.getString(ce.getColumnIndex("warehouse_no"));
            spinware.setText(lots);
        }
        Cursor cd=db.getStockQuanity(message);
        if(cd.moveToNext())
        {
            String qty= cd.getString(cd.getColumnIndex("TotalQuantity"));
            quantity.setText(qty);
        }
        Cursor cp = db.getunitOMdatas(message);
        if (cp.moveToNext())
        {
            String unitOM =cp.getString (cp.getColumnIndex("Item_Unit"));
            unit.setText(unitOM);
        }
    }
    public void clicktoSave(View view)
    {


        try {

            lotno1=lotno.getText().toString();
            quantity1=quantity.getText().toString();
            supplier_name1=supplier_names.getText().toString();
            ordernum1=ordernum.getText().toString();
            label=item_names.getText().toString();
            stwarehousecode=spinware.getText().toString();

            Sqldatabase db=new Sqldatabase(Up_Addstock.this);
            Cursor cursor = db.getUOMStock(lotno1);
            int count = cursor.getCount();
            if (count > 0)
            {
                showToast(0, "Lot Number Already Exist !");
            }
            else
            {
                Cursor c = db.getSupplierId(supplier_name1);
                if (c.moveToNext())
                {
                    supplier_id = c.getString(c.getColumnIndex("supplier_id"));
                }
                Cursor cs = db.getItemCodes(label);
                if (cs.moveToNext())
                {
                    item_id = cs.getString(cs.getColumnIndex("_id"));
                }
                Cursor c4 = db.getWarehouseDetails(stwarehousecode);
                if (c4.moveToNext())
                {
                    ware_id = c4.getString(c4.getColumnIndex("warehouse_id"));
                }
               // long results=db.insertStock(item_id,label, lotno1,quantity1,ware_id, supplier_id,ordernum1);

                db.getCount(message,lotno1);
                showToast(1, "Stock Added Successfully ");
                    Intent i = new Intent(Up_Addstock.this, Select_Activity.class);
                    startActivity(i);
                    if (Utilss.CheckNet(getApplicationContext())) {
                        new Thread() {
                            public void run() {
//								SyncServerRequest synctoserverRequest;
//								synctoserverRequest=((WhApp)getApplication()).syncRequest;
//								synctoserverRequest.syncStockINRequest();
                                Sqldatabase db = new Sqldatabase(getApplicationContext());
                                SharedPreferences sharedPreferences = getSharedPreferences("sample", MODE_PRIVATE);
                                String name = sharedPreferences.getString("username", "");
                                Cursor c1 = db.getMobileuser(name);
                                if (c1.moveToNext())
                                {
                                    id = c1.getString(c1.getColumnIndex("enduser_id"));
                                }
                                db.postAddStock(getApplicationContext(), "Add_Stock", id);
                            }
                        }.start();

                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(), "No internet Connection", Toast.LENGTH_SHORT).show();
                    }
                }

        }catch (Exception e) {
            e.printStackTrace();
        }
    }




    @Override
    public void onBackPressed() {
        Intent i=new Intent(Up_Addstock.this,Select_Activity.class);
        startActivity(i);
    }
    public void showToast(int a,String t)
    {
        try {
            LayoutInflater inflater = getLayoutInflater();
            View layout = inflater.inflate(R.layout.successtoat,
                    (ViewGroup) findViewById(R.id.ll_custoast_parent));

            ImageView image = (ImageView) layout.findViewById(R.id.ll_custoast_iv);
            if(a==1) image.setImageResource(R.drawable.greentick);
            else image.setImageResource(R.drawable.attentionred);
            TextView text = (TextView) layout.findViewById(R.id.ll_custoast_msg);
            text.setText(t);
            Toast toast = new Toast(getApplicationContext());
            toast.setGravity(Gravity.FILL_HORIZONTAL|Gravity.BOTTOM | Gravity.CENTER_VERTICAL, 0, 0);
            toast.setDuration(Toast.LENGTH_SHORT);
            toast.setView(layout);
            toast.show();
        } catch (Exception e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
    }




}
