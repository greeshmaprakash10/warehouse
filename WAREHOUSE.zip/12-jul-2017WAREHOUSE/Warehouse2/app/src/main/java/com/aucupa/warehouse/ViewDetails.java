package com.aucupa.warehouse;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ListAdapter;
import android.widget.ListView;

/**
 * Created by roy on 21-Jun-17.
 */

public class ViewDetails extends Activity {
    ListView list_id;
    ListAdapter listAdapter;
    String itemid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);

        list_id=(ListView)findViewById(R.id.list_id);
        Sqldatabase handler=new Sqldatabase(ViewDetails.this);
        //Cursor cursor=handler.getDetails();
//        listAdapter =new com.aucupa.warehouse.adapter.ListAdapter(this,cursor);
//        list_id.setAdapter(listAdapter);

//        list_id.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                itemid=String.valueOf(listAdapter.getItemId(position));
//                Intent intent=new Intent(ViewDetails.this,DisplayListDetails.class);
//                intent.putExtra("itemid",itemid);
//                startActivity(intent);
//
//            }
//        });

    }
}
