package com.aucupa.warehouse;

import java.util.ArrayList;
import java.util.List;

import android.annotation.SuppressLint;
import android.app.ActionBar.LayoutParams;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Point;
import android.os.Bundle;
import android.support.v4.widget.SimpleCursorAdapter;
import android.support.v4.widget.SimpleCursorAdapter.ViewBinder;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnGroupClickListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.aucupa.warehouse.view.AnimatedExpandableListView;
import com.aucupa.warehouse.view.AnimatedExpandableListView.AnimatedExpandableListAdapter;
import com.google.gson.FieldNamingStrategy;
public class ViewLocation extends Activity {

	private AnimatedExpandableListView listView;
	private ExampleAdapter adapter;
	static ListView locationlist; 
	static Cursor cs1;
	static Sqldatabase db1; 
	static int width=500;
	static int height=700;
	static SimpleCursorAdapter adapt;
	static Boolean alertstatus;
	public static Boolean byname=true;
	
	TextView edittxtclear;
	EditText serchedt; 
	Cursor cs;
	Context context;
	public static Context cnt;
	Sqldatabase db;
	
	public static Activity activity;

	@SuppressLint("NewApi") 
	@Override   
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_view_location);
		
		context=ViewLocation.this;
		db=new Sqldatabase(context);
		db1=db;
		cnt=context;
		activity=this;
		
		edittxtclear=(TextView)findViewById(R.id.txt_viewsk_sclear);
		serchedt=(EditText)findViewById(R.id.edt_viewloc_search_field);

		List<GroupItem> items = new ArrayList<GroupItem>();
		
		
		
		edittxtclear.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				serchedt.setText(null);
			}
		});

		serchedt.addTextChangedListener(new TextWatcher() {
			
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				// TODO Auto-generated method stub
				 
			} 
			
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub 
				try { 
					String where=Sqldatabase.key_warehouse_issuestock_issuecode+" like '"+serchedt.getText().toString()+"%' ";
					cs=db.sqlQuery("Select distinct("+db.key_warehouse_issuestock_issuecode+") from "+db.tbl_warehouse_issuestock+" where "+where); 
					if(cs.getCount()>0)
					{
						SetupListitems(cs);
					}
				
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
	
	try{
//		Cursor citem=db.getdb().query(true,
//				db.tbl_warehouse_issuestock,
//				new String[]{db.key_warehouse_issuestock_issuecode},
//				null, null, null, null, null,null,null);
		Cursor citem=db.sqlQuery("Select distinct("+db.key_warehouse_issuestock_issuecode+") from "+db.tbl_warehouse_issuestock); //by roy

		SetupListitems(citem);
	}catch(Exception e){ 
		e.printStackTrace();
	}
		
		listView.setOnGroupClickListener(new OnGroupClickListener() {
 
			@Override
			public boolean onGroupClick(ExpandableListView parent, View v,
					int groupPosition, long id) {
				// We call collapseGroupWithAnimation(int) and
				// expandGroupWithAnimation(int) to animate group
				// expansion/collapse.
				if (listView.isGroupExpanded(groupPosition)) {
					listView.collapseGroupWithAnimation(groupPosition);
				} else {
					listView.expandGroupWithAnimation(groupPosition);
				}
				return true;
			}

		});

		// Set indicator (arrow) to the right
		Display display = getWindowManager().getDefaultDisplay();
		Point size = new Point();
		display.getSize(size);
		int width = size.x;
		//Log.v("width", width + "");
		Resources r = getResources();
		int px = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
				50, r.getDisplayMetrics());
		if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.JELLY_BEAN_MR2) {
			listView.setIndicatorBounds(width - px, width);
		} else {
			listView.setIndicatorBoundsRelative(width - px, width);
		}
	}
	
	@SuppressLint("NewApi")
	public void SetupListitems(Cursor citem){
		List<GroupItem> items = new ArrayList<GroupItem>();
		if(citem.getCount()>0){ 
			while(citem.moveToNext()) {
				GroupItem item = new GroupItem();
				
				item.title = citem.getString(0).toString();
//				Cursor citems=db.getdb().query(false,
//						db.tbl_warehouse_issuestock+","+db.tbl_Items,
//						new String[]{db.key_warehouse_issuestock_issueid,
//								db.key_warehouse_item_itemname,
//								db.key_warehouse_issuestock_location_status,  
//								db.key_warehouse_issuestock_IssuedQty},
//						db.key_warehouse_issuestock_issuecode+" = ? and "+db.key_warehouse_item_itemcode+"="+db.key_warehouse_issuestock_itemcode, new String[]{citem.getString(0).toString()}, null, null, null,null,null);
				Cursor citems=db.sqlQuery("Select " +db.key_warehouse_issuestock_issueid+","+db.key_warehouse_item_itemname //TODO by roy
						+","+db.key_warehouse_issuestock_location_status+","+db.key_warehouse_issuestock_IssuedQty+
						" from "+db.tbl_warehouse_issuestock+","+db.tbl_Items+" where "+db.key_warehouse_issuestock_issuecode+"='"+citem.getString(0).toString()
						+"'and "+db.key_warehouse_item_itemcode+"="+db.key_warehouse_issuestock_itemcode);
				while(citems.moveToNext()) {
					ChildItem child = new ChildItem();
					child.title = citems.getString(1).toString();
					child.loction=citems.getString(2).toString();
					child.issueid=citems.getString(0).toString();
					child.qty=citems.getString(3).toString();
					item.items.add(child);
				}

				items.add(item);
			}  
		}
		adapter = new ExampleAdapter(this);
		adapter.setData(items);

		listView = (AnimatedExpandableListView) findViewById(R.id.list_view);
		listView.setAdapter(adapter);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if (item.getItemId() == android.R.id.home) {
			finish();
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	private static class GroupItem {
		String title;
		List<ChildItem> items = new ArrayList<ChildItem>();
	}

	private static class ChildItem {
		String title;
		String loction;
		String qty;
		String issueid;
		//String hint;
	}

	private static class ChildHolder {
		TextView title;
		TextView location;
		TextView qty;
	}

	private static class GroupHolder {
		TextView title;
	}

	/**
	 * Adapter for our list of {@link GroupItem}s.
	 */
	private class ExampleAdapter extends AnimatedExpandableListAdapter {
		private LayoutInflater inflater;

		private List<GroupItem> items;

		public ExampleAdapter(Context context) {
			inflater = LayoutInflater.from(context);
		}

		public void setData(List<GroupItem> items) {
			this.items = items;
		}

		@Override
		public ChildItem getChild(int groupPosition, int childPosition) {
			return items.get(groupPosition).items.get(childPosition);
		}

		@Override
		public long getChildId(int groupPosition, int childPosition) {
			return childPosition;
		}

		@Override
		public View getRealChildView(int groupPosition, int childPosition,
				boolean isLastChild, View convertView, ViewGroup parent) {
			final int pos=childPosition;
			ChildHolder holder;
			final ChildItem item = getChild(groupPosition, childPosition);
			if (convertView == null) {
				holder = new ChildHolder();
				convertView = inflater.inflate(R.layout.list_item, parent,
						false);
//				if(childPosition%2==1){
//					convertView.setBackgroundColor(Color.parseColor("#e2ddc7"));
//				}
				holder.title = (TextView) convertView
						.findViewById(R.id.textTitle);
			
				holder.location = (TextView) convertView
						.findViewById(R.id.textLocation);
				holder.qty = (TextView) convertView
						.findViewById(R.id.textqty);
				convertView.setTag(holder);
			} else {
				holder = (ChildHolder) convertView.getTag();
			}

			holder.title.setText(item.title);
			holder.qty.setText(item.qty);
			if(!(item.loction.equals("1")))
				holder.location.setTextColor(Color.RED);
			else holder.location.setTextColor(Color.GRAY);
			convertView.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					ViewLocation.editLocation(item.issueid);
					//Toast.makeText(getApplicationContext(), ""+item.qty,Toast.LENGTH_SHORT).show();
				}
			});
			return convertView;
		}

		@Override
		public int getRealChildrenCount(int groupPosition) {
			return items.get(groupPosition).items.size();
		}

		@Override
		public GroupItem getGroup(int groupPosition) {
			return items.get(groupPosition);
		}

		@Override
		public int getGroupCount() {
			return items.size();
		}

		@Override
		public long getGroupId(int groupPosition) {
			return groupPosition;
		}

		@Override
		public View getGroupView(int groupPosition, boolean isExpanded,
				View convertView, ViewGroup parent) {
			GroupHolder holder;
			GroupItem item = getGroup(groupPosition);
			if (convertView == null) {
				holder = new GroupHolder();
				convertView = inflater.inflate(R.layout.group_item, parent,
						false);
//				if(groupPosition%2==1){
//					convertView.setBackgroundColor(Color.parseColor("#c7e2dc"));
//				}
				holder.title = (TextView) convertView
						.findViewById(R.id.textTitle);
				convertView.setTag(holder);
			} else {
				holder = (GroupHolder) convertView.getTag();
			}

			holder.title.setText(item.title);

			return convertView;
		}

		@Override
		public boolean hasStableIds() {
			return true;
		}

		@Override
		public boolean isChildSelectable(int arg0, int arg1) {
			return true;
		}

	}
	
	public static void editLocation(final String issue_id)
	{	
		final Dialog dialog = new Dialog(cnt);	
		dialog.setTitle("Location of Issue ID:"+issue_id);			   
		dialog.setContentView(R.layout.locationview);	
		locationlist=(ListView)dialog.findViewById(R.id.lv_locationview_loc);
		TextView noloc=(TextView)dialog.findViewById(R.id.txt_locationview_noloc);
		ImageView addnewloc=(ImageView)dialog.findViewById(R.id.iv_locationview_newloc);
		addnewloc.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				dialog.dismiss();
				Intent i1 =new Intent(cnt,UpdateIssueLocation.class);
				i1.putExtra("Issue_id",Long.parseLong(issue_id));
				//i1.putExtra("Issue_id",issue_id);
				cnt.startActivity(i1);	
				activity.finish();
			}
		});
		Button cancel=(Button)dialog.findViewById(R.id.bt_locationview_cancel);
		cancel.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				dialog.dismiss();
			}
		});
			try { 
				cs1=db1.sqlQuery("Select *,"+db1.key_warehouse_issuestockupdatelocation_issueid+" as _id,"
						+Sqldatabase.key_warehouse_no_plantno
						+ " from "+db1.tbl_warehouse_update_issue_location+","+Sqldatabase.tbl_warehouse_no+
						" where "+Sqldatabase.key_warehouse_no_id+" = "+Sqldatabase.key_warehouse_updatelocation_warehouseid+
						" and "+db1.key_warehouse_issuestockupdatelocation_issueid+"='"+issue_id+"'");
				if(cs1.getCount()>0)
				{
				noloc.setVisibility(View.INVISIBLE); 
				locationlist.setVisibility(View.VISIBLE);
				addnewloc.setVisibility(View.GONE); 

				cs1.moveToFirst(); 
				adapt=new SimpleCursorAdapter(cnt, R.layout.locationedititem2, cs1, 
						new String[]{db1.key_warehouse_no_plantno,db1.key_warehouse_updatelocation_itemcode,
						db1.key_warehouse_updatelocation_qty,db1.key_warehouse_updatelocation_rakerow,
						db1.key_warehouse_updatelocation_rakecolumn}, 
						new int[]{R.id.txt_locediti_warehouse,R.id.txt_locediti_itemcode,
						R.id.txt_locediti_qty,R.id.txt_locediti_rakerow,R.id.txt_locediti_rakecolumn}, SimpleCursorAdapter.NO_SELECTION);
				adapt.setViewBinder(new ViewBinder() {      
					 
					@Override    
					public boolean setViewValue(View arg0, Cursor arg1, int arg2) {
						// TODO Auto-generated method stub 


						if(15==arg2){  
							try { 
								TextView frname=(TextView)arg0;	
								
			 					frname.setText(arg1.getString(arg2));   
							} catch (NumberFormatException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							  
						} 
						else if(5==arg2){   
							try {
								TextView frname=(TextView)arg0;	
								
			 					frname.setText(arg1.getString(arg2));   
							} catch (NumberFormatException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							  
						}	
						else if(6==arg2){   
							try {
								TextView frname=(TextView)arg0;	
								
			 					frname.setText(arg1.getString(arg2));   
							} catch (NumberFormatException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							  
						}
						else if(3==arg2){   
							try {
								TextView frname=(TextView)arg0;	
								
			 					frname.setText(arg1.getString(arg2));   
							} catch (NumberFormatException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							  
						}
						else if(8==arg2){  
							try {
								TextView frname=(TextView)arg0;	
								
			 					frname.setText(arg1.getString(arg2));   
							} catch (NumberFormatException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							  
							  
						}
						return true;
						}
						});
				locationlist.setAdapter(adapt);
				 
				}
				else{
					locationlist.setVisibility(View.GONE);
					noloc.setVisibility(View.VISIBLE);
					addnewloc.setVisibility(View.VISIBLE); 

				} 
				try {
					Window window = dialog.getWindow();
					window.setLayout(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
					window.setGravity(Gravity.CENTER);
				dialog.show();
				
				dialog.getWindow().setLayout(width, height);
				dialog.setCancelable(false);
			} catch (Exception e) {
				// TODO Auto-generated catch block  
				e.printStackTrace();
			}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}


	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		super.onBackPressed();
		Intent i1 =new Intent(getApplicationContext(),Select_Activity.class);
		i1.putExtra("syncstatus",true);
		startActivity(i1);
		finish();
	}
}
