package com.aucupa.warehouse;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.Settings;
import android.util.Log;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

public class Sqldatabase {

	public static final String database_name = "AUCUPA_WAREHOUSE";
	public static final int database_ver =1;


	public final static String tbl_warehouse_no ="Warehouse_No";
	public final static String tbl_Allwarehouses ="AllWarehouses";
	public final static String tbl_mobile_user ="Mobile_User";
	public final static String tbl_mobile_userOffline ="Mobile_UserOffline";
	public final static String tbl_palnts ="Plants";
	public final static String tbl_assign_warehouse ="Assign_WareHouse";
	public final static String tbl_orderno_lotno ="Orderno_Lotno";
	public final static String tbl_suppliers ="suppliers";
	public final static String tbl_Items ="Items";
	public final static String tbl_Stock_QAChecklist="Stock_QA_Check";
	public final static String tbl_Config ="ConfigTable";
	//local save Add Stock_temp
	//public final static String tbl_warehouse_addsocks ="Add_Stocks";
	public final static String tbl_warehouse_addsock ="Add_Stock";
	public final static String tbl_warehouse_issuestock ="Issue_Stock";
	public final static String tbl_warehouse_updatelocation ="Update_Location";
	public final static String tbl_warehouse_update_issue_location ="Update_issue_Location";



	public static final String key_mobileuser_id ="enduser_id";
	public static final String key_mobileuser_name ="enduser_username";
	public static final String key_mobileuser_password ="enduser_password";

	public static final String key_supplier_id ="supplier_id";
	public static final String key_supplier_Server_id ="supplier_server_id";
	public static final String key_supplier_code ="supplier_code";
	public static final String key_supplier_name = "supplier_name";

	public static final String key_mobileuserOffline_id ="enduser_id";
	public static final String key_mobileuserOffline_uname ="enduser_username";
	public static final String key_mobileuserOffline_password ="enduser_password";

	public static final String key_orderno_lotno_id ="id";
	public static final String key_orderno_lotno_lotno ="lotno";
	public static final String key_orderno_lotno_orderno ="orderno";
	public static final String key_orderno_lotno_item_name ="item_name";
	public static final String key_orderno_lotno_raw_quantity ="raw_quantity";


	public static final String key_warehouse_no_id ="id";
	public static final String key_warehouse_no_ware_id ="warehouse_id";
	public static final String key_warehouse_no_plantno ="warehouse_no";


	public static final String key_assign_warehouse_id ="id";
	public static final String key_assign_warehouse_plantno ="warehouse_no";
	public static final String key_assign_warehouse_uname ="username";

	public static final String key_plants_id="id";
	public static final String key_plants_name ="plantName";

	public static final String key_warehouse_syncstatus ="Sync_Status";
	public static final	String key_warehouse_server_stockID="serverstockID";
	public static final	String key_warehouse_server_stockissueID="serverissueID";
	public static final String key_warehouse_createdtime="createtime";

	/**Item Table key Words**/
	public static final String key_warehouse_item_itemid ="Item_id";
	public static final String key_warehouse_item_itemcode ="Item_code";
	public static final String key_warehouse_item_itemname="Item_name";
	public static final String key_warehouse_item_category ="Category";
	public static final String key_warehouse_item_subcategory ="Sub_category";
	public static final String key_warehouse_item_itemUnit ="Item_Unit";
	public static final String key_warehouse_item_itemtype ="Item_type";


	/**add stock keywords Device*/
	public static final String key_warehouse_addstock_stockid ="Stock_id";
	public static final String key_warehouse_addstock_Stocktype ="StockType";
	public static final String key_warehouse_addstock_ordernumber ="OrderNo";
	public static final String key_warehouse_addstock_suppliercode ="SupplierCode";
	public static final String key_warehouse_addstock_warehousecode ="Warehousecode";
	public static final String key_warehouse_add_sync="add_sync";
	public static final String key_warehouse_syncerrorstatus="error_sync";
	public static final String key_warehouse_addstock_itemid="ItemId";
	public static final String key_warehouse_addstock_itemcode ="ItemCode";
	public static final String key_warehouse_addstock_qcinspno="qcinspectno";
	public static final String key_warehouse_addstock_batchnumber ="BatchNumber";
	public static final String key_warehouse_addstock_RMARnumber ="RMARNumber";
	public static final String key_warehouse_addstock_RmSpecNo ="RmSpecNo";
	public static final String key_warehouse_addstock_GIRNo ="GIRNo";
	public static final String key_warehouse_addstock_commoditygrade ="CommodityGrade";
	public static final String key_warehouse_addstock_variety ="Variety";
	public static final String key_warehouse_addstock_EstYiels ="EstYield";
	public static final String key_warehouse_addstock_ExpDate ="ExpDate";
	public static final String key_warehouse_addstock_totalquantity ="TotalQuantity";
	public static final String key_warehouse_addstock_noofbags ="NoOfBags";
	public static final String key_warehouse_addstock_UnitPrice ="UnitPrice";
	public static final String key_warehouse_addstock_lotnumber ="LotNumber";
	public static final String key_warehouse_addstock_ArrivalForm ="ArrivalForm";
	public static final String key_warehouse_addstock_arrivaldate ="ArrivalDate";
	public static final String key_warehouse_addstock_intentstatus ="IntentStatus";
	public static final String key_warehouse_addstock_location_status ="Location_Status";
	public static final String key_warehouse_addstock_Remarks ="Remarks";


	/** issue stock keyword **/
	public static final String key_warehouse_issuestock_issuecode="Issuecode";
	public static final String key_warehouse_issuestock_issueid ="Issueid";
	public static final String key_warehouse_issuestock_Stocktype ="StockType";
	public static final String key_warehouse_issuestock_itemcode ="ItemCode";
	public static final String key_warehouse_issuestock_timestamp ="timestamp";
	public static final String key_warehouse_issuestock_lotnumber ="LotNumber";
	public static final String key_warehouse_issuestock_batchnumber ="BatchNumber";
	public static final String key_warehouse_issuestock_RMARnumber ="RMARNumber";
	public static final String key_warehouse_issuestock_Plantid  ="Plantid";
	public static final String key_warehouse_issuestock_OrderNumber ="OrderNumber";
	public static final String key_warehouse_issuestock_toWareHousid ="ToWareHouseid";
	public static final String key_warehouse_issuestock_RequiredQty ="RequiredQty";
	public static final String key_warehouse_issuestock_IssuedQty ="IssuedQty";
	public static final String key_warehouse_issuestock_IssuedTo ="IssuedTo";
	public static final String key_warehouse_issuestock_location_status ="Location_Status";

	public static final String key_warehouse_updatelocation_locationid ="locationid";
	public static final String key_warehouse_updatelocation_warehouseid ="WareHouseid";
	public static final String key_warehouse_updatelocation_stockid ="Stock_id";
	public static final String key_warehouse_updatelocation_palletno ="PalletNo";
	public static final String key_warehouse_updatelocation_rakerow ="RakeRow";
	public static final String key_warehouse_updatelocation_rakecolumn ="RakeColumn";
	public static final String key_warehouse_updatelocation_refposition ="RefPosition";
	public static final String key_warehouse_updatelocation_qty ="Quantity";
	public static final String key_warehouse_updatelocation_itemcode ="ItemCode";

	public static final String key_Stock_QAChecklist_qaid ="qa_id";
	public static final String key_Stock_QAChecklist_stockid ="Stock_id";
	public static final String key_Stock_QAChecklist_IntegrityofBags="IntegrityofBags";
	public static final String key_Stock_QAChecklist_Appearance ="Appearance";
	public static final String key_Stock_QAChecklist_ExtraneousMatter ="Extraneous_Matter";
	public static final String key_Stock_QAChecklist_Other="Other";
	public static final String key_Stock_QAChecklist_Remarks ="Remarks";

	public static final String key_warehouse_issuestockupdatelocation_issueid ="issueid";



	private dbhelper myhelper;
	private Context mycontext;
	private SQLiteDatabase mydatabase;
	private Cursor cr;
	public static String weburl = "http://sellowa.com/proctore/";

	/**************************************/

	public Sqldatabase(Context c)
	{
		mycontext =c;
		sqlopen();
	}
	public Sqldatabase sqlopen(){
		myhelper = new dbhelper(mycontext);
		mydatabase =myhelper.getWritableDatabase();
		return this;
	}
	public void sqlclose(){
		myhelper.close();
	}

	public void cursorclose()
	{
		try{
			cr.close();
		}catch(Exception e)
		{
			Log.i("Cursor close", e.toString());
		}

	}

	/**************************************/

	public long configins(String name,String values)
	{
		ContentValues cv=new ContentValues();
		cv.put("name", name);
		cv.put("value", values);
		return sqlins(tbl_Config,cv);
	}

	public long sqlins(String tablename,ContentValues cv)
	{
		try{

			return	mydatabase.insert(tablename, null, cv);
		}catch(Exception e)
		{
			Log.i("sqlins", e.toString());
			e.printStackTrace();
		}
		return -1;
	}
	void sqlupdate(String tablename,ContentValues dataToInsert, String where, String Value)
	{
		//where="";
		try{
			where=where+"=?";
			String[] whereArgs = {Value.toString()};
			//mydatabase.update(tablename, dataToInsert, where, whereArgs);
			mydatabase.update(tablename, dataToInsert, where, whereArgs);
			//mydatabase.commit();

		}catch(Exception e)
		{
			Log.i("sqlupdate", e.toString());
			e.printStackTrace();
		}


	}
	public Cursor sqlread(String tablename)
	{
		try{
			cr=mydatabase.rawQuery("select * from "+ tablename +" ", null);
		}catch(Exception e)
		{
			Log.i("sqlread", e.toString());
		}
		return cr;
	}

	public boolean setSupplierDetails(Context c) {
		Boolean temp = false;
		SQLiteDatabase sqlite = myhelper.getWritableDatabase();
		JSONArray jsonarray = new JSONArray();
		JSONObject json = new JSONObject();
		try {
			json.put("table", "suppliers");
			json.put("dev_id",Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ANDROID_ID));
			json.put("user_id","");
			json.put("last_sync","0");
			jsonarray.put(json);
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(weburl + "sync_outs");
			StringEntity se = new StringEntity(jsonarray.toString());
			httppost.setEntity(se);
			httppost.setHeader("Accept", "application/json");
			httppost.setHeader("Content-type", "application/json");
			HttpResponse response = httpclient.execute(httppost);
			Log.i("response", response.toString());
			if (response != null) {
				temp = true;
				InputStream is = response.getEntity().getContent();
				sqlite.delete("suppliers", null, null);
				JsonFactory fact = new JsonFactory();
				JsonParser par = fact.createParser(is);
				par.nextToken();
				try {
					while (par.nextToken() != com.fasterxml.jackson.core.JsonToken.END_ARRAY) {
						ContentValues cv = new ContentValues();
						while (par.nextToken() != com.fasterxml.jackson.core.JsonToken.END_OBJECT) {
							String namefield = par.getCurrentName();
							par.nextToken();
							if ("id".equals(namefield))
								cv.put("supplier_id", par.getText());
							else if ("suppliercode".equals(namefield))
								cv.put("supplier_code", par.getText());
							else if ("suppliername".equals(namefield))
								cv.put("supplier_name", par.getText());
						}
						sqlite.insert("suppliers",null, cv);
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			mydatabase.close();

		}
		catch (JSONException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IllegalStateException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return temp;
	}
	public void updateAddSync(String lotno){
		myhelper.getWritableDatabase();
		mydatabase.execSQL("update wh_qa set add_sync='1' where lot_no='"+lotno+"'");
	}
	public Cursor getDetails(String suplyname){
		//String query="SELECT Stock_id AS _id,LotNumber,TotalQuantity,Warehousecode,SupplierCode,StockType FROM Add_Stock";
		Cursor c=null;
		try {
			String query="SELECT supplier_id AS _id,supplier_code,supplier_name FROM suppliers where supplier_name LIKE '"+suplyname+"%' ORDER BY supplier_name ASC";
			c=mydatabase.rawQuery(query,null);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return c;
	}

	public Cursor getDataDetails(){
		//String query="SELECT Stock_id AS _id,LotNumber,TotalQuantity,Warehousecode,SupplierCode,StockType FROM Add_Stock";
		Cursor c=null;
		try {
			String query="SELECT supplier_id AS _id,supplier_code,supplier_name FROM suppliers ORDER BY supplier_name ASC";
			c=mydatabase.rawQuery(query,null);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return c;
	}
//	public void getCountss(String Stock_id,String lotno)
//	{
////		Cursor c=null;
////		try
////		{
//			String query="UPDATE Add_Stock SET LotNumber='"+lotno+"' WHERE Stock_id='"+Stock_id+"'";
//			mydatabase.execSQL(query);
////		}
////		catch (Exception e)
////		{
////			e.printStackTrace();
////		}
////		return c;
//	}
	public void getCount(String Stock_id,String lotno)
	{
			myhelper.getWritableDatabase();
			mydatabase.execSQL("update Add_Stock set LotNumber='"+lotno+"' WHERE Stock_id='"+Stock_id+"'");
	}


	public int getCounts(String Stock_id,String lotno) {

		try
		{
			Cursor c =mydatabase.rawQuery("UPDATE Add_Stock SET LotNumber='"+lotno+"' WHERE Stock_id='"+Stock_id+"'", null);
			Log.i("Get count", c.getCount()+"");
			if(c.getCount()>0)
			return c.getCount();
		}
		catch(Exception e)
		{
			Log.i("Get count", e.toString());
		}

		return 0;
	}

	public Cursor sqlQuery(String sql){
		Cursor c =mydatabase.rawQuery(sql , null);
		return c;
	}

	public boolean Delete(String Tablename , String key, int i) {
		mydatabase.rawQuery("Delete from " +Tablename+ " where " + key + " = " + i, null);
		return true;
	}
	public SQLiteDatabase getdb(){
		return mydatabase;
	}

	public int getCount(String Tname) {

		try{
			Cursor c =mydatabase.rawQuery("select * from " + Tname, null);
			Log.i("Get count", c.getCount()+"");
			if(c.getCount()>0)
				return c.getCount();

		}
		catch(Exception e) {
			Log.i("Get count", e.toString());
		}

		return 0;
	}
	public Cursor getAddstock()
	{
		Cursor c=null;
		try {
			myhelper.getReadableDatabase();
			c=mydatabase.rawQuery("SELECT Stock_id AS _id,ItemId,ItemCode,LotNumber,TotalQuantity,error_sync FROM Add_Stock ORDER BY createtime DESC",null);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return c;
	}

	public Cursor getWarehouseDetails()
	{
		myhelper.getReadableDatabase();
		Cursor c=mydatabase.rawQuery("SELECT * FROM Warehouse_No ORDER BY warehouse_no ASC",null);
		return c;
	}
	public Cursor getWarehouseDetails(String code)
	{
		myhelper.getReadableDatabase();
		Cursor c=mydatabase.rawQuery("SELECT * FROM Warehouse_No where warehouse_no='"+code+"'",null);
		return c;
	}
	public void InsertqaDetails(String item,String item_id,String lot,String qty,String supplier,String sup_id,String uname,String c_id){
		ContentValues cv=new ContentValues();
		cv.put("item_type","1");
		cv.put("item_id",item_id);
		cv.put("itemcode",item);
		cv.put("lot_no",lot);
		cv.put("quantity",qty);
		cv.put("Supplier",supplier);
		cv.put("Supplier_id",sup_id);
		cv.put("qa_status","0");
		cv.put("specification","");
		cv.put("remarks","");
		cv.put("comments","");
		cv.put("created_time","");
		cv.put("created_by",uname);
		cv.put("created_by_id",c_id);
		cv.put("qa_starttime","");
		cv.put("qa_updatedtime","");
		cv.put("sync_status","0");
		cv.put("stock_id","");
		cv.put("add_sync","0");

		mydatabase.insert("wh_qa",null,cv);

	}
	public Cursor getItemCodes()
	{
		myhelper.getReadableDatabase();
		Cursor c=mydatabase.rawQuery("SELECT Item_id as _id,Item_code FROM Items ORDER BY Item_code ASC",null);
		return c;

	}
	public Cursor getdata(String message)
	{
		myhelper.getReadableDatabase();
		Cursor c = mydatabase.rawQuery("SELECT Item_id as _id,Item_code FROM Items where Item_code LIKE '" + message + "%' order by Item_code asc", null);
		return c;
	}

	public Cursor getItemCodesdatas(String message)
	{
		myhelper.getReadableDatabase();
		Cursor c=mydatabase.rawQuery("select items.Item_id as _id,items.Item_code from items,wh_qa where wh_qa.item_id=items.Item_id and wh_qa._id='"+message+"'",null);
		return c;

	}
	public Cursor getStockQuanity(String message)
	{
		myhelper.getReadableDatabase();
		Cursor c=mydatabase.rawQuery("select TotalQuantity from Add_Stock where Stock_id='"+message+"'",null);
		return c;

	}
	public Cursor getItemCodesstockdatas(String message)
	{
		myhelper.getReadableDatabase();
		Cursor c=mydatabase.rawQuery("select items.Item_id as _id,items.Item_code from items,Add_Stock where Add_Stock.ItemId=items.Item_id and Add_Stock.Stock_id='"+message+"'",null);
		return c;

	}
	public Cursor getWarehousesstockdatas(String message)
	{
		myhelper.getReadableDatabase();
		Cursor c=mydatabase.rawQuery("select Warehouse_No.warehouse_id,Warehouse_No.warehouse_no from Warehouse_No,Add_Stock where Add_Stock.Warehousecode=Warehouse_No.warehouse_id and Add_Stock.Stock_id='"+message+"'",null);
		return c;

	}
	public Cursor getlotCodesdatas(String message)
	{
		myhelper.getReadableDatabase();
		Cursor c=mydatabase.rawQuery("select lot_no,quantity from wh_qa where _id='"+message+"'",null);
		return c;

	}
	public Cursor getquantityCodesdatas(String message)
	{
		myhelper.getReadableDatabase();
		Cursor c=mydatabase.rawQuery("select quantity from wh_qa where _id='"+message+"'",null);
		return c;

	}
	public Cursor getunitOMdatas(String message)
	{
		myhelper.getReadableDatabase();
		Cursor c=mydatabase.rawQuery("select Items.Item_Unit from items,Add_Stock where Add_Stock.ItemId=Items.Item_id and Add_Stock.Stock_id='"+message+"';",null);
		return c;

	}
//	public Cursor getorderOMdatas(String message)
//	{
//		myhelper.getReadableDatabase();
//		Cursor c=mydatabase.rawQuery("select items.Item_Unit from items,wh_qa where wh_qa.item_id=items.Item_id and wh_qa._id='"+message+"'",null);
//		return c;
//
//	}


	public Cursor getItemCodesdata(String message)
	{
		myhelper.getReadableDatabase();
		Cursor c=mydatabase.rawQuery("select Item_Code FROM items C LEFT JOIN [wh_qa] O ON O.item_id=C.Item_id AND O._id='"+message+"' ORDER BY Item_Code",null);
		return c;

	}
	public Cursor getSupplierdata(String message)
	{
		myhelper.getReadableDatabase();
		Cursor c=mydatabase.rawQuery("select supplier_name from Suppliers,wh_qa where wh_qa.Supplier_id =Suppliers.supplier_id and wh_qa._id='"+message+"'",null);
		return c;

	}
	public Cursor getaddSupplierdata(String message)
	{
		myhelper.getReadableDatabase();
		Cursor c=mydatabase.rawQuery("select supplier_name from Suppliers,Add_Stock where Add_Stock.SupplierCode =Suppliers.supplier_id and Add_Stock.Stock_id='"+message+"'",null);
		return c;

	}
	public Cursor getItemCodes(String name){
		myhelper.getReadableDatabase();
		Cursor c=mydatabase.rawQuery("SELECT Item_id AS _id FROM Items WHERE Item_code='"+name+"'",null);
		return c;

	}
	public Cursor getItemname(String name)
	{
		myhelper.getReadableDatabase();
		Cursor c=mydatabase.rawQuery("SELECT * FROM Items WHERE Item_id='"+name+"'",null);
		return c;

	}
	public Cursor getqaupdateDetails(){
		myhelper.getReadableDatabase();
		Cursor c=mydatabase.rawQuery("SELECT * FROM qaUpdate",null);
		return c;
	}
	public Cursor getqaDetails(){
		myhelper.getReadableDatabase();
		Cursor c= null;
		try {
			c = mydatabase.rawQuery("SELECT * FROM wh_qa where add_sync='"+0+"'",null);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return c;
	}
	public Cursor getSupplierId(String name)
	{
		myhelper.getReadableDatabase();
		Cursor c=mydatabase.rawQuery("SELECT * FROM suppliers WHERE supplier_name='"+name+"'",null);
		return c;

	}
	public Cursor getSuppliername(String name)
	{
		myhelper.getReadableDatabase();
		Cursor c=mydatabase.rawQuery("SELECT * FROM suppliers WHERE supplier_code='"+name+"'",null);
		return c;

	}
	public long insertStock(String item_id, String itemcode, String lotno,String qty, String warehouse ,String suppliercode,String orderno){
		try {
			ContentValues cv=new ContentValues();
			cv.put("StockType","1");
			cv.put("ItemId",item_id);
			cv.put("ItemCode",itemcode);
			cv.put("LotNumber",lotno);
			cv.put("TotalQuantity",qty);
			cv.put("Warehousecode",warehouse);
			cv.put("SupplierCode",suppliercode);
			cv.put("OrderNo",orderno);
			cv.put("createtime",System.currentTimeMillis());
			cv.put("serverstockID","");
			cv.put("Sync_Status","0");

			mydatabase.insert("Add_Stock",null,cv);

			//Toast.makeText(context,"Added to Stock",Toast.LENGTH_SHORT).show();
			return 1;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}
	public Cursor getUOM(String code)
	{
		myhelper.getReadableDatabase();
		Cursor c=mydatabase.rawQuery("select * from wh_qa where lot_no='"+code+"'",null);
		return c;
	}
	public Cursor getUOMStock(String code)
	{
		myhelper.getReadableDatabase();
		Cursor c=mydatabase.rawQuery("select * from Add_Stock where LotNumber='"+code+"'",null);
		return c;
	}
	public Cursor getqaDetails(String item){
		myhelper.getReadableDatabase();
		Cursor c=mydatabase.rawQuery("SELECT * FROM wh_qa where _id='"+item+"'",null);
		return c;
	}
	public Cursor getstockDetails(String item){
		myhelper.getReadableDatabase();
		Cursor c=mydatabase.rawQuery("SELECT * FROM Add_Stock where Stock_id='"+item+"'",null);
		return c;
	}
	public Cursor getqaDetails1(String item){
		myhelper.getReadableDatabase();
		Cursor c=mydatabase.rawQuery("SELECT * FROM wh_qa where _id='"+item+"'",null);
		return c;
	}
	public Cursor getMobileuser(String name){
		myhelper.getReadableDatabase();
		Cursor c=mydatabase.rawQuery("SELECT enduser_id from Mobile_User WHERE enduser_username='"+name+"';",null);
		return c;

	}
	public Cursor getwh_qaNotificationCount()
	{
		myhelper.getReadableDatabase();
		Cursor c=mydatabase.rawQuery("select * from wh_qa",null);
		return c;
	}
	public boolean setWareHouseDetails(Context c) {
		Boolean temp = false;
		SQLiteDatabase sqlite = myhelper.getWritableDatabase();
		JSONArray jsonarray = new JSONArray();
		JSONObject json = new JSONObject();
		try {
			json.put("table", "warehouses");
			json.put("dev_id",Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ANDROID_ID));
			json.put("user_id","");
			json.put("last_sync","0");
			jsonarray.put(json);
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(weburl + "sync_outs");
			StringEntity se = new StringEntity(jsonarray.toString());
			httppost.setEntity(se);
			httppost.setHeader("Accept", "application/json");
			httppost.setHeader("Content-type", "application/json");
			HttpResponse response = httpclient.execute(httppost);
			Log.i("response", response.toString());
			if (response != null) {
				temp = true;
				InputStream is = response.getEntity().getContent();
				sqlite.delete("Warehouse_No", null, null);
				JsonFactory fact = new JsonFactory();
				JsonParser par = fact.createParser(is);
				par.nextToken();
				try {
					while (par.nextToken() != com.fasterxml.jackson.core.JsonToken.END_ARRAY) {
						ContentValues cv = new ContentValues();
						while (par.nextToken() != com.fasterxml.jackson.core.JsonToken.END_OBJECT) {
							String namefield = par.getCurrentName();
							par.nextToken();
							if ("id".equals(namefield))
								cv.put("warehouse_id", par.getText());
							else if ("warehouse_no".equals(namefield))
								cv.put("warehouse_no", par.getText());
						}
						sqlite.insert("Warehouse_No",null, cv);
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			mydatabase.close();

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IllegalStateException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return temp;
	}
	public boolean postqaDetails(Context c,String Tname,String id){

		Sqldatabase db=new Sqldatabase(c);
		Boolean temp = false;
		JSONArray jsonarray = new JSONArray();
		JSONObject json = new JSONObject();
		Cursor cs = null;
		String sendTname = "";
		if (Tname.equalsIgnoreCase("wh_qa")) {
			String q="SELECT * FROM wh_qa WHERE sync_status='0'";
			cs=db.sqlQuery(q);
			sendTname = "wh_qa";
		}
		if (cs.getCount() > 0) {
			cs.moveToFirst();
			try {
				json.put("uid",id);
				json.put("Device_Id", Settings.Secure.getString(c.getContentResolver(),
						Settings.Secure.ANDROID_ID));
				json.put("process", sendTname);
				jsonarray.put(json);
			} catch (Exception e) {

			}
			while (cs.isAfterLast() == false) {
				try {
					json = new JSONObject();
					for (int i = 0; i < cs.getColumnCount(); i++) {
						json.put(cs.getColumnName(i), cs.getString(i));
					}
					jsonarray.put(json);
					cs.moveToNext();
				} catch (Exception e) {
					Log.d("Android", "JSON Error");
				}
			}
			try {
				Log.d("Jarray", jsonarray.toString());
				HttpClient httpclient = new DefaultHttpClient();
				HttpPost httppost = new HttpPost(weburl + "sync_ins");
				StringEntity se = new StringEntity(jsonarray.toString());
				httppost.setEntity(se);
				httppost.setHeader("Accept", "application/json");
				httppost.setHeader("Content-type", "application/json");
				HttpResponse response = httpclient.execute(httppost);
				Log.i("response", response.toString());
				if(response!=null){
					{
						temp = true;
						InputStream is = response.getEntity().getContent();
						BufferedReader reader = new BufferedReader(
								new InputStreamReader(is));
						StringBuilder sb = new StringBuilder();
						String line = null;
						try {
							while ((line = reader.readLine()) != null) {
								sb.append(line + "\n");
							}
							Log.i("response", sb.toString());
							if (sb.toString().contains("SUCCESS")) {
								if (Tname.equalsIgnoreCase("wh_qa")) {

									ContentValues cv = new ContentValues();
									cv.put("sync_status", 1);
									db.sqlupdate("wh_qa",cv,"sync_status='0'","");

								}
							}
						} catch (IOException e) {
							e.printStackTrace();
						} finally {
							try {
								is.close();
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}


		}
		cs.close();
		return temp;
	}
	public boolean postAddStock(Context c,String Tname,String id){

		Sqldatabase db=new Sqldatabase(c);
		Boolean temp = false;
		JSONArray jsonarray = new JSONArray();
		JSONObject json = new JSONObject();
		Cursor cs = null;
		String sendTname = "";
		if (Tname.equalsIgnoreCase("Add_Stock")) {
			String q="SELECT * FROM Add_Stock WHERE Sync_Status='0'";
			cs=db.sqlQuery(q);
			sendTname = "StockDetails";
		}
		if (cs.getCount() > 0) {
			cs.moveToFirst();
			try {
				json.put("uid",id);
				json.put("Device_Id", Settings.Secure.getString(c.getContentResolver(),
						Settings.Secure.ANDROID_ID));
				json.put("process", sendTname);
				jsonarray.put(json);
			} catch (Exception e) {

			}
			while (cs.isAfterLast() == false) {
				try {
					json = new JSONObject();
					for (int i = 0; i < cs.getColumnCount(); i++) {
						json.put(cs.getColumnName(i), cs.getString(i));
					}
					jsonarray.put(json);
					cs.moveToNext();
				} catch (Exception e) {
					Log.d("Android", "JSON Error");
				}
			}
			try {
				Log.d("Jarray", jsonarray.toString());
				HttpClient httpclient = new DefaultHttpClient();
				HttpPost httppost = new HttpPost(weburl + "sync_ins");
				StringEntity se = new StringEntity(jsonarray.toString());
				httppost.setEntity(se);
				httppost.setHeader("Accept", "application/json");
				httppost.setHeader("Content-type", "application/json");
				HttpResponse response = httpclient.execute(httppost);
				Log.i("response", response.toString());
				if(response!=null){
					{
						temp = true;
						InputStream is = response.getEntity().getContent();
						BufferedReader reader = new BufferedReader(
								new InputStreamReader(is));
						StringBuilder sb = new StringBuilder();
						String line = null;
						try {
							while ((line = reader.readLine()) != null) {
								sb.append(line + "\n");
							}
							Log.i("response", sb.toString());
							if (sb.toString().contains("SUCCESS"))
							{
								if (Tname.equalsIgnoreCase("Add_Stock"))
								{

									ContentValues cv = new ContentValues();
									cv.put("Sync_Status",1);
									cv.put("error_sync",0);
									db.sqlupdate("Add_Stock",cv,"Sync_Status","0");

								}
							}
							if (sb.toString().contains("Already Exist Lot Number"))
							{
								if (Tname.equalsIgnoreCase("Add_Stock"))
								{

									ContentValues cv = new ContentValues();
									cv.put("Sync_Status",0);
									cv.put("error_sync",502);
									db.sqlupdate("Add_Stock",cv,"Sync_Status","0");

								}
							}

						} catch (IOException e) {
							e.printStackTrace();
						} finally {
							try {
								is.close();
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}


		}
		cs.close();
		return temp;
	}
	public boolean getUpdateFromServerQa(Context c) {
		Boolean temp = false;
		SQLiteDatabase sqlite = myhelper.getWritableDatabase();
		JSONArray jsonarray = new JSONArray();
		JSONObject json = new JSONObject();
		try {
			json.put("table", "QAUpdate");
			jsonarray.put(json);
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(weburl + "sync_outs");
			StringEntity se = new StringEntity(jsonarray.toString());
			httppost.setEntity(se);
			httppost.setHeader("Accept", "application/json");
			httppost.setHeader("Content-type", "application/json");
			HttpResponse response = httpclient.execute(httppost);
			Log.i("response", response.toString());
			if (response != null) {
				temp = true;
				InputStream is = response.getEntity().getContent();
				sqlite.delete("qaUpdate", null, null);
				JsonFactory fact = new JsonFactory();
				JsonParser par = fact.createParser(is);
				par.nextToken();
				try {
					while (par.nextToken() != com.fasterxml.jackson.core.JsonToken.END_ARRAY) {
						ContentValues cv = new ContentValues();
						while (par.nextToken() != com.fasterxml.jackson.core.JsonToken.END_OBJECT) {
							String namefield = par.getCurrentName();
							par.nextToken();
							if ("specification".equals(namefield))
								cv.put("specification", par.getText());
							else if ("remarks".equals(namefield))
								cv.put("remarks", par.getText());
							else if ("comments".equals(namefield))
								cv.put("comments", par.getText());
							else if ("qa_start_time".equals(namefield))
								cv.put("qa_start_time", par.getText());
							else if ("qa_status".equals(namefield))
								cv.put("qa_status", par.getText());
							else if ("stock_id".equals(namefield))
								cv.put("stock_id", par.getText());
							else if ("created_time".equals(namefield))
								cv.put("created_time", par.getText());
							else if ("qa_updated_time".equals(namefield))
								cv.put("qa_updated_time", par.getText());
							else if ("qa_sample_id".equals(namefield))
								cv.put("qa_sample_id", par.getText());
							else if ("item_id".equals(namefield))
								cv.put("item_id", par.getText());
							else if ("lot_no".equals(namefield))
								cv.put("lot_no", par.getText());
							else if ("quantity".equals(namefield))
								cv.put("quantity", par.getText());
							else if ("supplier_id".equals(namefield))
								cv.put("supplier_id", par.getText());
							else if ("created_by".equals(namefield))
								cv.put("created_by", par.getText());
							else if ("updated_by".equals(namefield))
								cv.put("updated_by", par.getText());
						}
						try {
							cv.put("sync_status","1");
							mydatabase.insert("qaUpdate",null,cv);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			mydatabase.close();

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IllegalStateException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return temp;
	}
	public void updateqaDetails(String lotno,String qastatus,String spec,String remark,String comment,String createdtime,String qastart,String qaupdate,String stockid,String sync){
		myhelper.getWritableDatabase();
		mydatabase.execSQL("update wh_qa set qa_status='"+qastatus+"',specification='"+spec+"',remarks='"+remark+"',comments='"+comment+"',created_time='"+createdtime+"'," +
				"qa_starttime='"+qastart+"',qa_updatedtime='"+qaupdate+"',stock_id='"+stockid+"' ,sync_status='"+sync+"' where lot_no='"+lotno+"';");

	}
	public Cursor sqlreadwhere(String Tname,String[] selection,String args,String[] values){
		try {
			cr=mydatabase.query(true,Tname,selection,args,
					values, null, null, null,
					null);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return cr;

	}

	public boolean sqlDelTable(String Tname)
	{
		return mydatabase.delete(Tname, null, null) > 0;
	}


	public Cursor ListPlants()
	{
		return this.mydatabase.rawQuery("select * from Warehouse_No", null);
	}





	public  Cursor update()
	{
		return this.mydatabase.rawQuery("update Pickme_Table set pay_amount = 0", null);
	}








	public Cursor Total()
	{
		String stdate=	Utils.SharedPreferencesContain(mycontext, "Startdate");

		String endate =Utils.SharedPreferencesContain(mycontext, "Enddate");

		return this.mydatabase.rawQuery("select sum (payamount) as sum from dailypickme where timestamp<'"+endate+"' and timestamp>'"+stdate+"' or  timestamp='"+stdate+"'  ", null);

	}



	public   Cursor getDBNames(){

		try {
			StringBuilder sb = new StringBuilder();
			sb.append("SELECT name FROM sqlite_master ");
			sb.append("WHERE type IN ('table','view') AND name NOT LIKE 'sqlite_%' AND name" +
					" NOT LIKE 'android_metadata' ");

			//HERE name NOT LIKE 'sqlite_%' AND name NOT LIKE 'android_metadata' ORDER BY name
			sb.append("UNION ALL ");
			sb.append("SELECT name FROM sqlite_temp_master ");
			sb.append("WHERE type IN ('table','view') ");
			sb.append("ORDER BY 1");
			String sql =sb.toString();
			Log.d("string", sql)
			;
			Cursor c = mydatabase.rawQuery(sql, null);
			return c;
		}
		catch(Exception e){
			Log.e("OOPS", e.toString());
			return null;
		}

	}




	public static double  RoundDecimal(double value, int decimalPlace) {
		try{
			java.math.BigDecimal bd = new java.math.BigDecimal(value);

			bd = bd.setScale(decimalPlace, 6);

			return bd.doubleValue();
		}catch(Exception e){
			return 0.0;
			//return "";
		}
	}




	private static class dbhelper extends SQLiteOpenHelper {


		public dbhelper(Context context) {
			super(context, database_name, null, database_ver);
			// TODO Auto-generated constructor stub



		}



		@Override
		public void onCreate(SQLiteDatabase db) {
			// TODO Auto-generated method stub


			//***********************  Creating Table  *******************************//




			try {
//				db.execSQL("CREATE TABLE " + tbl_warehouse_no + " (" +
//
//						key_warehouse_no_id + " INTEGER PRIMARY KEY AUTOINCREMENT, "+
//
//						key_warehouse_no_plantno + " TEXT NOT NULL "+"  );");


				db.execSQL("CREATE TABLE " + tbl_assign_warehouse + " (" +

						key_assign_warehouse_id + " TEXT UNIQUE NOT NULL, "+
						key_assign_warehouse_plantno + " TEXT NOT NULL ,"+
						key_assign_warehouse_uname + " TEXT NOT NULL "+"  );");



				db.execSQL("CREATE TABLE " + tbl_palnts+ " (" +

						key_plants_id + " TEXT , "+

						key_plants_name + " TEXT NOT NULL "+"  );");

				db.execSQL("CREATE TABLE " + tbl_mobile_user + " (" +

						key_mobileuser_id + " INTEGER PRIMARY KEY AUTOINCREMENT, "+
						key_mobileuser_name + " TEXT NOT NULL "+"  );");



				db.execSQL("CREATE TABLE " + tbl_mobile_userOffline + " (" +

						key_mobileuserOffline_id + " INTEGER PRIMARY KEY AUTOINCREMENT, "+
						key_mobileuserOffline_uname + " TEXT UNIQUE NOT NULL, "+
						key_mobileuserOffline_password + " TEXT UNIQUE NOT NULL "+"  );");


				db.execSQL("CREATE TABLE " + tbl_orderno_lotno + " (" +

						key_orderno_lotno_id + " INTEGER PRIMARY KEY AUTOINCREMENT, "+
						key_orderno_lotno_lotno + " TEXT , "+
						key_orderno_lotno_orderno+ " TEXT , "+
						key_orderno_lotno_item_name + " TEXT , "+
						key_orderno_lotno_raw_quantity + " TEXT  "+" );");


//				db.execSQL("CREATE TABLE " + tbl_suppliers + " (" +
//
//						key_supplier_id + " INTEGER PRIMARY KEY AUTOINCREMENT, "+
//						key_supplier_code + " TEXT , "+
//						key_supplier_name + " TEXT  "+" );");

				/**create add stock local table**/
//				db.execSQL("CREATE TABLE " + tbl_warehouse_addsock + " (" +
//
//						key_warehouse_addstock_stockid + " INTEGER PRIMARY KEY AUTOINCREMENT, "+
//						key_warehouse_addstock_Stocktype + " TEXT , "+
//						key_warehouse_addstock_ordernumber + " TEXT , "+
//						key_warehouse_addstock_suppliercode+ " TEXT ,"
//+						key_warehouse_addstock_itemcode + " TEXT NOT NULL, "+
//						key_warehouse_addstock_qcinspno + " TEXT , "+
//						key_warehouse_addstock_RMARnumber + " TEXT , "+
//						key_warehouse_addstock_batchnumber + " TEXT , "+
//						key_warehouse_addstock_RmSpecNo + " TEXT , "+
//						key_warehouse_addstock_GIRNo + " TEXT , "+
//						key_warehouse_addstock_commoditygrade + " TEXT , "+
//						key_warehouse_addstock_variety + " TEXT , "+
//						key_warehouse_addstock_EstYiels + " TEXT , "+
//						key_warehouse_addstock_ExpDate + " TEXT , "+
//						key_warehouse_addstock_totalquantity + " TEXT NOT NULL, "+
//						key_warehouse_addstock_noofbags + " TEXT NOT NULL, "+
//						key_warehouse_addstock_UnitPrice + " TEXT , "+
//						key_warehouse_addstock_lotnumber + " TEXT , "+
//						key_warehouse_addstock_ArrivalForm + " TEXT , "+
//						key_warehouse_addstock_arrivaldate + " TEXT , "+
//						key_warehouse_addstock_Remarks + " TEXT , "+
//						key_warehouse_addstock_intentstatus + " TEXT , "+
//						key_warehouse_addstock_location_status + " TEXT , "+
//						key_warehouse_createdtime + " TEXT , "+
//						key_warehouse_server_stockID + " TEXT , "+
//						key_warehouse_syncstatus + " TEXT "+" );");


				/**add stock stephy**/

				db.execSQL("CREATE TABLE " + tbl_warehouse_addsock  + " (" +

						key_warehouse_addstock_stockid + " INTEGER PRIMARY KEY AUTOINCREMENT, "+
						key_warehouse_addstock_Stocktype + " TEXT , "+
						key_warehouse_addstock_itemid + " TEXT , "+
						key_warehouse_addstock_itemcode + " TEXT , "+
						key_warehouse_addstock_lotnumber + " TEXT , "+
						key_warehouse_addstock_totalquantity + " TEXT NOT NULL, "+
						key_warehouse_addstock_warehousecode+ " TEXT ,"+
						key_warehouse_addstock_suppliercode+ " TEXT ,"+
						key_warehouse_addstock_ordernumber + " TEXT , "+
						key_warehouse_createdtime + " TEXT , "+
						key_warehouse_server_stockID + " TEXT , "+
						key_warehouse_syncerrorstatus + " TEXT,"+
						key_warehouse_syncstatus + " TEXT"+");");


				/**create issue stock local table**/
				db.execSQL("CREATE TABLE " + tbl_warehouse_issuestock+ " (" +

						key_warehouse_issuestock_issueid + " INTEGER PRIMARY KEY AUTOINCREMENT , "+
						key_warehouse_issuestock_issuecode + " TEXT , "+
						key_warehouse_issuestock_Stocktype + " TEXT , "+
						key_warehouse_issuestock_itemcode + " TEXT NOT NULL, "+
						key_warehouse_issuestock_timestamp + " varchar(13) , "+
						key_warehouse_issuestock_lotnumber + " TEXT , "+
						key_warehouse_issuestock_batchnumber + " TEXT , "+
						key_warehouse_issuestock_RMARnumber + " TEXT , "+
						key_warehouse_issuestock_Plantid + " TEXT , "+
						key_warehouse_issuestock_OrderNumber + " TEXT , "+
						key_warehouse_issuestock_toWareHousid + " TEXT , "+
						key_warehouse_issuestock_RequiredQty + " TEXT , "+
						key_warehouse_issuestock_IssuedQty + " TEXT , "+
						key_warehouse_issuestock_IssuedTo + " TEXT , "+
						key_warehouse_issuestock_location_status + " TEXT , "+
						key_warehouse_createdtime + " TEXT , "+
						key_warehouse_server_stockissueID + " TEXT , "+
						key_warehouse_syncstatus + " TEXT "+" );");

				db.execSQL("CREATE TABLE " + tbl_warehouse_updatelocation+ " (" +

						key_warehouse_updatelocation_locationid + " INTEGER PRIMARY KEY AUTOINCREMENT, "+
						key_warehouse_updatelocation_warehouseid + " TEXT , "+
						key_warehouse_updatelocation_stockid + " TEXT , "+
						key_warehouse_updatelocation_itemcode + " TEXT , "+
						key_warehouse_updatelocation_palletno + " TEXT , "+
						key_warehouse_updatelocation_rakerow + " TEXT , "+
						key_warehouse_updatelocation_rakecolumn + " TEXT , "+
						key_warehouse_updatelocation_refposition + " TEXT , "+
						key_warehouse_updatelocation_qty + " TEXT , "+
						key_warehouse_createdtime + " TEXT , "+
						key_warehouse_server_stockID + " TEXT , "+
						key_warehouse_syncstatus + " TEXT "+" );");

				db.execSQL("CREATE TABLE " + tbl_Items+ " (" +

						key_warehouse_item_itemid + " TEXT , "+
						key_warehouse_item_itemcode + " TEXT , "+
						key_warehouse_item_itemname + " TEXT , "+
						key_warehouse_item_category + " TEXT , "+
						key_warehouse_item_subcategory + " TEXT , "+
						key_warehouse_item_itemUnit + " TEXT , "+
						key_warehouse_item_itemtype + " TEXT "+" );");

				db.execSQL("CREATE TABLE " + tbl_Stock_QAChecklist+ " (" +

						key_Stock_QAChecklist_qaid + " INTEGER PRIMARY KEY AUTOINCREMENT, "+
						key_Stock_QAChecklist_stockid + " TEXT , "+
						key_Stock_QAChecklist_IntegrityofBags + " TEXT , "+
						key_Stock_QAChecklist_Appearance + " TEXT , "+
						key_Stock_QAChecklist_ExtraneousMatter + " TEXT , "+
						key_Stock_QAChecklist_Other + " TEXT , "+
						key_Stock_QAChecklist_Remarks+ " TEXT , "+
						key_warehouse_createdtime + " TEXT , "+
						key_warehouse_server_stockID + " TEXT , "+
						key_warehouse_syncstatus + " TEXT "+" );");

				db.execSQL("CREATE TABLE " + tbl_warehouse_update_issue_location+ " (" +

						key_warehouse_updatelocation_locationid + " INTEGER PRIMARY KEY AUTOINCREMENT, "+
						key_warehouse_updatelocation_warehouseid + " TEXT , "+
						key_warehouse_issuestockupdatelocation_issueid + " TEXT , "+
						key_warehouse_updatelocation_itemcode + " TEXT , "+
						key_warehouse_updatelocation_palletno + " TEXT , "+
						key_warehouse_updatelocation_rakerow + " TEXT , "+
						key_warehouse_updatelocation_rakecolumn + " TEXT , "+
						key_warehouse_updatelocation_refposition + " TEXT , "+
						key_warehouse_updatelocation_qty + " TEXT , "+
						key_warehouse_createdtime + " TEXT , "+
						key_warehouse_server_stockissueID + " TEXT , "+
						key_warehouse_syncstatus + " TEXT "+" );");


				db.execSQL("CREATE TABLE " + tbl_Config+ " (name TEXT, value TEXT  );");
				db.execSQL("CREATE TABLE wh_qa(_id INTEGER PRIMARY KEY AUTOINCREMENT,item_type TEXT,item_id TEXT,itemcode TEXT,lot_no TEXT, quantity TEXT,Supplier TEXT,Supplier_id TEXT,qa_status TEXT," +
						"specification TEXT,remarks TEXT,comments TEXT,created_time TEXT,created_by TEXT,created_by_id TEXT,qa_starttime TEXT,qa_updatedtime TEXT,sync_status TEXT,stock_id TEXT,add_sync TEXT);");
				db.execSQL("create table qaUpdate(_id INTEGER PRIMARY KEY AUTOINCREMENT,qa_sample_id TEXT,item_id TEXT,lot_no TEXT," +
						"quantity TEXT,supplier_id TEXT,specification TEXT,remarks TEXT,comments TEXT,qa_start_time TEXT,sync_status TEXT," +
						"qa_status TEXT,stock_id TEXT,created_time TEXT,qa_updated_time TEXT,created_by TEXT,updated_by TEXT);");
				db.execSQL("create table suppliers(_id INTEGER PRIMARY KEY AUTOINCREMENT,supplier_id TEXT,supplier_code,supplier_name TEXT);");
				db.execSQL("create table Warehouse_No(_id INTEGER PRIMARY KEY AUTOINCREMENT,warehouse_id TEXT,warehouse_no TEXT);");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}



		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			// TODO Auto-generated method stub
		}

	}



}
