package com.aucupa.warehouse;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.aucupa.warehouse.adapter.Stock_adapter;

public class Qa_viewbook extends Activity {
    ListView list;
    Stock_adapter stockAdapter;
    String sync_status,sync;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qa_viewbook);
        list=(ListView)findViewById(R.id.listViewStock);
        Sqldatabase db=new Sqldatabase(Qa_viewbook.this);
        Cursor c=db.getAddstock();
        int count=c.getCount();
        if(count>0)
        {

                stockAdapter = new Stock_adapter(Qa_viewbook.this, c);
                list.setAdapter(stockAdapter);
                list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                        final String id = String.valueOf(stockAdapter.getItemId(i));
                        Sqldatabase db = new Sqldatabase(Qa_viewbook.this);
                        Cursor c = db.getstockDetails(id);
                        if (c.moveToNext())
                        {
                            sync_status =c.getString(c.getColumnIndexOrThrow("error_sync"));
                            if (sync_status.equals("502"))
                            {
                                //int sync_status = c.getColumnIndexOrThrow("error_sync");
                                Intent ne = new Intent(Qa_viewbook.this, Up_Addstock.class);
                                ne.putExtra("item", id);
                                startActivity(ne);
                                finish();


                            }
                        }


                    }
                });
            }

        else
        {
            Toast.makeText(getApplicationContext(),"No Records Found !!",Toast.LENGTH_LONG).show();
        }


    }

    @Override
    public void onBackPressed()
    {
        Intent i=new Intent(Qa_viewbook.this,Select_Activity.class);
        startActivity(i);

    }
}
