package com.aucupa.warehouse.sync;

import java.util.ArrayList;

public class SyncResponseDataWrapper {

	public static class SyncToServerResponseData
	{
		public String Clientid;
		public String Serverid;
	}
	
	public static class SyncFromServerStockInResponseData
	{
		public String x;
		public String y;
	}
	public static class SyncFromServerStockOutResponseData
	{
		public String x;
		public String y;
	}
	public static class SyncFromServerLocationInResponseData
	{
		public String x;
		public String y;
	}
	public static class SyncFromServerLocationOutResponseData
	{
		public String x;
		public String y;
	}
	public static class SyncFromServerItemDetailsResponseData
	{
		public String id;
		public String itemcode;
		public String itemname;
		public String categoryname;
		public String subCategoryname;
		public String itemtype;
		public String itemunit;
	}
	public static class SyncFromServerWareDetailsResponseData
	{
		public String id;
		public String warehouse_no;
	}
	public static class SyncFromServerSupplierDetailsResponseData
	{
		public String supplierid;
		public String suppliercode;
		public String suppliername;
	}
	public static class SyncLivestockResponseData
	{
		public String itemcode;
		public String itemname;
		public String itemtype;
		public String quantity;
		public ArrayList<LivestockLocation> location;
	}
	public static class LivestockLocation{
		public String warehouse_no;
		public String rake_row;
		public String rake_column;
		public String lqty;
	}
}
