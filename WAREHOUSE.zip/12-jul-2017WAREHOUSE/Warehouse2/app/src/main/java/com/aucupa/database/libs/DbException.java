package com.aucupa.database.libs;

public class DbException extends Exception {
	/**
	 * Set DB exception.
	 * 
	 * @param message
	 */
	public DbException(String message) {
		super(message);
	}
}
