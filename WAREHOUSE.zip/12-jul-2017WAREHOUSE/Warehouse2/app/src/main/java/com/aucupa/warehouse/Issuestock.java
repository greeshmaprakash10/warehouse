package com.aucupa.warehouse;

import java.util.ArrayList;
import java.util.HashMap;

import com.aucupa.warehouse.sync.SyncServerRequest;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Issuestock extends Activity {

	
	EditText etItemcode,etItemname,etLotNo,etBatchNo,etPOrder,etReqQty,etissuedQty;
	//EditText etRMARno;
	String stItemcode,stItemname,stLotNo,stBatchNo,stPOrder="",
			stplantno="",stwarehouseno="",stReqQty,stissuedQty,
	ststocktypeselect="1",stissueTo;
//	String stRMARno;
	
	Spinner spinstockType,spinplantname,spinwarehousename;
	
	RadioGroup radiogroupissue;
	RadioButton radioplant,radioorder,radiowarehouse;
	LayoutInflater inflator; 
	 
	LinearLayout itemAddd_layout;
	HorizontalScrollView horizontalScrollView;
	
	String[] warehousenames={"WH1","WH2","WH3"};
	String[] plantnames={"Plant1","plant2","plant3"};
	
	Button btnadd,btnremove;
	
	int stselctnnumber=0,ststocktypeindex,stissuestockid,stplantnameindex,stwarehouseindex;
	float ststockbalance=0,stCurrenttotal=0;;
	int j=0;	
	
	ArrayList<HashMap<String, String>> al_itemdetailsarray;
	HashMap<String, String> hm_itemdetails;
	
	ArrayList<String> itemcodelist,plantidlist,plantnamelist,warehouseidlist,warehousenamelist,
	stockidlist;
	
	boolean stinput_flag=true,issue_flag=true,sucess_status=false;
	
	
	SQLiteDatabase sdb;
	
	String stStatus = 0+"";	
	String stlocation_status=""+0;
	Context context;
	Sqldatabase db;
	Utils utility;
	
	AutoCompleteTextView editItemc;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.issuestock2);
		
		context=this;
		db=new Sqldatabase(context);
		sdb=db.getdb();
		
		
		itemAddd_layout=(LinearLayout)findViewById(R.id.lladditem);
		
		horizontalScrollView=(HorizontalScrollView)findViewById(R.id.hrzlayout);
		
		
		radiogroupissue=(RadioGroup)findViewById(R.id.radiogrupissueto);
		
		btnadd=(Button)findViewById(R.id.btnadd);
		
		radioplant=(RadioButton)findViewById(R.id.radioplant);
		radioorder=(RadioButton)findViewById(R.id.radioorder);
		radiowarehouse=(RadioButton)findViewById(R.id.radiowarehouse);

		
		etPOrder=(EditText)findViewById(R.id.editissuestockpo);
		etItemname=(EditText)findViewById(R.id.editissuestockitemname);
		etLotNo=(EditText)findViewById(R.id.editissuestocklotno);
//		etRMARno=(EditText)findViewById(R.id.editissuestockrmarno);
		etBatchNo=(EditText)findViewById(R.id.editissuestockbatchnumber);
		etReqQty=(EditText)findViewById(R.id.editissuestockreqqty);
		etissuedQty=(EditText)findViewById(R.id.editissuestockissueqty);
		
		spinplantname=(Spinner)findViewById(R.id.spinissuestockplantnames);
		spinwarehousename=(Spinner)findViewById(R.id.spinissuestockwhnames);
		spinstockType=(Spinner)findViewById(R.id.spinissuestocktype);
		
		spinstockType.setSelection(2);
		
		al_itemdetailsarray=new ArrayList<HashMap<String,String>>();
		itemcodelist=new ArrayList<String>();
		plantidlist=new ArrayList<String>();
		plantnamelist=new ArrayList<String>();
		warehouseidlist=new ArrayList<String>();
		warehousenamelist=new ArrayList<String>();
		stockidlist=new ArrayList<String>();

		editItemc = (AutoCompleteTextView) findViewById(R.id.editissuestockitemcode); 
		
		/**ware house No**/
//		stWareHouseNo=utility.SharedPreferencesContain(Issuestock.this,"Warehouse_No");
		
		stissueTo="Plant";
		
		/**add items To Spinner Plant name and wareHouse**/
		Cursor crplant=db.getdb().query(db.tbl_palnts,
				new String[]{db.key_plants_id,db.key_plants_name},null,null,null,null,null);
		if(crplant.getCount()>0){
			plantidlist.clear();
			plantnamelist.clear();
			while (crplant.moveToNext()) {
				plantidlist.add(crplant.getString(0).toString());
				plantnamelist.add(crplant.getString(1).toString());
			}
		}
		ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
				R.layout.spinner_item, plantnamelist);
			dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			spinplantname.setAdapter(dataAdapter);
		
			Cursor crwh=db.getdb().query(db.tbl_warehouse_no,
					new String[]{db.key_warehouse_no_id,db.key_warehouse_no_plantno},null,null,null,null,null);
			if(crwh.getCount()>0){
				warehouseidlist.clear();
				warehousenamelist.clear();
				while (crwh.moveToNext()) {
					warehouseidlist.add(crwh.getString(0).toString());
					warehousenamelist.add(crwh.getString(1).toString());
				}
			}
			dataAdapter = new ArrayAdapter<String>(this,
					R.layout.spinner_item, warehousenamelist);
			dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			spinwarehousename.setAdapter(dataAdapter);
	
		radioplant.setChecked(true);
		/** Radio group issue to **/
		radiogroupissue.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			
			@Override 
			public void onCheckedChanged(RadioGroup group, int checkedId) {
				// TODO Auto-generated method stub
				
				switch (checkedId) {
				case R.id.radioplant:
					spinplantname.setVisibility(View.VISIBLE);
					etPOrder.setVisibility(View.GONE);
					etPOrder.setText("");
					stissueTo="Plant";
					stissuestockid=0;
					spinwarehousename.setVisibility(View.GONE);
					spinplantname.setSelection(0);
					spinwarehousename.setSelection(0);
					stwarehouseindex=0;
					stplantnameindex=0;
					stwarehouseno="";
					stplantno="";
					etPOrder.setText("");
					stPOrder="";
					/**add items To Spinner Plant name**/

			

					break;
				case R.id.radioorder:
					spinplantname.setVisibility(View.GONE);
					etPOrder.setVisibility(View.VISIBLE);
					etPOrder.setText("");
					stissueTo="Order";
					stissuestockid=1;
					spinwarehousename.setVisibility(View.GONE);		
					spinplantname.setSelection(0);
					spinwarehousename.setSelection(0);
					stwarehouseindex=0;
					stplantnameindex=0;
					stwarehouseno="";
					stplantno="";
					stPOrder="";
					etPOrder.setText("");
					

					
					break;
				case R.id.radiowarehouse:
					spinplantname.setVisibility(View.GONE);
					etPOrder.setVisibility(View.GONE);
					etPOrder.setText("");
					stissueTo="WareHouse";
					stissuestockid=2;
					spinwarehousename.setVisibility(View.VISIBLE);
					spinplantname.setSelection(0);
					spinwarehousename.setSelection(0);
					stwarehouseindex=0;
					stplantnameindex=0;
					stwarehouseno="";
					stplantno="";
					stPOrder="";
					break;
					default:stissueTo="Plant";
					break;
					
				}
				
			}
		});
		
		/** Spinner Selections **/
		spinstockType.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int position, long arg3) {
				// TODO Auto-generated method stub
				ststocktypeindex=position;
				switch (position) {
				case 2:
					ststocktypeselect="1";
					autoCompletefill(1);
					editItemc.setText("");
					etItemname.setText("");
					break;
					
				case 1:
					ststocktypeselect="2";
					autoCompletefill(1);
					editItemc.setText("");
					etItemname.setText("");
						break;
				case 0:
					ststocktypeselect="3";
					autoCompletefill(1);
					editItemc.setText("");
					etItemname.setText("");
							break;	
				default:
					break;
				}
				
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				spinstockType.setSelection(2);
				ststocktypeindex=2;
			}
		});
		
		spinplantname.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View view, int position, long arg3) {
				// TODO Auto-generated method stub
				stplantno=plantidlist.get(position);
				stplantnameindex=position;
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				spinplantname.setSelection(0);
				stplantnameindex=0;
			}
		});
		
		spinwarehousename.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View view, int position, long arg3) {
				// TODO Auto-generated method stub
				stwarehouseno=warehouseidlist.get(position);
				stwarehouseindex=position;
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				spinwarehousename.setSelection(0);
				stwarehouseindex=0;
			}
		}); 
		
		
		/** ItemCoode Auto Complete **/
		autoCompletefill(0);
		
		editItemc.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				Cursor c=db.sqlQuery(" select "+db.key_warehouse_item_itemname+" from "+db.tbl_Items+
						" where "+db.key_warehouse_item_itemcode+"='"+((TextView)arg1).getText().toString()+"'");
						
				//Toast.makeText(getApplicationContext(),""+c.getCount(),Toast.LENGTH_SHORT).show();
				if(c.getCount()>0){
					while (c.moveToNext()) {
						etItemname.setText(c.getString(0));
						break;	
					}
				}
			}
		});
		
	}
	
	public void autoCompletefill(int status) {
		itemcodelist.clear();
		stockidlist.clear();
		String MY_QUERY;
		Cursor c=null;
		switch (status)
		{
		case 1:
		c=db.sqlQuery(" select "+db.key_warehouse_item_itemcode+","+
				db.key_warehouse_item_itemname+" from "+db.tbl_Items+" where "+db.key_warehouse_item_itemtype+"='"+ststocktypeselect+"'");
			break;
		default:
			c=db.sqlQuery(" select "+db.key_warehouse_item_itemcode+","+
					db.key_warehouse_item_itemname+" from "+db.tbl_Items);
			
			
		}
		if(c.getCount()>0){
			while (c.moveToNext()) {
				itemcodelist.add(c.getString(0));
			}
		}
		
		ArrayAdapter<String> adapter =new ArrayAdapter<String>(getApplicationContext(),R.layout.autolistview,itemcodelist);
		editItemc.setAdapter(adapter);
	}
	
	public void clearContainers() {
		//etItemcode.setText("");
		etItemname.setText("");
		etLotNo.setText("");
//		etRMARno.setText("");
		etBatchNo.setText("");
		etPOrder.setText("");
		etReqQty.setText("");
		etissuedQty.setText("");
		editItemc.setText("");
		spinstockType.setSelection(2);
		spinplantname.setSelection(0);
		spinwarehousename.setSelection(0);
		stCurrenttotal=0;
		containerTostring();
		sucess_status=false;
	}
	
	public void clicktoSave(View v){
		stinput_flag=true;
		issue_flag=true;
		/** Load data From Array List **/
	if(editItemc.length()>0)
		{
		if(!(editItemc.length()<1)){
			if(!(etItemname.length()<1)){
//				if(!(etLotNo.length()<1)){
//					if(!(etRMARno.length()<1)){
//						if(!(etBatchNo.length()<1)){
							if(etissuedQty.length()>0){
									Cursor c=db.sqlQuery(" select "+db.key_warehouse_item_itemcode+","+
											db.key_warehouse_item_itemcode+
											" from "+db.tbl_Items+" where "+
											db.key_warehouse_item_itemcode+"='"+editItemc.getText().toString()+"'");
											
									if(c.getCount()<=0)
									{
										
										showToast(0,"there is no such item code");
										stinput_flag=false;
										issue_flag=false;
									}
									else
									{
//										
//										if(CheckTotalBalance()){
//											
//											containerTostring();
//											insertToHash();
//											stinput_flag=true;
//											issue_flag=true;
//										}
//										
//										else
//										{
//											showToast(0,"Insufficient Stock");
//											stinput_flag=false; 
//											issue_flag=false;
//										}
										containerTostring();
										insertToHash();
										stinput_flag=true;
										issue_flag=true;
									}
							
							}else
							{
								stinput_flag=false; 
								issue_flag=false;
								showToast(0,"Enter Issued Qty");
							}
//						}else{
//							stinput_flag=false; 
//							issue_flag=false;
//							showToast(0,"Enter Batch Number");
//						}
//					}else{
//						stinput_flag=false; 
//						issue_flag=false;
//						showToast(0,"Enter RMAR Number");
//					}
//				}else{
//					stinput_flag=false; 
//					issue_flag=false;
//					showToast(0,"Enter Lot Number");
//				}
			}else{
				stinput_flag=false; 
				issue_flag=false;
				showToast(0,"Invalid Item Code Selected");
			}
		}else
		{
			stinput_flag=false; 
			issue_flag=false;
			showToast(0,"Enter Item Code");
		}
		
		}
		HashMap< String, String> data=new HashMap<String, String>();
		
		if(stinput_flag && issue_flag)
		{
			if(al_itemdetailsarray.size()<=0){
				showToast(0,"No Items For Issue");
				issue_flag=false;
			}
			else
			{

				String issuecode=getnextissueCode();
				for(int i=0;i<al_itemdetailsarray.size();i++){
					data=al_itemdetailsarray.get(i);
					ContentValues cv=new ContentValues();
					cv.put(db.key_warehouse_issuestock_issuecode,issuecode);
					cv.put(db.key_warehouse_issuestock_Stocktype, data.get("StockType"));
					cv.put(db.key_warehouse_issuestock_itemcode, data.get("ItemCode"));
					cv.put(db.key_warehouse_issuestock_lotnumber, data.get("LotNo"));
					cv.put(db.key_warehouse_issuestock_batchnumber, data.get("BatchNo"));
//					cv.put(db.key_warehouse_issuestock_RMARnumber, data.get("RMARNo"));
					cv.put(db.key_warehouse_issuestock_Plantid, data.get("Plant_No"));
					cv.put(db.key_warehouse_issuestock_OrderNumber, data.get("PO"));
					cv.put(db.key_warehouse_issuestock_toWareHousid, data.get("WareHouse_No"));
					cv.put(db.key_warehouse_issuestock_RequiredQty, data.get("reqQty"));
					cv.put(db.key_warehouse_issuestock_IssuedQty, data.get("issuedQty"));
					cv.put(db.key_warehouse_issuestock_IssuedTo, data.get("issueto"));
					cv.put(db.key_warehouse_issuestock_location_status, stlocation_status);
					cv.put(db.key_warehouse_createdtime, Utils.getSystemTimeStamp());
					cv.put(db.key_warehouse_syncstatus,"0");
					

					if(db.sqlins(db.tbl_warehouse_issuestock, cv)>0){
						sucess_status=true;
						try {//TODO Sync add stock by roy
							SyncServerRequest synctoserverRequest;
							 synctoserverRequest=((WhApp)getApplication()).syncRequest;
							//synctoserverRequest=new SyncServerRequest(context);
							synctoserverRequest.synctoIssueINRequest();
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
//						Cursor curs=sdb.query(db.tbl_warehouse_addsock, new String[] { db.key_warehouse_addstock_totalquantity,db.key_warehouse_addstock_ordernumber}
//						,db.key_warehouse_addstock_itemcode+" = ? "+ "and "  +
//				                db.key_warehouse_addstock_Stocktype + " = ? ",
//					            new String[] {data.get("ItemCode"),data.get("StockType")}, null, null, db.key_warehouse_addstock_ordernumber,null);
//						if(curs.getCount()>0){	
//							int issueqty= Integer.parseInt(data.get("issuedQty"));
//							String orderno;
//							while(curs.moveToNext()){
//								orderno=curs.getString(1);
//								if(issueqty==0)
//								{
//									break;
//								}
//								String newtotal=curs.getString(0);
//								do{
//									if(newtotal.equals(""+0)){
//										break;
//									}
//									if(Integer.parseInt(curs.getString(0))>=issueqty){
//										newtotal=String.valueOf(Integer.parseInt(curs.getString(0))-issueqty);
//										issueqty=0;
//									}
//									else
//									{
//										 newtotal=""+0;
//										issueqty=issueqty-Integer.parseInt(curs.getString(0));
//									}
//									ContentValues cvupdate=new ContentValues();
//									cvupdate.put(db.key_warehouse_addstock_totalquantity, newtotal);
//
//								sdb.update(db.tbl_warehouse_addsock, cvupdate,db.key_warehouse_addstock_itemcode+" = ? "+ "and "  +
//				                db.key_warehouse_addstock_Stocktype + " = ? "+ "and "  +
//						                db.key_warehouse_addstock_ordernumber + " = ? "+ "and "  +
//								                db.key_warehouse_addstock_warehouseno + " = ? ",
//						                new String[] {data.get("ItemCode"),data.get("StockType"),orderno,data.get("WareHouseNo")});
//								
//								}while(issueqty!=0);
//							
//								
//							}
						}
//						if(issue_flag)
//						{
//							issue_flag=true;
//							sucess_status=true;
//						}
//					}
//					else{
//						issue_flag=false;
//						sucess_status=false;
//					}
				}
			}
		}
		if(sucess_status)
			{
			showToast(1,"Item issued Successfully");
			clearAllContainerInflaors(v);
			sucess_status=false;
			al_itemdetailsarray.clear();
			}
					
	}
	
	
	public void clearAllContainerInflaors(View v)
	{
		//find lay out from view
		clearContainers();
		ViewGroup parent=(ViewGroup) v.getParent().getParent();
		String itcode="";
		ViewGroup Childsrollview=(ViewGroup) parent.getChildAt(2);
		ViewGroup horicontalview=(ViewGroup) Childsrollview.getChildAt(0);
		ViewGroup linearview=(ViewGroup) horicontalview.getChildAt(1);
		int i=0;
		while(i<linearview.getChildCount())
		{
			
			
			ViewGroup container=(ViewGroup) linearview.getChildAt(i);
			linearview.removeView(container);
		}
		horizontalScrollView.setVisibility(View.GONE);
	}
	
	public void containerTostring() {
		stItemcode=editItemc.getText().toString();
		stItemname=etItemname.getText().toString();
		stLotNo=etLotNo.getText().toString();
//		stRMARno=etRMARno.getText().toString();
		stBatchNo=etBatchNo.getText().toString();
		stReqQty=etReqQty.getText().toString();
		stissuedQty=etissuedQty.getText().toString();
		stPOrder=etPOrder.getText().toString();
		stinput_flag=true;
	}
	
	public void addNewitem(View v){
		
		if(!(editItemc.length()<1)){
			if(!(etItemname.length()<1)){
//				if(!(etLotNo.length()<1)){
//					if(!(etRMARno.length()<1)){
//						if(!(etBatchNo.length()<1)){
							if(etissuedQty.length()>0)
							{	
								Cursor c=db.sqlQuery(" select "+db.key_warehouse_item_itemcode+","+
									db.key_warehouse_item_itemcode+
									" from "+db.tbl_Items+" where "+
									db.key_warehouse_item_itemcode+"='"+editItemc.getText().toString()+"'");
											
									if(c.getCount()<=0)
									{
										showToast(0,"there is no such item code");
									}
									else
									{
										horizontalScrollView.setVisibility(View.VISIBLE);
										inflator=(LayoutInflater)this.getSystemService(this.LAYOUT_INFLATER_SERVICE);
										View v1=inflator.inflate(R.layout.additem_layout, null);
									
										containerTostring();
										
										setAddItemDetails(v1);
										
										itemAddd_layout.addView(v1);
										clearContainers(); 
									}
							}else
							{
								showToast(0,"Enter Issued Qty");

							}
//						}else{
//							showToast(0,"Enter Batch Number");
//						}
//					}else{
//						showToast(0,"Enter RMAR Number");
//					}
//				}else{
//					showToast(0,"Enter Lot Number");
//				}
			}else{
				showToast(0,"Invalid Item Code Selected");
			}
		}else
		{
			showToast(0,"Enter Item Code");
		}

	}
	public void Remove(View v) {
	 ViewGroup Grandparent = (ViewGroup) v.getParent().getParent().getParent();
     ViewGroup parent = (ViewGroup) v.getParent().getParent();
     int pos=Grandparent.indexOfChild(parent);	//get the position of dynamically created view in parent view
     Grandparent.removeView(parent);
     al_itemdetailsarray.remove(pos);
     if(Grandparent.getChildCount()<1)
    	 horizontalScrollView.setVisibility(View.GONE);
     showToast(1,"Remove Item");
	}
	
	public void setAddItemDetails(View v) {
		EditText etvPOrder=(EditText)v.findViewById(R.id.veditissuestockpo);
		EditText etvItemcode=(EditText)v.findViewById(R.id.veditissuestockitemcode);
		EditText etvItemname=(EditText)v.findViewById(R.id.veditissuestockitemname);
		EditText etvLotNo=(EditText)v.findViewById(R.id.veditissuestocklotno);
//		EditText etvRMARno=(EditText)v.findViewById(R.id.veditissuestockrmarno);
		EditText etvBatchNo=(EditText)v.findViewById(R.id.veditissuestockbatchnumber);
		EditText etvReqQty=(EditText)v.findViewById(R.id.veditissuestockreqqty);
		EditText etvissuedQty=(EditText)v.findViewById(R.id.veditissuestockissueqty);
		Spinner spinvplantname=(Spinner)v.findViewById(R.id.vspinissuestockplantnames);
		Spinner spinvwarehousename=(Spinner)v.findViewById(R.id.vspinissuestockwhnames);
		Spinner spinvstockType=(Spinner)v.findViewById(R.id.vspinissuestocktype);
		
		/**add items To Spinner Plant name and wareHouse**/
		ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
				R.layout.spinner_item, plantnamelist);
			dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			spinvplantname.setAdapter(dataAdapter);
			
			dataAdapter = new ArrayAdapter<String>(this,
					R.layout.spinner_item, warehousenamelist);
			dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			spinvwarehousename.setAdapter(dataAdapter);
		
		
		
			spinvstockType.setSelection(ststocktypeindex);
			spinvplantname.setSelection(stplantnameindex);
			spinvwarehousename.setSelection(stwarehouseindex);

			switch (stissuestockid) {
			case 0:
				spinvplantname.setVisibility(View.VISIBLE);
				spinvwarehousename.setVisibility(View.GONE);
				etvPOrder.setVisibility(View.GONE);
				break;
			case 1:
				spinvplantname.setVisibility(View.GONE);
				spinvwarehousename.setVisibility(View.GONE);
				etvPOrder.setVisibility(View.VISIBLE);
				break;
			case 2:
				spinvplantname.setVisibility(View.GONE);
				spinvwarehousename.setVisibility(View.VISIBLE);
				etvPOrder.setVisibility(View.GONE);
				
				break;
			default:
				break;
			}
			
			etvPOrder.setText(stPOrder);
		 	etvItemcode.setText(stItemcode);
			etvItemname.setText(stItemname);
			etvLotNo.setText(stLotNo);
//			etvRMARno.setText(stRMARno);
			etvBatchNo.setText(stBatchNo);
			etvReqQty.setText(stReqQty);
			etvissuedQty.setText(stissuedQty);
			
			insertToHash();
			
	}
	
	public boolean CheckTotalBalance(){
		
		float totalstock=0;
		Cursor curs=sdb.query(db.tbl_warehouse_addsock, new String[] { db.key_warehouse_addstock_totalquantity}
		,db.key_warehouse_addstock_itemcode+" = ? "+ "and "  +
                db.key_warehouse_addstock_Stocktype + " = ? ",
	            new String[] {editItemc.getText().toString(),ststocktypeselect}, null, null, null,null);
		if(curs.getCount()>0){				
			while(curs.moveToNext()){
				totalstock=totalstock+Float.parseFloat(curs.getString(0));
			}
		}
		else
		{
			totalstock=0;
		}
		curs=sdb.query(db.tbl_warehouse_issuestock, new String[] { db.key_warehouse_issuestock_IssuedQty}
		,db.key_warehouse_addstock_itemcode+" = ? "+ "and "  +
                db.key_warehouse_addstock_Stocktype + " = ? ",
	            new String[] {editItemc.getText().toString(),ststocktypeselect}, null, null, null,null);
		if(curs.getCount()>0){				
			while(curs.moveToNext()){
				totalstock=totalstock-Float.parseFloat(curs.getString(0));
			}
		}
		
		if(al_itemdetailsarray.size()>0){
			for(int i=0;i<al_itemdetailsarray.size();i++){
				if(al_itemdetailsarray.get(i).get("StockType").toString().equals(ststocktypeselect.toString())&&
						al_itemdetailsarray.get(i).get("ItemCode").toString().equals(editItemc.getText().toString())){
					totalstock=totalstock-Float.parseFloat(al_itemdetailsarray.get(i).get("issuedQty").toString());
				}
			}
		}
		

		
		if(totalstock == 0 || totalstock < Float.parseFloat(etissuedQty.getText().toString())){
			return false;
		}
		
		return true;
	}
	
	public void insertToHash(){

		hm_itemdetails=new HashMap<String, String>();
		hm_itemdetails.put("StockType",ststocktypeselect);
		hm_itemdetails.put("ItemCode",stItemcode);
		hm_itemdetails.put("ItemName",stItemname);
		hm_itemdetails.put("LotNo",stLotNo);
		hm_itemdetails.put("BatchNo",stBatchNo);
//		hm_itemdetails.put("RMARNo",stRMARno);
		hm_itemdetails.put("Plant_No",stplantno);
		hm_itemdetails.put("PO",stPOrder);
		hm_itemdetails.put("WareHouse_No",stwarehouseno);
		hm_itemdetails.put("reqQty",stReqQty);
		hm_itemdetails.put("issuedQty",stissuedQty);
		hm_itemdetails.put("issueto", stissueTo);
		
		al_itemdetailsarray.add(hm_itemdetails);

		
	}

	 public void showToast(int a,String t)
     { 
     	 try {
     		 LayoutInflater inflater = getLayoutInflater();
     		 View layout = inflater.inflate(R.layout.successtoat,
     		                                (ViewGroup) findViewById(R.id.ll_custoast_parent));

     		 ImageView image = (ImageView) layout.findViewById(R.id.ll_custoast_iv);
     		 if(a==1) image.setImageResource(R.drawable.greentick);		 
     		 else image.setImageResource(R.drawable.attentionred);			 
     		 TextView text = (TextView) layout.findViewById(R.id.ll_custoast_msg);
     		 text.setText(t);
     		 Toast toast = new Toast(getApplicationContext());
     		 toast.setGravity(Gravity.FILL_HORIZONTAL|Gravity.BOTTOM | Gravity.CENTER_VERTICAL, 0, 0);
     		 toast.setDuration(Toast.LENGTH_SHORT);
     		 toast.setView(layout);
     		 toast.show();
     	} catch (Exception e1) {
     		// TODO Auto-generated catch block
     		e1.printStackTrace();
     	} 
     }
	
	 public String getnextissueCode()
	 {
		 if(db.getCount(Sqldatabase.tbl_warehouse_issuestock)>0){
			 Cursor csr=db.getdb().query(Sqldatabase.tbl_warehouse_issuestock,
					 new String[]{"MAX("+Sqldatabase.key_warehouse_issuestock_issuecode+")"},
					null,
					 null,
					 null, null, null);
			 if(csr.getCount()>0){
				 csr.moveToFirst();
				 int nextvalue=(Integer.parseInt(csr.getString(0).toString()))+1;
				 return String.valueOf(nextvalue);
			 }
		 }
			 return "1000";
	 }
	 

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		super.onBackPressed();
		Intent i1 =new Intent(getApplicationContext(),Select_Activity.class);
		i1.putExtra("syncstatus",true);
		startActivity(i1);
		finish();
	}
}
