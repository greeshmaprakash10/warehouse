package com.aucupa.warehouse;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ArrayAdapter;
import com.aucupa.warehouse.adapter.ItemAdapter;
import com.aucupa.warehouse.adapter.ListAdapter;

import java.util.ArrayList;
import java.util.List;

public class QaSample extends Activity{
    EditText lotno,quantity,supplier,item_names;
    Button qaButton;
    ImageButton customer;
    //Spinner itemcode;
    ListView list_id,listcode;
    ListAdapter listAdapter;
    ItemAdapter itemAdapter;
    //TextView item_names;
    String uname,supplier_id,cr_id,qa_itemid,label,sync;
    String name, id,lotno1,qastatus,spec,remark,createdtime,qastart,qaupdate,stockid,comment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qa_sample);

        ImageButton _slectitemcode=(ImageButton)findViewById(R.id.qa_selectitem);
        item_names=(EditText) findViewById(R.id.qa_itemcode);
        item_names.requestFocus();
       // itemcode=(Spinner)findViewById(R.id.qa_itemcode);
        lotno=(EditText)findViewById(R.id.qa_lotno);

        quantity=(EditText)findViewById(R.id.qa_quantity);
        supplier=(EditText)findViewById(R.id.qa_edit_customer);
        customer=(ImageButton)findViewById(R.id.qa_select_customer);
        qaButton=(Button)findViewById(R.id.qa_btn);
        uname=getIntent().getStringExtra("user_name");

//        itemSelect();
//        itemcode.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> parent, View view, int position, long l) {
//                label=parent.getItemAtPosition(position).toString();
//
//            }
//
//            @Override
//            public void onNothingSelected(AdapterView<?> adapterView) {
//
//            }
//        });
        _slectitemcode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String item=item_names.getText().toString();
                slectitemcode(item);
            }
        });
        customer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Supplier=supplier.getText().toString();
                selectsupplier(Supplier);
            }
        });
        qaButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(checkValid()==true)
                {
                    String qa_lotno, qa_qty, qa_supplier;
                    qa_lotno = lotno.getText().toString();
                    qa_qty = quantity.getText().toString();
                    qa_supplier = supplier.getText().toString();
                    label=item_names.getText().toString();
                    Sqldatabase db = new Sqldatabase(QaSample.this);
                    Cursor cursor = db.getUOM(qa_lotno);
                    int count = cursor.getCount();
                    if (count > 0)
                    {
                        showToast(0, "Lot Number Already Exist !");
                    }
                    else
                    {
                        Cursor c1 = db.getMobileuser(uname);

                        if (c1.moveToNext())
                        {
                            cr_id = c1.getString(c1.getColumnIndex("enduser_id"));
                        }

                        Cursor c = db.getSupplierId(qa_supplier);
                        if (c.moveToNext()) {
                            supplier_id = c.getString(c.getColumnIndex("supplier_id"));
                        }
                        Cursor c2 = db.getItemCodes(label);
                        if (c2.moveToNext()) {
                            qa_itemid = c2.getString(0);
                        }
                        db.InsertqaDetails(label,qa_itemid, qa_lotno, qa_qty, qa_supplier, supplier_id, uname, cr_id);
                        showToast(1, "QASample Added Successfully ");
                        Intent i = new Intent(QaSample.this, Select_Activity.class);
                        startActivity(i);
                        if (Utils.CheckNet(getApplicationContext())) {
                            new Thread() {
                                public void run() {
                                    //Sqldatabase db = new Sqldatabase(QaSample.this);
                                    // db.getUpdateFromServerQa(getApplicationContext());
                                    Sqldatabase db = new Sqldatabase(getApplicationContext());
                                    SharedPreferences sharedPreferences = getSharedPreferences("sample", MODE_PRIVATE);
                                    String name = sharedPreferences.getString("username", "");
                                    Cursor c1 = db.getMobileuser(name);
                                    if (c1.moveToNext()) {
                                        id = c1.getString(c1.getColumnIndex("enduser_id"));
                                    }
                                    db.postqaDetails(getApplicationContext(), "wh_qa", id);
                                    db.getUpdateFromServerQa(getApplicationContext());

                                }
                            }.start();
                            updateQA();
                        }

                        Toast.makeText(getApplicationContext(), "Success!!", Toast.LENGTH_LONG).show();

                    }
                }
            }
        });
    }
    public void slectitemcode(final String itemname)
    {
        try {
            final Dialog dialogs = new Dialog(QaSample.this);
            dialogs.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialogs.setContentView(R.layout.dialog_select);
            listcode=(ListView)dialogs.findViewById(R.id.list3);
            EditText et_cstomer_name = (EditText) dialogs.findViewById(R.id.et_dialog_customer_name);
            et_cstomer_name.setText(itemname+ "" + et_cstomer_name.getText().toString().trim());
            String searchText = et_cstomer_name.getText().toString();
            Sqldatabase handler = new Sqldatabase(QaSample.this);
            // final Cursor cursors = handler.getdata(searchText);
            final Cursor cursors = handler.getdata(searchText);
            itemAdapter = new ItemAdapter(QaSample.this, cursors);
            listcode.setAdapter(itemAdapter);
            listcode.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    String Supplier = cursors.getString(1);
                    item_names.setText(Supplier);
                    dialogs.hide();

                }

            });
            dialogs.show();
            dialogs.setCancelable(true);

            et_cstomer_name.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after)
                {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {

                }

                @Override
                public void afterTextChanged(Editable s) {
                    EditText et_cstomer_name = (EditText) dialogs.findViewById(R.id.et_dialog_customer_name);
                    String searchText = et_cstomer_name.getText().toString();
                    Sqldatabase handler = new Sqldatabase(QaSample.this);
                    final Cursor cursor = handler.getItemCodes();
                    itemAdapter = new ItemAdapter(QaSample.this, cursor);
                    listcode.setAdapter(itemAdapter);
                    listcode.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            String Supplier = cursor.getString(1);
                            item_names.setText(Supplier);
                            dialogs.hide();

                        }

                    });
                    dialogs.show();
                    dialogs.setCancelable(true);
                }
            });
            dialogs.show();
            dialogs.setCancelable(true);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    public void updateQA()
    {
        Sqldatabase db=new Sqldatabase(QaSample.this);
        Cursor c2=db.getqaupdateDetails();
        int count=c2.getCount();
        for(int i=0;i<count;i++)
        {
            if(c2.moveToNext())
            {
                lotno1=c2.getString(3);
                qastatus=c2.getString(11);
                spec=c2.getString(6);
                remark=c2.getString(7);
                comment=c2.getString(8);
                createdtime=c2.getString(13);
                qastart=c2.getString(9);
                qaupdate=c2.getString(14);
                stockid=c2.getString(12);
                sync="1";
            }
            db.updateqaDetails(lotno1,qastatus,spec,remark,comment,createdtime,qastart,qaupdate,stockid,sync);

        }
    }
    public void selectsupplier(final String Supplier)
    {
        try {
            final Dialog dialog = new Dialog(QaSample.this);
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog.setContentView(R.layout.dialog_customer_select);
            list_id=(ListView)dialog.findViewById(R.id.list1);
            EditText et_cstomer_name = (EditText) dialog.findViewById(R.id.et_dialog_customer_name);
            et_cstomer_name.setText(Supplier+ "" + et_cstomer_name.getText().toString().trim());
            String searchText = et_cstomer_name.getText().toString();
            Sqldatabase handler = new Sqldatabase(QaSample.this);
            final Cursor cursor = handler.getDetails(searchText);
            listAdapter = new com.aucupa.warehouse.adapter.ListAdapter(QaSample.this, cursor);
            list_id.setAdapter(listAdapter);
            list_id.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id)
                {
                    String Supplier = cursor.getString(2);
                    supplier.setText(Supplier);
                    dialog.hide();
                }

            });
            et_cstomer_name.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after)
                {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {

                }

                @Override
                public void afterTextChanged(Editable s) {
                    EditText et_cstomer_name = (EditText) dialog.findViewById(R.id.et_dialog_customer_name);
                    String searchText = et_cstomer_name.getText().toString();

                    Sqldatabase handler = new Sqldatabase(QaSample.this);
                    final Cursor cursor = handler.getDataDetails();
                    listAdapter = new com.aucupa.warehouse.adapter.ListAdapter(QaSample.this, cursor);
                    list_id.setAdapter(listAdapter);
                    list_id.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            String Supplier = cursor.getString(2);
                            supplier.setText(Supplier);
                            dialog.hide();

                        }

                    });
                    dialog.show();
                    dialog.setCancelable(true);
                }
            });
            dialog.show();
            dialog.setCancelable(true);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public boolean checkValid(){
        if(item_names.getText().toString().equals(""))
        {
            Toast.makeText(getApplicationContext(),"Please enter Valid itemCode",Toast.LENGTH_SHORT).show();
            return false;
        }
        if(lotno.getText().toString().equals(""))
        {
            Toast.makeText(getApplicationContext(),"Please enter Valid Lotno",Toast.LENGTH_SHORT).show();
            return false;
        }
        if(quantity.getText().toString().equals(""))
        {
            Toast.makeText(getApplicationContext(),"Please enter Valid Quantity",Toast.LENGTH_SHORT).show();
            return false;
        }
        if(supplier.getText().toString().equals(""))
        {
            Toast.makeText(getApplicationContext(),"Please enter Valid Supplier",Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        Intent i=new Intent(QaSample.this,Select_Activity.class);
        startActivity(i);
    }
//    public void itemSelect()
//    {
//        List<String> categories = new ArrayList<String>();
//        categories.clear();
//        Sqldatabase db=new Sqldatabase(getApplicationContext());
//        Cursor c=db.getItemCodes();
//        if(c.getCount()>0)
//        {
//            categories.add("Item Code");
//            while (c.moveToNext())
//            {
//                categories.add(c.getString(1).toString());
//            }
//        }
//
//        ArrayAdapter dataAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, categories);
//        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//        itemcode.setAdapter(dataAdapter);
//    }
    public void showToast(int a,String t)
    {
        try {
            LayoutInflater inflater = getLayoutInflater();
            View layout = inflater.inflate(R.layout.successtoat,
                    (ViewGroup) findViewById(R.id.ll_custoast_parent));

            ImageView image = (ImageView) layout.findViewById(R.id.ll_custoast_iv);
            if(a==1) image.setImageResource(R.drawable.greentick);
            else image.setImageResource(R.drawable.attentionred);
            TextView text = (TextView) layout.findViewById(R.id.ll_custoast_msg);
            text.setText(t);
            Toast toast = new Toast(getApplicationContext());
            toast.setGravity(Gravity.FILL_HORIZONTAL|Gravity.BOTTOM | Gravity.CENTER_VERTICAL, 0, 0);
            toast.setDuration(Toast.LENGTH_SHORT);
            toast.setView(layout);
            toast.show();
        } catch (Exception e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
    }
}
