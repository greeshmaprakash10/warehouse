package com.aucupa.warehouse.model;

public class DummyModelIssueStock {
	
	private long mId;
	private String mImageURL,issue_id,loc_status;
	private String fletter,itemname,qty;
	
	public DummyModelIssueStock(long id, String imageURL,String letter, String name, String itemqty,String issueid,String loc_status){
		mId = id;
		mImageURL = imageURL; 
		fletter = letter;
		itemname=name;  
		qty = itemqty;
		issue_id=issueid;
		this.loc_status=loc_status;
	}
	public long getId() {
		return mId;
	}

	public void setId(long id) {
		mId = id;
	}


	public String getText() {
		return fletter;
	}

	public void setText(String text) {
		fletter = text;
	}
	public String getItemname() {
		return itemname;
	}

	public void setItemname(String name) {
		itemname = name;
	}
	public String getItemqty() {
		return qty;
	}
	public String getlocstatus() {
		return loc_status;
	}

	public void setItemqty(String iconRes) {
		qty = iconRes;
	}

	@Override
	public String toString() {
		return fletter;
	}
	public String getIssueid() {
		return issue_id;
	}
}
