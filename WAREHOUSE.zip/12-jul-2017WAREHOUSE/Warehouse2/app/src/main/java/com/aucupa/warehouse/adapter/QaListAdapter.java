package com.aucupa.warehouse.adapter;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.TextView;

import com.aucupa.warehouse.R;
import com.aucupa.warehouse.Utils;
import com.aucupa.warehouse.Utilss;

/**
 * Created by Greeshma Prakash on 28-Jun-17.
 */

public class QaListAdapter extends CursorAdapter{
    TextView itemcode,lotno,status,quantity;
    String itemcode1,lotno1,status1,quantity1;

    public QaListAdapter(Context context, Cursor c) {
        super(context, c);
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup viewGroup) {
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        View view = layoutInflater.inflate(R.layout.qa_list,null);
        return view;
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {

        itemcode=(TextView)view.findViewById(R.id.itemcode);
        status=(TextView)view.findViewById(R.id.status);
        lotno=(TextView)view.findViewById(R.id.lot_no);
        quantity=(TextView)view.findViewById(R.id.customer);

        itemcode1=cursor.getString(cursor.getColumnIndex("itemcode"));
        status1=cursor.getString(cursor.getColumnIndex("qa_status"));
        lotno1=cursor.getString(cursor.getColumnIndex("lot_no"));
        quantity1=cursor.getString(cursor.getColumnIndex("Supplier"));

        itemcode.setText(Utilss.trimName(itemcode1,8));
        if(status1.equals("1"))
        {
            status.setText("Accepted");
        }
        else
        {
            status.setText("Pending");
        }
        lotno.setText(lotno1);
        quantity.setText(quantity1);

    }
}
