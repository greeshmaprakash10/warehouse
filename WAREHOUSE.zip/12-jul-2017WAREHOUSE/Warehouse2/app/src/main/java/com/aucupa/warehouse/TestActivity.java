package com.aucupa.warehouse;

import org.json.JSONObject;

import com.aucupa.warehouse.sync.SyncServerRequest;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.widget.TextView;

public class TestActivity extends Activity {

	
	 Context context;
	 SyncServerRequest synctoserverRequest;
	 
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_test);
		
		context=this;
		synctoserverRequest=new SyncServerRequest(context);
		JSONObject job=new JSONObject();
		TextView tv=(TextView)findViewById(R.id.txttestjson);
		tv.setText(job.toString());
	}

}
