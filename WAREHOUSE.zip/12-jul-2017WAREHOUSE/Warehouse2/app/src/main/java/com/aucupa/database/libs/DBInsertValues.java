package com.aucupa.database.libs;

public class DBInsertValues {

	public static class UserInsertValue
	{
		public String uname;
		public String password;
		public UserInsertValue(String uname,String password) {
			this.uname=uname;
			this.password=password;
		}
	}
	
	
}
