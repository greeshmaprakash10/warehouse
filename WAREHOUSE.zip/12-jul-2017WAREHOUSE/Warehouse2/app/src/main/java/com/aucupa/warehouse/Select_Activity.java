package com.aucupa.warehouse;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Settings.Secure;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.aucupa.warehouse.sync.SyncServerRequest;

import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;


public class Select_Activity extends Activity { 
	ProgressDialog conectingDialog;
	Context context;
	 Sqldatabase dbAdapter;
	 SyncServerRequest synctoserverRequest;
	 Utils util; 
	 TextView tvNotificCount,qaNotification;
	 ArrayList<String[]> list =new ArrayList<String []>();
	 ArrayList<HashMap<String, String>> myList = new ArrayList();
	 SimpleDateFormat dateFormat;
	 int i =0;
	 private ProgressDialog syncProgressDialog;
	 DialogUtility dutil;
	 RelativeLayout relativeLayout;
	String name, id,lotno,qastatus,spec,remark,createdtime,qastart,qaupdate,stockid,comment,sync;
		
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.select_activity_temp);
		qaNotification=(TextView)findViewById(R.id.txt_countnotification);
		setNotificationCount();

		context=this;
		synctoserverRequest=new SyncServerRequest(context);
		dutil=new DialogUtility();
		this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date d=new Date();
		
		dbAdapter = new Sqldatabase(this);
		tvNotificCount = (TextView)findViewById(R.id.txtnotification);  
		 try {
			 Utils.setSharedPreferences(getApplicationContext(), "Div_id", Secure.getString(this.getContentResolver(),
					       Secure.ANDROID_ID) );
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		ProgressDialog syncProgressDialog;
		Listnotification();
		setNotificationCount();
		 try {
			new DownloadFilesTask().execute();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public void qaSamplebtnclick (View view){
		String username=getIntent().getStringExtra("username");
		Intent i = new Intent(Select_Activity.this, QaSample.class);
		i.putExtra("user_name",username);
		startActivity(i);
		finish();

	}
	public void AddstockbtnClick (View view){
		
		Intent i = new Intent(Select_Activity.this, Add_Stock.class);
		startActivity(i);
		finish();
		   
	}
	public void qastatusbtnclick (View view){

		Intent i = new Intent(Select_Activity.this, QaStatus.class);
		startActivity(i);
		finish();

	}
	public void Aboutclick(View view){
		Intent i = new Intent(Select_Activity.this, About.class);
		startActivity(i);
		finish();

	}

public void viewissuestock(View view)
{
	Intent i = new Intent(Select_Activity.this, ViewLocation.class);
	startActivity(i);
	finish();
	
}

public void IssuestockClick (View view)
{
	
	Intent i = new Intent(Select_Activity.this, Issuestock.class);
	startActivity(i);
	finish();
	   
}  
public void viewStockClick (View view)
{
	 
	Intent i = new Intent(Select_Activity.this, Qa_viewbook.class);
	startActivity(i);
	finish();

}
	

public void Notificatinbtnclick (View view){

	
	Intent i = new Intent(Select_Activity.this, Viewnotification.class);
	startActivity(i);
	finish();
	   
}

public void viewLocation (View view){ 
	 
	Intent i = new Intent(Select_Activity.this, ViewLiveStock.class);
	startActivity(i);
	finish();
	
	   
}

public void Listnotification(){ 
	 //tvNotificCount.setVisibility(View.INVISIBLE);


	}
		


public void setNotificationCount()
{
	try {
		Sqldatabase db=new Sqldatabase(Select_Activity.this);
		Cursor c=db.getqaDetails();
		String count= String.valueOf(c.getCount());
		qaNotification.setText(String.valueOf(count));
	} catch (Exception e) {
		e.printStackTrace();
	}


}

public void Synoutbtnclick (View view){
	
////////////////////////////////////////////
	
	/**kaja
	 * 
	 */
	if(Utilss.CheckNet(context)){
		showToast(1,"Sync Start..");
//		ProgressDialog dialog=null;
//		try{
//			dialog=new ProgressDialog(context);
//			dialog.setMessage("Syncing...");
//			dialog.show();
//		}catch(Exception e){
//			
//		}
		DialogUtility.DialogManage(((WhApp)getApplication()).context, 1);
        try {
            //synctoserverRequest.syncFromServerItemDetails();
          //  synctoserverRequest.syncFromServerWarehouseDetails();
            //synctoserverRequest.syncFromServerSupplierDetails();
           // synctoserverRequest.syncStockINRequest();
            //	synctoserverRequest.SyncStockOUTRequest();
            synctoserverRequest.synctoLocationINRequest();
            synctoserverRequest.synctoIssueINRequest();
            synctoserverRequest.synctoIssueLocation();
            synctoserverRequest.synctoQA();
        } catch (Exception e) {
            e.printStackTrace();
        }
        if(Utils.CheckNet(getApplicationContext()))
		{
			new Thread()
			{
				public void run()
				{

					Sqldatabase db=new Sqldatabase(Select_Activity.this);
					SharedPreferences sharedPreferences=getSharedPreferences("sample",MODE_PRIVATE);
					name=sharedPreferences.getString("username","");
					Cursor c1=db.getMobileuser(name);
					if(c1.moveToNext()){
						id=c1.getString(c1.getColumnIndex("enduser_id"));
					}
					db.postqaDetails(getApplicationContext(),"wh_qa",id);
					db.postAddStock(getApplicationContext(),"Add_Stock",id);
					db.getUpdateFromServerQa(getApplicationContext());
					db.setWareHouseDetails(getApplication());
				}
			}.start();
			updateQA();
		}
		else{
			Toast.makeText(getApplicationContext(),"No Internet",Toast.LENGTH_SHORT).show();
		}
		DialogUtility.DialogManage(((WhApp)getApplication()).context, 0);
//	 dialog.dismiss();
	//SyncServer.testSync(context);
	
	}
	else{
		showToast(0,"No Internet");
	}

	
//	Intent i=new Intent(Select_Activity.this,TestActivity.class);
//	startActivity(i);
	
	
try {

	/////////kAJA
//syncProgressDialog = ProgressDialog.show(Select_Activity.this, "Updating Database", "Database Syncing..",true);
//
//new Thread(new Runnable() {
//
//@Override
//public void run() {
//
//// TODO Auto-generated method stub
//
//Utils.Dailysync(context,"offlineuser","offlinepass");
//
//runOnUiThread(new Runnable() {
//
//@Override
//public void run() {
//// TODO Auto-generated method stub
//
//syncProgressDialog.dismiss();
//
//}
//});
//}
//}).start();

/////kaja
	
//syncProgressDialog.setMessage("Building database..");
//syncProgressDialog.show();
//syncProgressDialog.setCancelable(false);  
//
////OnPreExecute();
//
//
//
//if(this.syncProgressDialog.isShowing()){
//
//this.syncProgressDialog.dismiss();
//
//}

//	new	Importsync().execute("");
} catch (Exception e) {
// TODO Auto-generated catch block
e.printStackTrace(); 
}     


////////////////////////////////////////
	
//	showConnectingProgreesDialog(context,true,"Syncing with server");
//	try {
//		new	ImportDatabaseServer().execute("");
//	} catch (Exception e) {
//		// TODO Auto-generated catch block
//		e.printStackTrace();
//	}
//	showConnectingProgreesDialog(context,false,"Syncing with server");
}

public class ImportDatabaseServer extends AsyncTask<String, Void, Boolean> {
    private final ProgressDialog conectingDialog = new ProgressDialog(context);

    protected void PreExecute() {
		
    	this.conectingDialog.setMessage("Receving data from the server ");
    	this.conectingDialog.show();
    	this.conectingDialog.setCancelable(false);
    	
	}
    
    protected Boolean doInBackground(final String... args) {
    	
    	if (Utils.CheckNet(context)==true) {
    		
    		
            //Utils.postDB(context);// SERVER IN INSERT
            //Utils.postoutDB(context);// SERVER OUT INSERT
     //     Utils.postDB2(context);
     //     Utils.setWarehouseHistoryTableFromServer(context);//// HISTORY FROM SERVER  
            
		}
    	
    if(this.conectingDialog.isShowing()){
    	
    	this.conectingDialog.dismiss();
    }
       
 	 return true;
    }

 }
public void showConnectingProgreesDialog(Context contect, Boolean show, String Message){

if(show) {
 conectingDialog=new ProgressDialog(contect);
 conectingDialog.setMessage(Message);
 conectingDialog.show();
 conectingDialog.setCancelable(false);

 System.out.println("Shown dialog");
 } else {
conectingDialog.cancel();
 }

     }

@Override
public void onBackPressed() {
	// TODO Auto-generated method stub
	//super.onBackPressed();
	alertforlogout();
}
	public void updateQA()
	{
		Sqldatabase db=new Sqldatabase(Select_Activity.this);
		Cursor c2=db.getqaupdateDetails();
		int count=c2.getCount();
		for(int i=0;i<count;i++)
		{
			if(c2.moveToNext())
			{
				lotno=c2.getString(3);
				qastatus=c2.getString(11);
				spec=c2.getString(6);
				remark=c2.getString(7);
				comment=c2.getString(8);
				createdtime=c2.getString(13);
				qastart=c2.getString(9);
				qaupdate=c2.getString(14);
				stockid=c2.getString(12);
				sync="1";
			}
			db.updateqaDetails(lotno,qastatus,spec,remark,comment,createdtime,qastart,qaupdate,stockid,sync);

		}
	}

public void showToast(int a,String t)
{ 
	 try {
		 LayoutInflater inflater = getLayoutInflater();
		 View layout = inflater.inflate(R.layout.successtoat,
		                                (ViewGroup) findViewById(R.id.ll_custoast_parent));

		 ImageView image = (ImageView) layout.findViewById(R.id.ll_custoast_iv);
		 if(a==1) image.setImageResource(R.drawable.greentick);		 
		 else image.setImageResource(R.drawable.attentionred);			 
		 TextView text = (TextView) layout.findViewById(R.id.ll_custoast_msg);
		 text.setText(t);
		 Toast toast = new Toast(getApplicationContext());
		 toast.setGravity(Gravity.FILL_HORIZONTAL|Gravity.BOTTOM | Gravity.CENTER_VERTICAL, 0, 0);
		 toast.setDuration(Toast.LENGTH_SHORT);
		 toast.setView(layout);
		 toast.show();
	} catch (Exception e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	} 
}

public void alertforlogout()
{
	AlertDialog.Builder builder = new AlertDialog.Builder(this);
	builder.setCancelable(true);
	    builder.setTitle("Logout");
	    builder.setInverseBackgroundForced(true);
	    builder.setMessage("Are you sure to Logout ?");
	    builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
		
		@Override
		public void onClick(DialogInterface dialog, int arg1) {
			// TODO Auto-generated method stub
			
				try {
					dialog.dismiss();
					Intent i=new Intent(Select_Activity.this,Login.class);
					startActivity(i);
					finish();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		
			}	
			    
		
	});
	    builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
		
		@Override
		public void onClick(DialogInterface dialog, int arg1) {
			// TODO Auto-generated method stub
			dialog.dismiss();
			  
		}
	}); 
	
	  // builder.setIcon(R.drawable.exit);
	   builder.show();
} 
private class DownloadFilesTask extends AsyncTask<URL, Integer, Long> {
 

	@Override
	protected Long doInBackground(URL... arg0)
	{
		// TODO Auto-generated method stub
		try
		{
			//Utils.postStockqaTable(getApplicationContext());
//			Utilss.postStockTable(getApplicationContext());
//			//Utils.postIssueStockTable(getApplicationContext());
//			//Utils.postIssueLocatonTable(getApplicationContext());
//			Utils.postLocatonTable(getApplicationContext());
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}


    protected void onProgressUpdate(Integer... progress) {
    }

    protected void onPostExecute(Long result) {
    }
}

}
