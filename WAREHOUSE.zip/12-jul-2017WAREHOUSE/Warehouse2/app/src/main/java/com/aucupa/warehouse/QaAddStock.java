package com.aucupa.warehouse;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.aucupa.warehouse.adapter.ItemAdapter;
import com.aucupa.warehouse.adapter.ListAdapter;

import java.util.ArrayList;

public class QaAddStock extends Activity {
    TextView lotno;
    TextView quantity;
    TextView unit;
    TextView supplier_names;
    TextView item_names;
    TextView ordernum;
    String itemcode1,lotno1,quantity1,supplier_name1,stwarehousecode,ordernum1,supplier_id,ware_id,label,item_id,id,result;
    Spinner spinware,itemcode;
    ArrayList<String> itemcodelist;
    ArrayList<String> warenamecodelist;
    ListView list_id,listcode;
    ListAdapter listAdapter;
    ItemAdapter itemAdapter;
    boolean flag_insert=true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qa_addstock);
        // AddValue();

       // ImageButton _slectsupplier=(ImageButton)findViewById(R.id.ib_bill_acivity_select_customer);
        //ImageButton _slectitemcode=(ImageButton)findViewById(R.id.ib_bill_acivity_item_code);
        // itemcode=(Spinner) findViewById(R.id.qa_edititemcode);
        lotno=(TextView) findViewById(R.id.qa_editlotno);
        lotno.requestFocus();
        quantity=(EditText)findViewById(R.id.qa_edittotalqty);
        unit=(EditText)findViewById(R.id.qa_editunit);
        supplier_names=(TextView) findViewById(R.id.et_bill_acivity_customer_mob);
        item_names=(TextView) findViewById(R.id.et_bill_acivity_item_code);
        ordernum=(EditText)findViewById(R.id.qa_editordernumber);
        spinware=(Spinner)findViewById(R.id.qa_spinware);
        //String passedArg = getIntent().getExtras().getString("item");
        Bundle bundle = getIntent().getExtras();
        String message = bundle.getString("item");
        //itemSelect(message);
        Sqldatabase db=new Sqldatabase(QaAddStock.this);
        Cursor c = db.getSupplierdata(message);
        if (c.moveToNext())
        {
            String supp =c.getString (c.getColumnIndex("supplier_name"));
            supplier_names.setText(supp);
        }

        Cursor cs = db.getItemCodesdatas(message);
        if (cs.moveToNext())
        {
            String supps =cs.getString (cs.getColumnIndex("Item_code"));
            item_names.setText(supps);
        }
        Cursor ce = db.getlotCodesdatas(message);
        if (ce.moveToNext())
        {
            String lots =ce.getString (ce.getColumnIndex("lot_no"));
            String qt=ce.getString(1);
            lotno.setText(lots);
            quantity.setText(qt);
        }
//        Cursor co = db.getquantityCodesdatas(message);
//        if (co.moveToNext())
//        {
//            String quantitys =co.getString (co.getColumnIndex("quantity"));
//            quantity.setText(quantitys);
//        }
//        Cursor cp = db.getunitOMdatas(message);
//        if (cp.moveToNext())
//        {
//            String unitOM =cp.getString (cp.getColumnIndex("Item_Unit"));
//            unit.setText(unitOM);
//        }
//        Cursor ck = db.getunitOMdatas(message);
//        if (ck.moveToNext())
//        {
//            String ordeno =cp.getString (ck.getColumnIndex("Item_Unit"));
//            ordernum.setText(ordeno);
//        }

//        _slectsupplier.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                String supplier=supplier_names.getText().toString();
//                selectsupplier(supplier);
//            }
//        });
//        _slectitemcode.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                String item=item_names.getText().toString();
//                slectitemcode(item);
//            }
//        });
        fillwarehouse();
        spinware.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // TODO Auto-generated method stub
                String select=((TextView)view).getText().toString();
//                int indexstart=select.indexOf("(")+1;
//                int indexend=select.indexOf(")");
//                stwarehousecode=select.substring(indexstart, indexend);
                stwarehousecode=select;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub
                spinware.setSelection(0);
            }
        });
    }
//    public void selectsupplier(final String Supplier)
//    {
//        try {
//            final Dialog dialog = new Dialog(QaAddStock.this);
//            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
//            dialog.setContentView(R.layout.dialog_customer_select);
//            list_id=(ListView)dialog.findViewById(R.id.list1);
//            EditText et_cstomer_name = (EditText) dialog.findViewById(R.id.et_dialog_customer_name);
//            et_cstomer_name.setText(Supplier+ "" + et_cstomer_name.getText().toString().trim());
//            String searchText = et_cstomer_name.getText().toString();
//            Sqldatabase handler = new Sqldatabase(QaAddStock.this);
//            final Cursor cursor = handler.getDetails(searchText);
//            listAdapter = new com.aucupa.warehouse.adapter.ListAdapter(QaAddStock.this, cursor);
//            list_id.setAdapter(listAdapter);
//            list_id.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//                @Override
//                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                    String Supplier = cursor.getString(2);
//                    supplier_names.setText(Supplier);
//                    dialog.hide();
//                }
//
//            });
//            et_cstomer_name.addTextChangedListener(new TextWatcher() {
//                @Override
//                public void beforeTextChanged(CharSequence s, int start, int count, int after)
//                {
//
//                }
//
//                @Override
//                public void onTextChanged(CharSequence s, int start, int before, int count) {
//
//                }
//
//                @Override
//                public void afterTextChanged(Editable s) {
//                    EditText et_cstomer_name = (EditText) dialog.findViewById(R.id.et_dialog_customer_name);
//                    String searchText = et_cstomer_name.getText().toString();
//
//                    Sqldatabase handler = new Sqldatabase(QaAddStock.this);
//                    final Cursor cursor = handler.getDataDetails();
//                    listAdapter = new ListAdapter(QaAddStock.this, cursor);
//                    list_id.setAdapter(listAdapter);
//                    list_id.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//                        @Override
//                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                            String Supplier = cursor.getString(2);
//                            supplier_names.setText(Supplier);
//                            dialog.hide();
//
//                        }
//
//                    });
//                    dialog.show();
//                    dialog.setCancelable(true);
//                }
//            });
//            dialog.show();
//            dialog.setCancelable(true);
//        } catch (Exception e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//    }

//    public void slectitemcode(final String Supplier)
//    {
//        try {
//            final Dialog dialogs = new Dialog(QaAddStock.this);
//            dialogs.requestWindowFeature(Window.FEATURE_NO_TITLE);
//            dialogs.setContentView(R.layout.dialog_select);
//            listcode=(ListView)dialogs.findViewById(R.id.list3);
//            EditText et_cstomer_name = (EditText) dialogs.findViewById(R.id.et_dialog_customer_name);
//            et_cstomer_name.setText(Supplier+ "" + et_cstomer_name.getText().toString().trim());
//            String searchText = et_cstomer_name.getText().toString();
//            Sqldatabase handler = new Sqldatabase(QaAddStock.this);
//            final Cursor cursor = handler.getItemCode(searchText);
//            itemAdapter = new ItemAdapter(QaAddStock.this,cursor);
//            listcode.setAdapter(itemAdapter);
//            listcode.setOnItemClickListener(new AdapterView.OnItemClickListener()
//            {
//                @Override
//                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                    String Supplier = cursor.getString(1);
//                    item_names.setText(Supplier);
//                    dialogs.hide();
//                }
//
//            });
//            et_cstomer_name.addTextChangedListener(new TextWatcher() {
//                @Override
//                public void beforeTextChanged(CharSequence s, int start, int count, int after)
//                {
//
//                }
//
//                @Override
//                public void onTextChanged(CharSequence s, int start, int before, int count) {
//
//                }
//
//                @Override
//                public void afterTextChanged(Editable s) {
//                    EditText et_cstomer_name = (EditText) dialogs.findViewById(R.id.et_dialog_customer_name);
//                    String searchText = et_cstomer_name.getText().toString();
//                    Sqldatabase handler = new Sqldatabase(QaAddStock.this);
//                    final Cursor cursor = handler.getItemCodes();
//                    itemAdapter = new ItemAdapter(QaAddStock.this, cursor);
//                    listcode.setAdapter(itemAdapter);
//                    listcode.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//                        @Override
//                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                            String Supplier = cursor.getString(1);
//                            item_names.setText(Supplier);
//                            dialogs.hide();
//
//                        }
//
//                    });
//                    dialogs.show();
//                    dialogs.setCancelable(true);
//                }
//            });
//            dialogs.show();
//            dialogs.setCancelable(true);
//        } catch (Exception e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//    }



    public void clicktoSave(View view)
    {


        try {

                lotno1=lotno.getText().toString();
                quantity1=quantity.getText().toString();
                supplier_name1=supplier_names.getText().toString();
                ordernum1=ordernum.getText().toString();
                label=item_names.getText().toString();

                Sqldatabase db=new Sqldatabase(QaAddStock.this);
                Cursor cursor = db.getUOMStock(lotno1);
                int count = cursor.getCount();
                if (count > 0)
                {
                    showToast(0, "Lot Number Already Exist !");
                }
                else
                {
                    Cursor c = db.getSupplierId(supplier_name1);
                    if (c.moveToNext())
                    {
                        supplier_id = c.getString(c.getColumnIndex("supplier_id"));
                    }
                    Cursor cs = db.getItemCodes(label);
                    if (cs.moveToNext())
                    {
                        item_id = cs.getString(cs.getColumnIndex("_id"));
                    }
                    Cursor c4 = db.getWarehouseDetails(stwarehousecode);
                    if (c4.moveToNext())
                    {
                        ware_id = c4.getString(c4.getColumnIndex("warehouse_id"));
                    }
                    long results=db.insertStock(item_id,label, lotno1,quantity1,ware_id, supplier_id,ordernum1);
                    if(results > 0)
                    {
                        showToast(1, "QAStock Added Successfully ");
                        Intent i = new Intent(QaAddStock.this, Select_Activity.class);
                        startActivity(i);

                        if (Utilss.CheckNet(getApplicationContext())) {
                            new Thread() {
                                public void run() {
//								SyncServerRequest synctoserverRequest;
//								synctoserverRequest=((WhApp)getApplication()).syncRequest;
//								synctoserverRequest.syncStockINRequest();
                                    Sqldatabase db = new Sqldatabase(getApplicationContext());
                                    SharedPreferences sharedPreferences = getSharedPreferences("sample", MODE_PRIVATE);
                                    String name = sharedPreferences.getString("username", "");
                                    Cursor c1 = db.getMobileuser(name);
                                    if (c1.moveToNext()) {
                                        id = c1.getString(c1.getColumnIndex("enduser_id"));
                                    }
                                    db.postAddStock(getApplicationContext(), "Add_Stock", id);
                                }
                            }.start();
                            db.updateAddSync(lotno1);

                        } else {
                            Toast.makeText(getApplicationContext(), "No internet Connection", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void AddValue()
    {

        try {
            String id=getIntent().getStringExtra("item");
            Sqldatabase db=new Sqldatabase(getApplicationContext());
            Cursor c=db.getqaDetails1(id);
            if(c.moveToNext())
            {
                itemcode1=c.getString(3).toString();
                lotno1=c.getString(4).toString();
                supplier_name1=c.getString(6).toString();
            }
            lotno.setText(lotno1);
            supplier_names.setText(supplier_name1);
        } catch (Exception e) {
            e.printStackTrace();
        }


    }
    public void fillwarehouse(){
        warenamecodelist=new ArrayList<>();
        warenamecodelist.clear();
        Sqldatabase db=new Sqldatabase(getApplicationContext());
        Cursor cc=db.getWarehouseDetails();
        if(cc.getCount()>0)
        {
            warenamecodelist.add("--Select--");
            while(cc.moveToNext())
            {
                warenamecodelist.add(cc.getString(2).toString());
            }
        }
        ArrayAdapter<String> adapter =new ArrayAdapter<String>(getApplicationContext(),R.layout.autolistview,warenamecodelist);
        spinware.setAdapter(adapter);
    }


    @Override
    public void onBackPressed() {
        Intent i=new Intent(QaAddStock.this,Select_Activity.class);
        startActivity(i);
    }
    public void showToast(int a,String t)
    {
        try {
            LayoutInflater inflater = getLayoutInflater();
            View layout = inflater.inflate(R.layout.successtoat,
                    (ViewGroup) findViewById(R.id.ll_custoast_parent));

            ImageView image = (ImageView) layout.findViewById(R.id.ll_custoast_iv);
            if(a==1) image.setImageResource(R.drawable.greentick);
            else image.setImageResource(R.drawable.attentionred);
            TextView text = (TextView) layout.findViewById(R.id.ll_custoast_msg);
            text.setText(t);
            Toast toast = new Toast(getApplicationContext());
            toast.setGravity(Gravity.FILL_HORIZONTAL|Gravity.BOTTOM | Gravity.CENTER_VERTICAL, 0, 0);
            toast.setDuration(Toast.LENGTH_SHORT);
            toast.setView(layout);
            toast.show();
        } catch (Exception e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
    }
}
