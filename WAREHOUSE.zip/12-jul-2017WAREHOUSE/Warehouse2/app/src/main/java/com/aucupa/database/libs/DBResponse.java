package com.aucupa.database.libs;

import java.util.ArrayList;

import com.aucupa.database.libs.DBResponseData.UserResponseData;

public class DBResponse {

	public static class Count
	{
		public int count;
	}
	public static class UserResponse 
	{
		public ArrayList<UserResponseData> data;
	}
}
