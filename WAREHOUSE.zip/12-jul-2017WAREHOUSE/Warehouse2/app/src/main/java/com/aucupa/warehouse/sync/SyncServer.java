package com.aucupa.warehouse.sync;

import com.aucupa.warehouse.DialogUtility;
import com.aucupa.warehouse.Sqldatabase;
import com.aucupa.warehouse.Utils;
import com.aucupa.warehouse.WhApp;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

import android.content.ContentValues;
import android.content.Context;
import android.util.Log;
import android.widget.Toast;

public class SyncServer {
	
	/*** use return object of Response */
	public static String start_sync="";
	
	private static SyncResponseDatatypes.SyncToServerResponse response;
	private static SyncResponseDatatypes.SyncToServerResponse responseqa;
	private static SyncResponseDatatypes.SyncToServerResponse responsestocklocation;
	private static SyncResponseDatatypes.SyncToServerResponse responseissue;
	private static SyncResponseDatatypes.SyncToServerResponse responseissuelocation;
	private static SyncResponseDatatypes.SyncFromServerStockInResponse stockinResponseFromserver;
	private static SyncResponseDatatypes.SyncFromServerStockOutResponse stockoutResponseFromserver;
	private static SyncResponseDatatypes.SyncFromServerLocationInResponse locationinResponseFromserver;
	private static SyncResponseDatatypes.SyncFromServerLocationOutResponse locationoutResponseFromserver;
	private static SyncResponseDatatypes.SyncFromServerItemDetailsResponse masterdata_itemdetails;
	private static SyncResponseDatatypes.SyncFromServerWareDetailsResponse masterdata_waredetails;
	private static SyncResponseDatatypes.SyncFromServerSupplierDetailsResponse masterdata_supplierdetails;
	private final static DialogUtility dutil=new DialogUtility();
	
	public static void SyncToServerStock(final Context context,String Url,JsonObject params)
	{
		final Sqldatabase db=new Sqldatabase(context);
		final  SyncServerRequest synctoserverRequest=new SyncServerRequest(context);
		final Context con=context;
		response=new SyncResponseDatatypes.SyncToServerResponse();
		try {
	       	FutureCallback<JsonObject> futureCallBack=new FutureCallback<JsonObject>() {
	       		
		            @Override
		            public void onCompleted(Exception e, JsonObject result) {
		            	if(e==null)
		            	{
		            		if(result!=null)
		            		{
		            			try
		            			{
		            				response=new Gson().fromJson(result, SyncResponseDatatypes.SyncToServerResponse.class);
		            			}
		            			catch(Exception ee)
		            			{
		            				Log.e("Result Error  :", ee.toString());
		            			}
		            		}
		            		Log.i("JSON sync :",result.toString());
		        			System.out.print("JSON Sync RESULT : " +result.toString());
		        			
		        			if(response.isSuccess()){
		        				if(response.data.size()>0){ 
		        					for(int i=0;i<response.data.size();i++){
		        						ContentValues cv=new ContentValues(); 
		        						cv.put(db.key_warehouse_server_stockID, response.data.get(i).Serverid);
				        				cv.put(db.key_warehouse_syncstatus,"1");
				        				db.getdb().update(db.tbl_warehouse_addsock,cv,
				        						db.key_warehouse_addstock_stockid+" = ? ",
				        						new String[]{Integer.toString(Integer.parseInt(response.data.get(i).Clientid))});
				        				cv.put(db.key_warehouse_server_stockID, response.data.get(i).Serverid);
				        				cv.put(db.key_warehouse_syncstatus,"0");
				        				db.getdb().update(db.tbl_warehouse_updatelocation,cv,
				        						db.key_warehouse_updatelocation_stockid+" = ? ",
				        						new String[]{response.data.get(i).Clientid});
				        				cv.put(db.key_warehouse_server_stockID, response.data.get(i).Serverid);
				        				cv.put(db.key_warehouse_syncstatus,"0");
				        				db.getdb().update(db.tbl_Stock_QAChecklist,cv,
				        						db.key_Stock_QAChecklist_stockid+" = ? ",
				        						new String[]{response.data.get(i).Clientid});
		        					}
		        					synctoserverRequest.synctoLocationINRequest();
		        					synctoserverRequest.synctoQA();		        				}
		        			}else{
		        				if((response.isActive())){
		        					try {
										Toast.makeText(context, response.status_msg,Toast.LENGTH_SHORT).show();
									} catch (Exception e1) {
										// TODO Auto-generated catch block
										e1.printStackTrace();
									}
		        				}
		        			}
		            		
		            	}
		            }
		        };
		        JsonArray ja=new JsonArray();
		        ja.add(params);
				 Ion.with(context)
	                .load(Url)
	                .setJsonArrayBody(ja)
	                .asJsonObject()
	                .setCallback(futureCallBack);
				
//				Log.i("sssssssssssssssttttttttttttt", String.valueOf(status));
			
	      
	} catch (Exception e) {
		// TODO: handle exception
		System.out.print(e.toString());
		
	}
		
	}
	
	public static void SyncToQA(final Context context,String Url,JsonObject params)
	{
		final Sqldatabase db=new Sqldatabase(context);
		final  SyncServerRequest synctoserverRequest=new SyncServerRequest(context);
		final Context con=context;
		responseqa=new SyncResponseDatatypes.SyncToServerResponse();
		try {
	       	FutureCallback<JsonObject> futureCallBack=new FutureCallback<JsonObject>() {
	       		
		            @Override
		            public void onCompleted(Exception e, JsonObject result) {
		            	if(e==null)
		            	{
		            		if(result!=null)
		            		{
		            			try
		            			{
		            				responseqa=new Gson().fromJson(result, SyncResponseDatatypes.SyncToServerResponse.class);
		            			}
		            			catch(Exception ee)
		            			{
		            				Log.e("Result Error  :", ee.toString());
		            			}
		            		}
		            		Log.i("JSON sync :",result.toString());
		        			System.out.print("JSON Sync RESULT : " +result.toString());
		        			
		        			if(response.isSuccess()){
		        				ContentValues cv=new  ContentValues();
				        				cv.put(db.key_warehouse_syncstatus,"1");
				        				db.getdb().update(db.tbl_Stock_QAChecklist,cv,null,null);
		        			}else{
		        				if((response.isActive())){
		        					try {
										Toast.makeText(context, response.status_msg,Toast.LENGTH_SHORT).show();
									} catch (Exception e1) {
										// TODO Auto-generated catch block
										e1.printStackTrace();
									}
		        				}
		        			}
		            		
		            	}
		            }
		        };
		        JsonArray ja=new JsonArray();
		        ja.add(params);
				 Ion.with(context)
	                .load(Url)
	                .setJsonArrayBody(ja)
	                .asJsonObject()
	                .setCallback(futureCallBack);
			
	      
	} catch (Exception e) {
		// TODO: handle exception
		System.out.print(e.toString());
		
	}
		
	}
	
	public static void SyncFromStockInServer(Context context,String Url,JsonObject params)
	{
		stockinResponseFromserver=new SyncResponseDatatypes.SyncFromServerStockInResponse();
		try {
	       	FutureCallback<JsonObject> futureCallBack=new FutureCallback<JsonObject>() {
	       		
		            @Override
		            public void onCompleted(Exception e, JsonObject result) {
		            	if(e==null)
		            	{
		            		if(result!=null)
		            		{
		            			try
		            			{
		            				stockinResponseFromserver=new Gson().fromJson(result, SyncResponseDatatypes.SyncFromServerStockInResponse.class);
		            			}
		            			catch(Exception ee)
		            			{
		            				Log.e("Result Error  :", ee.toString());
		            			}
		            		}
		            	}
		            }
		        };
		        
				 Ion.with(context)
	                .load(Url)
	                .setJsonObjectBody(params)
	                .asJsonObject()
	                .setCallback(futureCallBack);
			
	      
	} catch (Exception e) {
		// TODO: handle exception
		System.out.print(e.toString());
		
	}
		
	}
	
	public static void SyncFromStockOutServer(Context context,String Url,JsonObject params)
	{
		stockoutResponseFromserver=new SyncResponseDatatypes.SyncFromServerStockOutResponse();
		try {
	       	FutureCallback<JsonObject> futureCallBack=new FutureCallback<JsonObject>() {
	       		
		            @Override
		            public void onCompleted(Exception e, JsonObject result) {
		            	if(e==null)
		            	{
		            		if(result!=null)
		            		{
		            			try
		            			{
		            				stockoutResponseFromserver=new Gson().fromJson(result, SyncResponseDatatypes.SyncFromServerStockOutResponse.class);
		            			}
		            			catch(Exception ee)
		            			{
		            				Log.e("Result Error  :", ee.toString());
		            			}
		            		}
		            		
		            	}
		            }
		        };
		        
				 Ion.with(context)
	                .load(Url)
	                .setJsonObjectBody(params)
	                .asJsonObject()
	                .setCallback(futureCallBack);
			
	      
	} catch (Exception e) {
		// TODO: handle exception
		System.out.print(e.toString());
		
	}
		
	}
	
	public static void SyncFromLocationInServer(Context context,String Url,JsonObject params)
	{
		locationinResponseFromserver=new SyncResponseDatatypes.SyncFromServerLocationInResponse();
		try {
	       	FutureCallback<JsonObject> futureCallBack=new FutureCallback<JsonObject>() {
	       		
		            @Override
		            public void onCompleted(Exception e, JsonObject result) {
		            	if(e==null)
		            	{
		            		if(result!=null)
		            		{
		            			try
		            			{
		            				locationinResponseFromserver=new Gson().fromJson(result, SyncResponseDatatypes.SyncFromServerLocationInResponse.class);
		            			}
		            			catch(Exception ee)
		            			{
		            				Log.e("Result Error  :", ee.toString());
		            			}
		            		}
		            		
		            		Log.i("JSON sync :",result.toString());
		        			System.out.print("JSON Sync RESULT : " +result.toString());
		            	}
		            }
		        };
		        
				 Ion.with(context)
	                .load(Url)
	                .setJsonObjectBody(params)
	                .asJsonObject()
	                .setCallback(futureCallBack);
			
	      
	} catch (Exception e) {
		// TODO: handle exception
		System.out.print(e.toString());
		
	}
	}
	
	public static void SyncFromLocationOutServer(Context context,String Url,JsonObject params)
	{
		locationoutResponseFromserver=new SyncResponseDatatypes.SyncFromServerLocationOutResponse();
		try {
	       	FutureCallback<JsonObject> futureCallBack=new FutureCallback<JsonObject>() {
	       		
		            @Override
		            public void onCompleted(Exception e, JsonObject result) {
		            	if(e==null)
		            	{
		            		if(result!=null)
		            		{
		            			try
		            			{
		            				locationoutResponseFromserver=new Gson().fromJson(result, SyncResponseDatatypes.SyncFromServerLocationOutResponse.class);
		            			}
		            			catch(Exception ee)
		            			{
		            				Log.e("Result Error  :", ee.toString());
		            			}
		            		}
		            		
		            	}
		            }
		        };
		        
				 Ion.with(context)
	                .load(Url)
	                .setJsonObjectBody(params)
	                .asJsonObject()
	                .setCallback(futureCallBack);
			
	      
	} catch (Exception e) {
		// TODO: handle exception
		System.out.print(e.toString());
		
	}
	}
	
	public static void SyncFromServerItemDetails(Context context,String Url,JsonObject params)
	{
		start_sync=Utils.getSystemTimeStamp();
		final Context con=context;
		final Sqldatabase db=new Sqldatabase(context);
		masterdata_itemdetails=new SyncResponseDatatypes.SyncFromServerItemDetailsResponse();
		try {
	       	FutureCallback<JsonObject> futureCallBack=new FutureCallback<JsonObject>() {
	       		
		            @Override
		            public void onCompleted(Exception e, JsonObject result) {
		            	if(e==null)
		            	{
		            		if(result!=null)
		            		{
		            			try
		            			{
		            				masterdata_itemdetails=new Gson().fromJson(result, SyncResponseDatatypes.SyncFromServerItemDetailsResponse.class);
		            			}
		            			catch(Exception ee)
		            			{
		            				Log.e("Result Error  :", ee.toString());
		            			}
		            		}
		            		Log.i("JSON sync :",result.toString());
		        			System.out.print("JSON Sync RESULT : " +result.toString());
		        			
		        			if(masterdata_itemdetails.isSuccess()){
		        				for(int i=0;i<masterdata_itemdetails.data.size();i++){
		        					ContentValues cv=new ContentValues();
									cv.put(Sqldatabase.key_warehouse_item_itemid, masterdata_itemdetails.data.get(i).id);
		        					cv.put(Sqldatabase.key_warehouse_item_itemcode, masterdata_itemdetails.data.get(i).itemcode);
		        					cv.put(Sqldatabase.key_warehouse_item_itemname, masterdata_itemdetails.data.get(i).itemname);
		        					cv.put(Sqldatabase.key_warehouse_item_itemtype, masterdata_itemdetails.data.get(i).itemtype);
		        					cv.put(Sqldatabase.key_warehouse_item_itemUnit, masterdata_itemdetails.data.get(i).itemunit);
		        					cv.put(Sqldatabase.key_warehouse_item_category, masterdata_itemdetails.data.get(i).categoryname);
		        					cv.put(Sqldatabase.key_warehouse_item_subcategory, masterdata_itemdetails.data.get(i).subCategoryname);
		        					if(db.getdb().query(Sqldatabase.tbl_Items,
		        							null,Sqldatabase.key_warehouse_item_itemid+" = ? ",
		        							new String[]{masterdata_itemdetails.data.get(i).id}, null, null, null).getCount()>0){
		        						if(db.getdb().update(Sqldatabase.tbl_Items, cv,Sqldatabase.key_warehouse_item_itemid+" = ? ",
			        							new String[]{masterdata_itemdetails.data.get(i).itemcode})>0){
			        						Log.i("Item sync db update : ","done");
			        					}
		        					}
		        					else
		        					{
		        						if(db.sqlins(Sqldatabase.tbl_Items, cv)>0){
			        						Log.i("Item sync db insert : ","done");
			        					}
		        					}
		        					
		        					ContentValues cvsynctime=new ContentValues();
		        					cvsynctime.put("value",start_sync);
		        					db.getdb().update(db.tbl_Config,cvsynctime,"name = ? ",new String[]{db.tbl_Items});
		        				}
		        			}else{
			        			Log.i("Item sync error message : ",masterdata_itemdetails.status_msg);
			        			if(masterdata_waredetails.isActive()){
			        				Toast.makeText(con, masterdata_itemdetails.status_msg,
			        						Toast.LENGTH_SHORT).show();
			        				}
			        			}
		        			}
		            }
		        };
		        JsonArray ja=new JsonArray();
		        ja.add(params);
				 Ion.with(context)
	                .load(Url)
	                .setJsonArrayBody(ja)
	                .asJsonObject()
	                .setCallback(futureCallBack);
			
	      
	} catch (Exception e) {
		// TODO: handle exception
		System.out.print(e.toString());
		
	}
	}
	
//	public static void SyncFromServerWareDetails(Context context,String Url,JsonObject params)
//	{
//		start_sync=Utils.getSystemTimeStamp();
//		final Sqldatabase db=new Sqldatabase(context);
//		final Context con=context;
//		masterdata_waredetails=new SyncResponseDatatypes.SyncFromServerWareDetailsResponse();
//		try {
//	       	FutureCallback<JsonObject> futureCallBack=new FutureCallback<JsonObject>() {
//
//		            @Override
//		            public void onCompleted(Exception e, JsonObject result) {
//		            	if(e==null)
//		            	{
//		            		if(result!=null)
//		            		{
//		            			try
//		            			{
//		            				masterdata_waredetails=new Gson().fromJson(result, SyncResponseDatatypes.SyncFromServerWareDetailsResponse.class);
//		            			}
//		            			catch(Exception ee)
//		            			{
//		            				Log.e("Result Error  :", ee.toString());
//		            			}
//		            		}
//		            		Log.i("JSON sync :",result.toString());
//		        			System.out.print("JSON Sync RESULT : " +result.toString());
//
//		        			if(masterdata_waredetails.isSuccess()){
//		        				for(int i=0;i<masterdata_waredetails.data.size();i++){
//		        					ContentValues cv=new ContentValues();
//		        					//cv.put(Sqldatabase.key_warehouse_no_id, masterdata_waredetails.data.get(i).id);
//									cv.put(Sqldatabase.key_warehouse_no_ware_id, masterdata_waredetails.data.get(i).id);
//		        					cv.put(Sqldatabase.key_warehouse_no_plantno, masterdata_waredetails.data.get(i).warehouse_no);
//		        					if(db.getdb().query(Sqldatabase.tbl_warehouse_no,
//		        							null,Sqldatabase.key_warehouse_no_id+" = ? ",
//		        							new String[]{masterdata_waredetails.data.get(i).id}, null, null, null).getCount()>0){
//		        						if(db.getdb().update(Sqldatabase.tbl_warehouse_no, cv,Sqldatabase.key_warehouse_no_id+" = ? ",
//			        							new String[]{masterdata_waredetails.data.get(i).id})>0){
//			        						Log.i("Plants sync db update : ","done");
//			        					}
//		        					}
//		        					else
//		        					{
//		        						if(db.sqlins(Sqldatabase.tbl_warehouse_no, cv)>0){
//			        						Log.i("Plant sync db insert : ","done");
//			        					}
//		        					}
//		        				}
//		        				ContentValues cvsynctime=new ContentValues();
//	        					cvsynctime.put("value",start_sync);
//	        					db.getdb().update(db.tbl_Config,cvsynctime,"name = ? ",new String[]{db.tbl_warehouse_no});
//
//		        			}else{
//		        				Log.i("Plant sync error message : ",masterdata_waredetails.status_msg);
//		        				if(masterdata_waredetails.isActive()){
//		        					Toast.makeText(con, masterdata_waredetails.status_msg,
//		        							Toast.LENGTH_SHORT).show();
//		        				}
//		        			}
//		            	}
//		            }
//		        };
//		        JsonArray ja=new JsonArray();
//		        ja.add(params);
//				 Ion.with(context)
//	                .load(Url)
//	                .setJsonArrayBody(ja)
//	                .asJsonObject()
//	                .setCallback(futureCallBack);
//
//
//	} catch (Exception e) {
//		// TODO: handle exception
//		System.out.print(e.toString());
//
//	}
//	}
	public static void SyncFromServerSupplierDetails(Context context,String Url,JsonObject params)
	{
		start_sync=Utils.getSystemTimeStamp();
		final Sqldatabase db=new Sqldatabase(context);
		final Context con=context;
		masterdata_supplierdetails=new SyncResponseDatatypes.SyncFromServerSupplierDetailsResponse();
		try {
	       	FutureCallback<JsonObject> futureCallBack=new FutureCallback<JsonObject>() {
	       		
		            @Override
		            public void onCompleted(Exception e, JsonObject result) {
		            	if(e==null)
		            	{
		            		if(result!=null)
		            		{
		            			try
		            			{
		            				masterdata_supplierdetails=new Gson().fromJson(result, SyncResponseDatatypes.SyncFromServerSupplierDetailsResponse.class);
		            			}
		            			catch(Exception ee)
		            			{
		            				Log.e("Result Error  :", ee.toString());
		            			}
		            		}
		            		Log.i("JSON sync :",result.toString());
		        			System.out.print("JSON Sync RESULT : " +result.toString());
		        			
		        			if(masterdata_supplierdetails.isSuccess()){
		        				for(int i=0;i<masterdata_supplierdetails.data.size();i++){
		        					ContentValues cv=new ContentValues();
		        					cv.put(Sqldatabase.key_supplier_code, masterdata_supplierdetails.data.get(i).suppliercode);
		        					cv.put(Sqldatabase.key_supplier_name, masterdata_supplierdetails.data.get(i).suppliername);
		        					if(db.getdb().query(Sqldatabase.tbl_suppliers,
		        							null,Sqldatabase.key_supplier_code+" = ? ",
		        							new String[]{masterdata_supplierdetails.data.get(i).suppliercode}, null, null, null).getCount()>0){
		        						if(db.getdb().update(Sqldatabase.tbl_suppliers, cv,Sqldatabase.key_supplier_code+" = ? ",
			        							new String[]{masterdata_supplierdetails.data.get(i).suppliercode})>0){
			        						Log.i("Supplier sync db update : ","done");
			        					}
		        					}
		        					else
		        					{
		        						if(db.sqlins(Sqldatabase.tbl_suppliers, cv)>0){
			        						Log.i("Supplier sync db insert : ","done");
			        					}
		        					}
		        				}
		        				ContentValues cvsynctime=new ContentValues();
	        					cvsynctime.put("value",start_sync);
	        					db.getdb().update(db.tbl_Config,cvsynctime,"name = ? ",new String[]{db.tbl_suppliers});
	        					
		        			}
							else{
		        				Log.i("Supplier sync error message : ",masterdata_supplierdetails.status_msg);
		        				if((masterdata_waredetails.isActive())){
		        					Toast.makeText(con, masterdata_supplierdetails.status_msg,
		        							Toast.LENGTH_SHORT).show();
		        				}
		        			}
		            	}
		            }
		        };
		        JsonArray ja=new JsonArray();
		        ja.add(params);
				 Ion.with(context)
	                .load(Url)
	                .setJsonArrayBody(ja)
	                .asJsonObject()
	                .setCallback(futureCallBack);
			
	      
	} catch (Exception e) {
		// TODO: handle exception
		System.out.print(e.toString());
		
	}
		
	}
	
	
	///////test start 
	public static void testSync(final Context context)
	{
		 JsonObject jobj=new JsonObject();
	        JsonArray jarray=new JsonArray();
	        jobj.addProperty("table", "MobileUsers");
	        jarray.add(jobj);
	        
	Toast.makeText(context, "in sync",Toast.LENGTH_SHORT ).show();
		try {
	       	FutureCallback<JsonArray> futureCallBack=new FutureCallback<JsonArray>() {
		            @Override
		            public void onCompleted(Exception e, JsonArray result) {
		            	if(e==null)
		            	{
		            		if(result!=null)
		            		{
		            			Toast.makeText(context, "has response",Toast.LENGTH_SHORT ).show();
		            			Log.i("AFTER SYNC : ","");
		            			
		            			try
		            			{
		            				System.out.print("JSON RESULT : ");
		            					
		            				Toast.makeText(context, "response  "+result.toString(),Toast.LENGTH_SHORT ).show();
		            			}
		            			catch(Exception ee)
		            			{
		            				Log.e("Result Error  :", ee.toString());
		            			}
		            		}
		            		
		            	}
		            }
		        };
		        
				 Ion.with(context)
	                .load("http://aucupa.com/warehouse/sync_out")
	                .setJsonArrayBody(jarray)
	                .asJsonArray()
	                .setCallback(futureCallBack);
			
	      
	} catch (Exception e) {
		// TODO: handle exception
		System.out.print(e.toString());
		
	}
	}
	public static void SyncToServerLocation(final Context context,String Url,JsonObject params)
	{
		final Sqldatabase db=new Sqldatabase(context);
		final Context con=context;
		responsestocklocation=new SyncResponseDatatypes.SyncToServerResponse();
		try {
	       	FutureCallback<JsonObject> futureCallBack=new FutureCallback<JsonObject>() {
	       		
		            @Override
		            public void onCompleted(Exception e, JsonObject result) {
		            	if(e==null)
		            	{
		            		if(result!=null) 
		            		{
		            			try
		            			{
		            				responsestocklocation=new Gson().fromJson(result, SyncResponseDatatypes.SyncToServerResponse.class);
		            			}
		            			catch(Exception ee)
		            			{
		            				Log.e("Result Error  :", ee.toString());
		            			}
		            		}
		            		Log.i("JSON sync :",result.toString());
		        			System.out.print("JSON Sync RESULT : " +result.toString());
		        			
		        			if(responsestocklocation.isSuccess()){
		        				try {
									//Toast.makeText(context, response.status_msg,Toast.LENGTH_SHORT).show();
									final Sqldatabase db=new Sqldatabase(context);
									ContentValues cvupdate=new ContentValues();
									cvupdate.put(db.key_warehouse_syncstatus, "1");
									db.getdb().update(db.tbl_warehouse_updatelocation,cvupdate,
											db.key_warehouse_syncstatus+"=?",new String[]{"0"});
								} catch (Exception e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}
		        				
		        				
		        			}else{
		        				if((responsestocklocation.isActive())){
		        					Toast.makeText(context, responsestocklocation.status_msg,Toast.LENGTH_SHORT).show();
		        				}
		        			}
		            		
		            	}
		            }
		        };
		        JsonArray ja=new JsonArray();
		        ja.add(params);
				 Ion.with(context)
	                .load(Url)
	                .setJsonArrayBody(ja)
	                .asJsonObject()
	                .setCallback(futureCallBack);
			
	      
	} catch (Exception e) {
		// TODO: handle exception
		System.out.print(e.toString());
		
	}
		
	}
	
	public static void SyncToServerIssue(final Context context,String Url,JsonObject params)
	{
		final Sqldatabase db=new Sqldatabase(context);
		final Context con=context;
		final  SyncServerRequest synctoserverRequest=new SyncServerRequest(context);
		responseissue=new SyncResponseDatatypes.SyncToServerResponse();
		try {
	       	FutureCallback<JsonObject> futureCallBack=new FutureCallback<JsonObject>() {
	       		
		            @Override
		            public void onCompleted(Exception e, JsonObject result) {
		            	if(e==null)
		            	{
		            		if(result!=null)
		            		{ 
		            			try
		            			{
		            				responseissue=new Gson().fromJson(result, SyncResponseDatatypes.SyncToServerResponse.class);
		            			}
		            			catch(Exception ee)
		            			{
		            				Log.e("Result Error  :", ee.toString());
		            			}
		            		} 
		            		Log.i("JSON sync :",result.toString()); 
		        			System.out.print("JSON Sync RESULT : " +result.toString());
		        			 
		        			if(responseissue.isSuccess()){
		        				if(responseissue.data.size()>0){
		        					for(int i=0;i<responseissue.data.size();i++){
		        						try {
											ContentValues cv=new ContentValues();
											cv.put(db.key_warehouse_server_stockissueID, responseissue.data.get(i).Serverid);
											cv.put(db.key_warehouse_syncstatus,"1");
											db.getdb().update(db.tbl_warehouse_issuestock,cv,
													db.key_warehouse_issuestock_issueid+" = ? ",
													new String[]{Integer.toString(Integer.parseInt(responseissue.data.get(i).Clientid))});
											cv.put(db.key_warehouse_server_stockissueID, responseissue.data.get(i).Serverid);
											cv.put(db.key_warehouse_syncstatus,"0");
											db.getdb().update(db.tbl_warehouse_update_issue_location,cv,
													db.key_warehouse_issuestockupdatelocation_issueid+" = ? ",
													new String[]{responseissue.data.get(i).Clientid});
										} catch (Exception e1) {
											// TODO Auto-generated catch block
											e1.printStackTrace();
										}
		        					}
		        				}
		        				synctoserverRequest.synctoIssueLocation();
		        			}else{
		        				if((responseissue.isActive())){
		        					try {
										Toast.makeText(context, responseissue.status_msg,Toast.LENGTH_SHORT).show();
									} catch (Exception e1) {
										// TODO Auto-generated catch block
										e1.printStackTrace();
									}
		        				}
		        			}
		            		
		            	}
		            }
		        };
		        JsonArray ja=new JsonArray();
		        ja.add(params);
				 Ion.with(context)
	                .load(Url)
	                .setJsonArrayBody(ja)
	                .asJsonObject()
	                .setCallback(futureCallBack);
			
	      
		} catch (Exception e) {
			// TODO: handle exception
			System.out.print(e.toString());
			
		}
		
	}
	public static void SyncToServerIssueLocation(final Context context,String Url,JsonObject params)
	{
		final Sqldatabase db=new Sqldatabase(context);
		final Context con=context;
		responseissuelocation=new SyncResponseDatatypes.SyncToServerResponse();
		try {
	       	FutureCallback<JsonObject> futureCallBack=new FutureCallback<JsonObject>() {
	       		
		            @Override
		            public void onCompleted(Exception e, JsonObject result) {
		            	if(e==null)
		            	{
		            		if(result!=null)
		            		{ 
		            			try
		            			{
		            				responseissuelocation=new Gson().fromJson(result, SyncResponseDatatypes.SyncToServerResponse.class);
		            			}
		            			catch(Exception ee)
		            			{
		            				Log.e("Result Error  :", ee.toString());
		            			}
		            		} 
		            		Log.i("JSON sync :",result.toString()); 
		        			System.out.print("JSON Sync RESULT : " +result.toString());
		        			 
		        			if(responseissuelocation.isSuccess()){ 				
		        					try {
											final Sqldatabase db=new Sqldatabase(context);
											ContentValues cvupdate=new ContentValues();
											cvupdate.put(db.key_warehouse_syncstatus, "1");
											db.getdb().update(db.tbl_warehouse_update_issue_location,cvupdate,
													db.key_warehouse_syncstatus+"=?",new String[]{"0"});
										} catch (Exception e1) {
											// TODO Auto-generated catch block
											e1.printStackTrace();
										}
		        								         				
		        			}else{
		        				if((responseissuelocation.isActive())){
		        					try {
										Toast.makeText(context, responseissuelocation.status_msg,Toast.LENGTH_SHORT).show();
									} catch (Exception e1) {
										// TODO Auto-generated catch block
										e1.printStackTrace();
									}
		        				}
		        			}
		            		
		            	}
		            }
		        };
		        JsonArray ja=new JsonArray();
		        ja.add(params);
				 Ion.with(context)
	                .load(Url)
	                .setJsonArrayBody(ja)
	                .asJsonObject()
	                .setCallback(futureCallBack);
			
	      
		} catch (Exception e) {
			// TODO: handle exception
			System.out.print(e.toString());
			
		}
		
	}
	///test end//////
}
