package com.aucupa.warehouse.adapter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import com.aucupa.warehouse.R;
import com.aucupa.warehouse.ViewIssueStock;
import com.aucupa.warehouse.Viewstock;
import com.aucupa.warehouse.model.DummyModelIssueStock;
import com.nhaarman.listviewanimations.itemmanipulation.swipedismiss.OnDismissCallback;
import com.nhaarman.listviewanimations.itemmanipulation.swipedismiss.undo.UndoAdapter;
import com.nhaarman.listviewanimations.util.Swappable;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class DefaultIssueAdapter extends BaseAdapter implements Swappable, UndoAdapter, OnDismissCallback {
	
	private Context mContext;
	private LayoutInflater mInflater;
	private ArrayList<DummyModelIssueStock> mDummyModelList;
	private boolean mShouldShowDragAndDropIcon;
	
	
	public DefaultIssueAdapter(Context context, ArrayList<DummyModelIssueStock> dummyModelList, boolean shouldShowDragAndDropIcon) {
		// TODO Auto-generated constructor stub
		mContext = context;
		mInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		mDummyModelList = dummyModelList;
		mShouldShowDragAndDropIcon = shouldShowDragAndDropIcon;
	}
	
	@Override
	public boolean hasStableIds() {
		return true;
	}  

		
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return mDummyModelList.size(); 
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return mDummyModelList.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return mDummyModelList.get(position).getId();
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		final ViewHolder holder;
		try {
			if (convertView == null) {
				convertView = mInflater.inflate(R.layout.list_item_default, parent, false);
				holder = new ViewHolder();  
				holder.image = (ImageButton) convertView.findViewById(R.id.image);
				holder.item_name = (TextView) convertView.findViewById(R.id.txt_itemlist_item_name);
				holder.itmfletter = (TextView) convertView.findViewById(R.id.txt_itemlist_flet);
				holder.itemqty = (TextView) convertView.findViewById(R.id.txt_itemlist_qty);
				holder.editloc = (ImageView) convertView.findViewById(R.id.iv_itemlist_editlocation);
				convertView.setTag(holder); 
			} else {  
				holder = (ViewHolder) convertView.getTag();   
			}; 
			final DummyModelIssueStock dm = mDummyModelList.get(position);
			if (holder.image != null) {  
				 try {  
					 mContext =holder.image.getContext();  
					 Random rnd = new Random();  int color;
					 color = Color.WHITE;
					 do{   
					  color = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256)); 
					 }while(color==-1 ||color==0); 
					 GradientDrawable gd = (GradientDrawable) holder.image.getBackground();
					gd.setColor(color); 
					
				} catch (Exception e) { 
					// TODO Auto-generated catch block   
					e.printStackTrace();    
				}  
			}
			holder.itmfletter.setText(dm.getText());
			holder.item_name.setText(dm.getItemname());
			holder.itemqty.setText("Qty:"+dm.getItemqty());
			if(dm.getlocstatus().equals(""+0)){
				holder.editloc.setImageResource(R.drawable.gpsred);
			}else{
				holder.editloc.setImageResource(R.drawable.gps);
			}
			
			holder.editloc.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					ViewIssueStock.editLocation(dm.getIssueid());
					
				}
			});
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return convertView;
	}
	
	private static class ViewHolder {
		public ImageButton image;ImageView editloc;
		public /*Roboto*/TextView item_name,itmfletter,itemqty;
		
	}

	@Override 
	@NonNull
	public View getUndoClickView(@NonNull View view) {
		return view.findViewById(R.id.undo_button);
	}

	@Override
	@NonNull
	public View getUndoView(final int position, final View convertView,
			@NonNull final ViewGroup parent) {
		View view = convertView;
		if (view == null) {
			view = LayoutInflater.from(mContext).inflate(R.layout.list_item_undo_view,
					parent, false);
		}
		return view;
	}

	@Override
	public void onDismiss(@NonNull final ViewGroup listView,
			@NonNull final int[] reverseSortedPositions) {
		for (int position : reverseSortedPositions) {
			remove(position);
		}
	}
	public void remove(int position) {
		mDummyModelList.remove(position);
	}

	@Override
	public void swapItems(int positionOne, int positionTwo) {
		// TODO Auto-generated method stub
		Collections.swap(mDummyModelList, positionOne, positionTwo);
	}

}
