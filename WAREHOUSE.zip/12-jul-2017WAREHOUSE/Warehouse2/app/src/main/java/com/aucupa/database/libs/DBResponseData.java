package com.aucupa.database.libs;

public class DBResponseData {

	public static class UserResponseData{
		public String uname;
		public String password;
	}
}
